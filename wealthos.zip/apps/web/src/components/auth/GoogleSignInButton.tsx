"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuthStore } from "@/lib/auth-store";
import { describeApiError } from "@/lib/api-client";

const GOOGLE_CLIENT_ID = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID;

declare global {
  interface Window {
    google?: {
      accounts: {
        id: {
          initialize: (config: {
            client_id: string;
            callback: (response: { credential: string }) => void;
          }) => void;
          renderButton: (parent: HTMLElement, options: Record<string, unknown>) => void;
        };
      };
    };
  }
}

/**
 * Renders Google's own "Sign in with Google" button via Google Identity
 * Services (GIS). On success, GIS hands us a signed ID token, which we pass
 * to the backend's /auth/google endpoint for verification — see
 * app/api/v1/auth/router.py::google_login.
 *
 * If NEXT_PUBLIC_GOOGLE_CLIENT_ID isn't set, this renders a disabled button
 * explaining why, rather than a button that silently does nothing (that
 * silent-failure was the original bug — the button had no click handler at
 * all).
 */
export function GoogleSignInButton() {
  const router = useRouter();
  const googleLogin = useAuthStore((s) => s.googleLogin);
  const containerRef = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [scriptLoaded, setScriptLoaded] = useState(false);

  useEffect(() => {
    if (!GOOGLE_CLIENT_ID) return;

    const script = document.createElement("script");
    script.src = "https://accounts.google.com/gsi/client";
    script.async = true;
    script.defer = true;
    script.onload = () => setScriptLoaded(true);
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  useEffect(() => {
    if (!scriptLoaded || !GOOGLE_CLIENT_ID || !containerRef.current || !window.google) return;

    window.google.accounts.id.initialize({
      client_id: GOOGLE_CLIENT_ID,
      callback: async (response) => {
        setError(null);
        try {
          await googleLogin(response.credential);
          router.push("/dashboard");
        } catch (err) {
          setError(describeApiError(err));
        }
      },
    });

    window.google.accounts.id.renderButton(containerRef.current, {
      theme: "outline",
      size: "large",
      width: 320,
      text: "continue_with",
    });
  }, [scriptLoaded, googleLogin, router]);

  if (!GOOGLE_CLIENT_ID) {
    return (
      <div>
        <button
          type="button"
          disabled
          title="Google sign-in isn't configured yet — set NEXT_PUBLIC_GOOGLE_CLIENT_ID"
          className="w-full cursor-not-allowed rounded-md border border-border/20 py-2 text-sm font-medium text-text-secondary opacity-60"
        >
          Continue with Google
        </button>
        <p className="mt-1 text-center text-xs text-text-secondary">
          Google sign-in isn&apos;t set up on this environment yet.
        </p>
      </div>
    );
  }

  return (
    <div>
      <div ref={containerRef} className="flex justify-center" />
      {error && (
        <p role="alert" className="mt-2 text-center text-sm text-danger">
          {error}
        </p>
      )}
    </div>
  );
}
