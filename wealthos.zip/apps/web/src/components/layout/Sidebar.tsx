"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { clsx } from "clsx";
import {
  LayoutDashboard,
  Wallet,
  PiggyBank,
  Target,
  Calculator,
  Bot,
  Settings,
  CreditCard,
  Receipt,
  Repeat,
  ShieldCheck,
  FileSpreadsheet,
  FolderLock,
  BarChart3,
  CalendarDays,
} from "lucide-react";

const NAV_GROUPS = [
  {
    label: "Overview",
    items: [
      { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
      { href: "/analytics", label: "Analytics", icon: BarChart3 },
      { href: "/calendar", label: "Calendar", icon: CalendarDays },
    ],
  },
  {
    label: "Money",
    items: [
      { href: "/transactions", label: "Transactions", icon: Wallet },
      { href: "/budget", label: "Budget", icon: Calculator },
      { href: "/bills", label: "Bills", icon: Receipt },
    ],
  },
  {
    label: "Wealth",
    items: [
      { href: "/assets", label: "Assets", icon: PiggyBank },
      { href: "/liabilities", label: "Liabilities", icon: CreditCard },
      { href: "/goals", label: "Goals", icon: Target },
      { href: "/subscriptions", label: "Subscriptions", icon: Repeat },
      { href: "/insurance", label: "Insurance", icon: ShieldCheck },
    ],
  },
  {
    label: "Planning",
    items: [
      { href: "/tax", label: "Tax Planner", icon: FileSpreadsheet },
      { href: "/vault", label: "Document Vault", icon: FolderLock },
    ],
  },
  {
    label: "Assistant",
    items: [{ href: "/assistant", label: "AI Assistant", icon: Bot }],
  },
  {
    label: "System",
    items: [{ href: "/settings", label: "Settings", icon: Settings }],
  },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden w-60 shrink-0 border-r border-border/10 bg-surface/40 px-4 py-6 lg:block">
      <div className="mb-8 px-2">
        <span className="font-display text-lg font-bold text-text-primary">WealthOS</span>
      </div>
      <nav className="space-y-6">
        {NAV_GROUPS.map((group) => (
          <div key={group.label}>
            <p className="mb-2 px-2 text-xs font-semibold uppercase tracking-wide text-text-secondary">
              {group.label}
            </p>
            <ul className="space-y-1">
              {group.items.map((item) => {
                const Icon = item.icon;
                const active = pathname === item.href;
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className={clsx(
                        "flex items-center gap-3 rounded-md px-2 py-2 text-sm font-medium transition",
                        active
                          ? "bg-primary/10 text-primary"
                          : "text-text-secondary hover:bg-surface hover:text-text-primary"
                      )}
                    >
                      <Icon size={18} />
                      {item.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  );
}
