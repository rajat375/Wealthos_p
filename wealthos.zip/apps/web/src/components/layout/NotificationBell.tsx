"use client";

import { useState } from "react";
import { Bell } from "lucide-react";
import { clsx } from "clsx";
import { useNotifications } from "@/hooks/useNotifications";

export function NotificationBell() {
  const { notifications, unreadCount, markRead, markAllRead } = useNotifications();
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="relative rounded-full p-2 text-text-secondary hover:bg-surface hover:text-text-primary"
        aria-label="Notifications"
      >
        <Bell size={20} />
        {unreadCount > 0 && (
          <span className="absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-danger text-[10px] font-semibold text-white">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <>
          <button
            className="fixed inset-0 z-10 cursor-default"
            aria-label="Close notifications"
            onClick={() => setOpen(false)}
          />
          <div className="glass-card absolute right-0 z-20 mt-2 w-80 p-0">
            <div className="flex items-center justify-between border-b border-border/10 p-3">
              <p className="text-sm font-semibold text-text-primary">Notifications</p>
              {unreadCount > 0 && (
                <button onClick={markAllRead} className="text-xs font-medium text-primary hover:underline">
                  Mark all read
                </button>
              )}
            </div>
            <div className="max-h-80 overflow-y-auto">
              {notifications.length === 0 ? (
                <p className="p-6 text-center text-sm text-text-secondary">You&apos;re all caught up.</p>
              ) : (
                <ul className="divide-y divide-border/10">
                  {notifications.map((n) => (
                    <li
                      key={n.id}
                      onClick={() => !n.is_read && markRead(n.id)}
                      className={clsx(
                        "cursor-pointer p-3 hover:bg-surface",
                        !n.is_read && "bg-primary/5"
                      )}
                    >
                      <p className="text-sm font-medium text-text-primary">{n.title}</p>
                      {n.body && <p className="mt-0.5 text-xs text-text-secondary">{n.body}</p>}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
