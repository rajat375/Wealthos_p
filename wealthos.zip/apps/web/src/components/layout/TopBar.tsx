"use client";

import Link from "next/link";
import { Bot } from "lucide-react";
import { NotificationBell } from "@/components/layout/NotificationBell";

export function TopBar() {
  return (
    <header className="flex items-center justify-end gap-2 border-b border-border/10 px-4 py-3 sm:px-8">
      <Link
        href="/assistant"
        className="flex items-center gap-1.5 rounded-full border border-border/20 px-3 py-1.5 text-sm font-medium text-text-secondary hover:bg-surface hover:text-text-primary"
      >
        <Bot size={16} />
        Ask AI
      </Link>
      <NotificationBell />
    </header>
  );
}
