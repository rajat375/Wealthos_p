import { clsx } from "clsx";
import type { BudgetItemStatus } from "@/types/finance";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export function BudgetProgressBar({ item }: { item: BudgetItemStatus }) {
  const pct = Math.min(item.percentage_used, 100);
  const barColor =
    item.percentage_used >= 100
      ? "bg-danger"
      : item.percentage_used >= 80
        ? "bg-warning"
        : "bg-success";

  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-sm">
        <span className="font-medium text-text-primary">{item.category_name}</span>
        <span className="text-text-secondary">
          {currency.format(item.actual_amount)} / {currency.format(item.planned_amount)}
        </span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-surface">
        <div className={clsx("h-full rounded-full transition-all", barColor)} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
