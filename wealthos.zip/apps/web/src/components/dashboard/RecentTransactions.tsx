import { clsx } from "clsx";
import type { DashboardSummary } from "@/types/finance";

const formatter = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export function RecentTransactions({
  items,
}: {
  items: DashboardSummary["recent_transactions"];
}) {
  if (items.length === 0) {
    return (
      <p className="py-6 text-center text-sm text-text-secondary">
        No transactions yet — add your first one to see it here.
      </p>
    );
  }

  return (
    <ul className="divide-y divide-border/10">
      {items.map((t) => (
        <li key={t.id} className="flex items-center justify-between py-3">
          <div>
            <p className="text-sm font-medium text-text-primary">
              {t.merchant ?? (t.type === "income" ? "Income" : "Expense")}
            </p>
            <p className="text-xs text-text-secondary">{t.date}</p>
          </div>
          <span
            className={clsx(
              "text-sm font-semibold tabular-nums",
              t.type === "income" ? "text-success" : "text-danger"
            )}
          >
            {t.type === "income" ? "+" : "-"}
            {formatter.format(t.amount)}
          </span>
        </li>
      ))}
    </ul>
  );
}
