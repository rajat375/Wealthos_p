import { Home, Car, Plane, PiggyBank, GraduationCap, Umbrella, Target } from "lucide-react";
import type { Goal, GoalType } from "@/types/finance";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

const GOAL_ICONS: Record<GoalType, typeof Home> = {
  emergency_fund: Umbrella,
  house: Home,
  car: Car,
  vacation: Plane,
  retirement: PiggyBank,
  child_education: GraduationCap,
  custom: Target,
};

export function GoalProgressCard({ goal }: { goal: Goal }) {
  const Icon = GOAL_ICONS[goal.goal_type] ?? Target;
  const pct = Math.min(goal.progress_pct, 100);

  return (
    <div className="rounded-md border border-border/10 p-4">
      <div className="mb-2 flex items-center gap-2">
        <Icon size={18} className="text-primary" />
        <p className="text-sm font-medium text-text-primary">{goal.name}</p>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-surface">
        <div
          className="h-full rounded-full bg-primary transition-all"
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="mt-2 flex items-center justify-between text-xs text-text-secondary">
        <span>
          {currency.format(goal.current_amount)} of {currency.format(goal.target_amount)}
        </span>
        <span className="font-medium text-text-primary">{pct}%</span>
      </div>
    </div>
  );
}
