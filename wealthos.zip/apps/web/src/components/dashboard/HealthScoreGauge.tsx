import { clsx } from "clsx";
import type { HealthScore } from "@/types/finance";

function bandFor(score: number): { label: string; color: string } {
  if (score >= 80) return { label: "Excellent", color: "text-success" };
  if (score >= 60) return { label: "Good", color: "text-primary" };
  if (score >= 40) return { label: "Fair", color: "text-warning" };
  return { label: "Needs attention", color: "text-danger" };
}

export function HealthScoreGauge({ healthScore }: { healthScore: HealthScore }) {
  const { label, color } = bandFor(healthScore.score);
  const circumference = 2 * Math.PI * 54;
  const offset = circumference * (1 - healthScore.score / 100);

  return (
    <div className="flex items-center gap-6">
      <div className="relative h-32 w-32 shrink-0">
        <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90">
          <circle cx="60" cy="60" r="54" fill="none" strokeWidth="10" className="stroke-surface" />
          <circle
            cx="60"
            cy="60"
            r="54"
            fill="none"
            strokeWidth="10"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            className={clsx(color, "stroke-current transition-all duration-700")}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display text-3xl font-bold text-text-primary">{healthScore.score}</span>
          <span className="text-xs text-text-secondary">/ 100</span>
        </div>
      </div>
      <div className="space-y-2">
        <p className={clsx("text-sm font-semibold", color)}>{label}</p>
        <ul className="space-y-1 text-xs text-text-secondary">
          <li>Savings rate: {healthScore.components.savings_rate.value_pct}%</li>
          <li>Debt-to-income: {healthScore.components.debt_to_income.value_pct}%</li>
          <li>Emergency fund: {healthScore.components.emergency_fund.months_covered} months</li>
        </ul>
      </div>
    </div>
  );
}
