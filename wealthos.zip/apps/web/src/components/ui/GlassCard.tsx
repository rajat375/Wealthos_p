import { clsx } from "clsx";
import type { ReactNode } from "react";

export function GlassCard({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={clsx("glass-card p-5 sm:p-6", className)}>{children}</div>
  );
}

export function StatTile({
  label,
  value,
  delta,
  deltaLabel,
}: {
  label: string;
  value: string;
  delta?: number;
  deltaLabel?: string;
}) {
  const isPositive = (delta ?? 0) >= 0;
  return (
    <div>
      <p className="text-sm text-text-secondary">{label}</p>
      <p className="mt-1 font-display text-3xl font-bold tabular-nums text-text-primary sm:text-4xl">
        {value}
      </p>
      {delta !== undefined && (
        <p
          className={clsx(
            "mt-1 text-sm font-medium",
            isPositive ? "text-success" : "text-danger"
          )}
        >
          {isPositive ? "▲" : "▼"} {Math.abs(delta)}% {deltaLabel}
        </p>
      )}
    </div>
  );
}
