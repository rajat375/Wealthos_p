"use client";

import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export function CashFlowChart({ income, expense }: { income: number; expense: number }) {
  const data = [{ name: "This month", Income: income, Expense: expense }];

  return (
    <ResponsiveContainer width="100%" height={180}>
      <BarChart data={data} barGap={8}>
        <XAxis dataKey="name" stroke="rgb(var(--text-secondary))" fontSize={12} />
        <YAxis stroke="rgb(var(--text-secondary))" fontSize={12} width={40} />
        <Tooltip
          contentStyle={{
            background: "rgb(var(--surface-solid))",
            border: "1px solid rgb(var(--border) / 0.1)",
            borderRadius: 8,
          }}
        />
        <Bar dataKey="Income" fill="rgb(var(--accent-success))" radius={[6, 6, 0, 0]} />
        <Bar dataKey="Expense" fill="rgb(var(--accent-danger))" radius={[6, 6, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
