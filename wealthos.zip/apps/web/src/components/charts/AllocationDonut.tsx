"use client";

import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import type { AssetAllocationItem } from "@/types/finance";

const COLORS = [
  "rgb(79 70 229)",
  "rgb(5 150 105)",
  "rgb(217 119 6)",
  "rgb(220 38 38)",
  "rgb(14 165 233)",
  "rgb(168 85 247)",
  "rgb(236 72 153)",
];

export function AllocationDonut({ data }: { data: AssetAllocationItem[] }) {
  if (data.length === 0) {
    return (
      <p className="py-8 text-center text-sm text-text-secondary">
        Add an asset to see your allocation.
      </p>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={220}>
      <PieChart>
        <Pie
          data={data}
          dataKey="percentage"
          nameKey="asset_type"
          innerRadius={55}
          outerRadius={85}
          paddingAngle={2}
        >
          {data.map((_, i) => (
            <Cell key={i} fill={COLORS[i % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip
          formatter={(value: number, name: string) => [`${value}%`, name]}
          contentStyle={{
            background: "rgb(var(--surface-solid))",
            border: "1px solid rgb(var(--border) / 0.1)",
            borderRadius: 8,
          }}
        />
      </PieChart>
    </ResponsiveContainer>
  );
}
