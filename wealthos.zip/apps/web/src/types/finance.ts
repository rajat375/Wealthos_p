export type AccountType = "bank_savings" | "bank_current" | "cash_wallet" | "credit_card";
export type TransactionType = "income" | "expense" | "transfer";

export interface Account {
  id: string;
  account_type: AccountType;
  name: string;
  institution_name: string | null;
  current_balance: number;
  credit_limit: number | null;
  currency: string;
  is_active: boolean;
}

export interface Transaction {
  id: string;
  account_id: string;
  type: TransactionType;
  amount: number;
  category_id: string | null;
  transaction_date: string;
  merchant: string | null;
  notes: string | null;
  is_recurring: boolean;
}

export interface DashboardSummary {
  net_worth: number;
  month_income: number;
  month_expense: number;
  savings_rate_pct: number;
  recent_transactions: {
    id: string;
    type: TransactionType;
    amount: number;
    merchant: string | null;
    date: string;
  }[];
}

export interface UserPublic {
  id: string;
  email: string;
  full_name: string;
  base_currency: string;
}

export interface Asset {
  id: string;
  name: string;
  quantity: number | null;
  purchase_value: number | null;
  current_value: number;
  purchase_date: string | null;
  institution: string | null;
}

export interface AssetAllocationItem {
  asset_type: string;
  total_value: number;
  percentage: number;
}

export interface AssetSummary {
  total_value: number;
  allocation: AssetAllocationItem[];
}

export interface Liability {
  id: string;
  name: string;
  lender: string | null;
  principal_amount: number;
  outstanding_amount: number;
  interest_rate: number | null;
  emi_amount: number | null;
  end_date: string | null;
}

export type GoalType =
  | "emergency_fund"
  | "house"
  | "car"
  | "vacation"
  | "retirement"
  | "child_education"
  | "custom";

export interface Goal {
  id: string;
  goal_type: GoalType;
  name: string;
  target_amount: number;
  current_amount: number;
  target_date: string | null;
  status: "active" | "completed" | "paused" | "cancelled";
  progress_pct: number;
}

export interface BudgetItemStatus {
  category_id: string;
  category_name: string;
  planned_amount: number;
  actual_amount: number;
  percentage_used: number;
}

export interface BudgetStatus {
  budget_id: string;
  period_start: string;
  period_end: string;
  items: BudgetItemStatus[];
}

export interface Bill {
  id: string;
  name: string;
  amount: number;
  due_date: string;
  frequency: "weekly" | "monthly" | "quarterly" | "yearly";
  is_autopay: boolean;
  is_active: boolean;
}

export interface Subscription {
  id: string;
  name: string;
  amount: number;
  billing_cycle: "weekly" | "monthly" | "yearly";
  next_billing_date: string | null;
  is_active: boolean;
  cancel_url: string | null;
}

export interface SubscriptionSummary {
  monthly_total: number;
  yearly_total: number;
  active_count: number;
}

export type PolicyType = "life" | "health" | "vehicle" | "home" | "term" | "other";

export interface InsurancePolicy {
  id: string;
  policy_type: PolicyType;
  provider: string | null;
  policy_number: string | null;
  sum_assured: number | null;
  premium_amount: number | null;
  premium_frequency: string;
  renewal_date: string | null;
  is_active: boolean;
}

export interface TaxProfile {
  id: string;
  financial_year: string;
  regime: "old" | "new";
  gross_income: number | null;
  deductions: Record<string, number>;
  estimated_tax: number | null;
}

export interface TaxEstimate {
  financial_year: string;
  regime: string;
  taxable_income: number;
  estimated_tax: number;
  effective_rate_pct: number;
}

export interface DeductionSuggestion {
  section: string;
  description: string;
  max_limit: number;
  currently_claimed: number;
  remaining_room: number;
}

export type DocType = "insurance" | "loan" | "tax" | "identity" | "other";

export interface Document {
  id: string;
  title: string;
  doc_type: DocType | null;
  file_size_kb: number | null;
  linked_entity_type: string | null;
  linked_entity_id: string | null;
  expiry_date: string | null;
  is_encrypted: boolean;
}

export interface NetWorthPoint {
  as_of: string;
  assets_value: number;
  liabilities_value: number;
  net_worth: number;
}

export interface CashFlowPoint {
  month: string;
  income: number;
  expense: number;
}

export interface HealthScoreComponent {
  score: number;
  [key: string]: number;
}

export interface HealthScore {
  score: number;
  components: {
    savings_rate: { value_pct: number; score: number };
    debt_to_income: { value_pct: number; score: number };
    emergency_fund: { months_covered: number; score: number };
  };
  calculated_at: string;
}

export interface OverspendingAlert {
  category_id: string;
  category_name: string;
  current_month_total: number;
  baseline_monthly_avg: number;
  delta_pct: number;
  narrative: string;
}

export interface CalendarEntry {
  date: string;
  type: "bill" | "subscription" | "goal_milestone";
  title: string;
  amount: number | null;
}

export interface Notification {
  id: string;
  type: string;
  title: string;
  body: string | null;
  is_read: boolean;
  action_url: string | null;
  created_at: string;
}
