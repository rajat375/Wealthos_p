import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { InsurancePolicy } from "@/types/finance";

export function useInsurance() {
  const [policies, setPolicies] = useState<InsurancePolicy[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    apiRequest<InsurancePolicy[]>("/insurance")
      .then((res) => {
        if (!cancelled) setPolicies(res);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "Failed to load insurance policies");
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return { policies, isLoading, error };
}
