import { useEffect, useState } from "react";
import { apiRequest, apiUpload } from "@/lib/api-client";
import type { Document } from "@/types/finance";

export function useDocuments() {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  async function refresh() {
    try {
      const docs = await apiRequest<Document[]>("/documents");
      setDocuments(docs);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load documents");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function upload(file: File, title: string, docType?: string) {
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("title", title);
      if (docType) formData.append("doc_type", docType);
      await apiUpload<Document>("/documents", formData);
      await refresh();
    } finally {
      setUploading(false);
    }
  }

  return { documents, isLoading, error, uploading, upload, refresh };
}
