import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { Liability } from "@/types/finance";

export function useLiabilities() {
  const [liabilities, setLiabilities] = useState<Liability[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    apiRequest<Liability[]>("/liabilities")
      .then((res) => {
        if (!cancelled) setLiabilities(res);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "Failed to load liabilities");
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const totalOutstanding = liabilities.reduce((sum, l) => sum + l.outstanding_amount, 0);

  return { liabilities, totalOutstanding, isLoading, error };
}
