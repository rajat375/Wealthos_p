import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { Transaction } from "@/types/finance";

interface PaginatedTransactions {
  data: Transaction[];
  meta: { page: number; limit: number; total: number };
}

export function useTransactions(filters: { type?: string } = {}) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [total, setTotal] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    const params = new URLSearchParams();
    if (filters.type) params.set("type", filters.type);

    apiRequest<PaginatedTransactions>(`/transactions?${params.toString()}`)
      .then((res) => {
        if (cancelled) return;
        setTransactions(res.data);
        setTotal(res.meta.total);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "Failed to load transactions");
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [filters.type]);

  return { transactions, total, isLoading, error };
}
