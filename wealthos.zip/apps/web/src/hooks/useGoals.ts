import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { Goal } from "@/types/finance";

export function useGoals() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    apiRequest<Goal[]>("/goals")
      .then((res) => {
        if (!cancelled) setGoals(res);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "Failed to load goals");
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return { goals, isLoading, error };
}
