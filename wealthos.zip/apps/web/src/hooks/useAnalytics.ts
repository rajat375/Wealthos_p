import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { HealthScore, OverspendingAlert } from "@/types/finance";

export function useAnalytics() {
  const [healthScore, setHealthScore] = useState<HealthScore | null>(null);
  const [alerts, setAlerts] = useState<OverspendingAlert[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all([
      apiRequest<HealthScore>("/analytics/health-score"),
      apiRequest<{ overspending_alerts: OverspendingAlert[] }>("/ai/insights"),
    ])
      .then(([score, insights]) => {
        if (cancelled) return;
        setHealthScore(score);
        setAlerts(insights.overspending_alerts);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "Failed to load analytics");
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return { healthScore, alerts, isLoading, error };
}
