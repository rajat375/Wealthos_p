import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { Bill } from "@/types/finance";

export function useBills() {
  const [bills, setBills] = useState<Bill[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    apiRequest<Bill[]>("/bills?upcoming_only=true")
      .then((res) => {
        if (!cancelled) setBills(res);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "Failed to load bills");
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return { bills, isLoading, error };
}
