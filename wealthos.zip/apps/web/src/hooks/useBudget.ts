import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { BudgetStatus } from "@/types/finance";

interface BudgetSummary {
  id: string;
  period_start: string;
  period_end: string;
  total_planned: number | null;
}

function currentPeriod(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

export function useBudget() {
  const [status, setStatus] = useState<BudgetStatus | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        const budget = await apiRequest<BudgetSummary | null>(`/budgets?period=${currentPeriod()}`);
        if (!budget) {
          if (!cancelled) setStatus(null);
          return;
        }
        const budgetStatus = await apiRequest<BudgetStatus>(`/budgets/${budget.id}/status`);
        if (!cancelled) setStatus(budgetStatus);
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : "Failed to load budget");
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  return { status, isLoading, error };
}
