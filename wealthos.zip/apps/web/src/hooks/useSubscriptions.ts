import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { Subscription, SubscriptionSummary } from "@/types/finance";

export function useSubscriptions() {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [summary, setSummary] = useState<SubscriptionSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all([
      apiRequest<Subscription[]>("/subscriptions"),
      apiRequest<SubscriptionSummary>("/subscriptions/summary"),
    ])
      .then(([subs, summ]) => {
        if (cancelled) return;
        setSubscriptions(subs);
        setSummary(summ);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "Failed to load subscriptions");
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return { subscriptions, summary, isLoading, error };
}
