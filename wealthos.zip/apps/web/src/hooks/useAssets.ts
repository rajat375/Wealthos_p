import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { Asset, AssetSummary } from "@/types/finance";

export function useAssets() {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [summary, setSummary] = useState<AssetSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    Promise.all([
      apiRequest<Asset[]>("/assets"),
      apiRequest<AssetSummary>("/assets/summary"),
    ])
      .then(([assetList, assetSummary]) => {
        if (cancelled) return;
        setAssets(assetList);
        setSummary(assetSummary);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "Failed to load assets");
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return { assets, summary, isLoading, error };
}
