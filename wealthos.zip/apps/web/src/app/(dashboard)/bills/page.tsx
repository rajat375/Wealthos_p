"use client";

import { clsx } from "clsx";
import { GlassCard } from "@/components/ui/GlassCard";
import { useBills } from "@/hooks/useBills";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

function daysUntil(dateStr: string): number {
  const due = new Date(dateStr);
  const today = new Date();
  return Math.ceil((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

export default function BillsPage() {
  const { bills, isLoading, error } = useBills();

  if (isLoading) {
    return <div className="glass-card h-64 animate-pulse" />;
  }

  if (error) {
    return (
      <GlassCard>
        <p className="text-sm text-danger">Couldn&apos;t load your bills: {error}</p>
      </GlassCard>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-text-primary">Upcoming Bills</h1>
          <p className="text-sm text-text-secondary">Next 30 days</p>
        </div>
        <button className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90">
          + Add Bill
        </button>
      </div>

      <GlassCard>
        {bills.length === 0 ? (
          <p className="py-8 text-center text-sm text-text-secondary">
            No bills due in the next 30 days.
          </p>
        ) : (
          <ul className="divide-y divide-border/10">
            {bills.map((b) => {
              const days = daysUntil(b.due_date);
              const urgent = days <= 3;
              return (
                <li key={b.id} className="flex items-center justify-between py-3">
                  <div>
                    <p className="text-sm font-medium text-text-primary">{b.name}</p>
                    <p className={clsx("text-xs", urgent ? "text-warning font-medium" : "text-text-secondary")}>
                      Due {b.due_date} {urgent && `· in ${days}d`}
                      {b.is_autopay && " · Autopay"}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-semibold tabular-nums text-text-primary">
                      {currency.format(b.amount)}
                    </span>
                    <button className="rounded-md border border-border/20 px-3 py-1 text-xs font-medium text-text-primary hover:bg-surface">
                      Mark Paid
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </GlassCard>
    </div>
  );
}
