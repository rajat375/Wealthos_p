"use client";

import { GlassCard } from "@/components/ui/GlassCard";
import { BudgetProgressBar } from "@/components/dashboard/BudgetProgressBar";
import { useBudget } from "@/hooks/useBudget";

export default function BudgetPage() {
  const { status, isLoading, error } = useBudget();

  if (isLoading) {
    return <div className="glass-card h-64 animate-pulse" />;
  }

  if (error) {
    return (
      <GlassCard>
        <p className="text-sm text-danger">Couldn&apos;t load your budget: {error}</p>
      </GlassCard>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-text-primary">Budget</h1>
          <p className="text-sm text-text-secondary">Planned vs. actual spend this month</p>
        </div>
        <button className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90">
          {status ? "Edit Budget" : "Create Budget"}
        </button>
      </div>

      <GlassCard>
        {!status || status.items.length === 0 ? (
          <p className="py-8 text-center text-sm text-text-secondary">
            No budget set for this month yet. Create one to track spending by category.
          </p>
        ) : (
          <div className="space-y-5">
            {status.items.map((item) => (
              <BudgetProgressBar key={item.category_id} item={item} />
            ))}
          </div>
        )}
      </GlassCard>
    </div>
  );
}
