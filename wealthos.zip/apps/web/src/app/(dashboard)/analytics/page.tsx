"use client";

import { AlertTriangle } from "lucide-react";
import { GlassCard } from "@/components/ui/GlassCard";
import { HealthScoreGauge } from "@/components/dashboard/HealthScoreGauge";
import { useAnalytics } from "@/hooks/useAnalytics";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export default function AnalyticsPage() {
  const { healthScore, alerts, isLoading, error } = useAnalytics();

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="glass-card h-40 animate-pulse" />
        <div className="glass-card h-48 animate-pulse" />
      </div>
    );
  }

  if (error) {
    return (
      <GlassCard>
        <p className="text-sm text-danger">Couldn&apos;t load your analytics: {error}</p>
      </GlassCard>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-text-primary">Analytics</h1>
        <p className="text-sm text-text-secondary">Your financial health, at a glance</p>
      </div>

      {healthScore && (
        <GlassCard>
          <h2 className="mb-4 text-sm font-semibold text-text-primary">Financial Health Score</h2>
          <HealthScoreGauge healthScore={healthScore} />
        </GlassCard>
      )}

      <GlassCard>
        <h2 className="mb-3 text-sm font-semibold text-text-primary">Spending Alerts</h2>
        {alerts.length === 0 ? (
          <p className="py-6 text-center text-sm text-text-secondary">
            Nothing unusual this month — your spending is in line with your recent average.
          </p>
        ) : (
          <ul className="space-y-3">
            {alerts.map((a) => (
              <li key={a.category_id} className="flex items-start gap-3 rounded-md border border-warning/20 bg-warning/5 p-3">
                <AlertTriangle size={18} className="mt-0.5 shrink-0 text-warning" />
                <div>
                  <p className="text-sm font-medium text-text-primary">{a.narrative}</p>
                  <p className="mt-0.5 text-xs text-text-secondary">
                    {currency.format(a.current_month_total)} this month vs.{" "}
                    {currency.format(a.baseline_monthly_avg)} average
                  </p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </GlassCard>
    </div>
  );
}
