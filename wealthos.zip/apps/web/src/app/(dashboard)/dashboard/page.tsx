"use client";

import { GlassCard, StatTile } from "@/components/ui/GlassCard";
import { CashFlowChart } from "@/components/charts/CashFlowChart";
import { RecentTransactions } from "@/components/dashboard/RecentTransactions";
import { useDashboardSummary } from "@/hooks/useDashboardSummary";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

function DashboardSkeleton() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="glass-card h-32 animate-pulse" />
      ))}
    </div>
  );
}

export default function DashboardPage() {
  const { data, isLoading, error } = useDashboardSummary();

  if (isLoading) return <DashboardSkeleton />;

  if (error) {
    return (
      <GlassCard>
        <p className="text-sm text-danger">Couldn&apos;t load your dashboard: {error}</p>
      </GlassCard>
    );
  }

  if (!data) return null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-text-primary">Good evening 👋</h1>
        <p className="text-sm text-text-secondary">Here&apos;s where your money stands today.</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <GlassCard>
          <StatTile label="Net Worth" value={currency.format(data.net_worth)} />
        </GlassCard>
        <GlassCard>
          <StatTile
            label="Savings Rate"
            value={`${data.savings_rate_pct}%`}
            delta={data.savings_rate_pct}
            deltaLabel="of income saved"
          />
        </GlassCard>
        <GlassCard>
          <StatTile label="Income this month" value={currency.format(data.month_income)} />
        </GlassCard>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <GlassCard className="lg:col-span-2">
          <h2 className="mb-2 text-sm font-semibold text-text-primary">Income vs Expense</h2>
          <CashFlowChart income={data.month_income} expense={data.month_expense} />
        </GlassCard>

        <GlassCard>
          <h2 className="mb-2 text-sm font-semibold text-text-primary">Recent Transactions</h2>
          <RecentTransactions items={data.recent_transactions} />
        </GlassCard>
      </div>
    </div>
  );
}
