"use client";

import { GlassCard, StatTile } from "@/components/ui/GlassCard";
import { useSubscriptions } from "@/hooks/useSubscriptions";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export default function SubscriptionsPage() {
  const { subscriptions, summary, isLoading, error } = useSubscriptions();

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="glass-card h-24 animate-pulse" />
        <div className="glass-card h-64 animate-pulse" />
      </div>
    );
  }

  if (error) {
    return (
      <GlassCard>
        <p className="text-sm text-danger">Couldn&apos;t load your subscriptions: {error}</p>
      </GlassCard>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-text-primary">Subscriptions</h1>
          <p className="text-sm text-text-secondary">{summary?.active_count ?? 0} active</p>
        </div>
        <button className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90">
          + Add Subscription
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <GlassCard>
          <StatTile label="Monthly Total" value={currency.format(summary?.monthly_total ?? 0)} />
        </GlassCard>
        <GlassCard>
          <StatTile label="Yearly Total" value={currency.format(summary?.yearly_total ?? 0)} />
        </GlassCard>
      </div>

      <GlassCard>
        {subscriptions.length === 0 ? (
          <p className="py-8 text-center text-sm text-text-secondary">
            No subscriptions tracked yet — add Netflix, Spotify, or any recurring service.
          </p>
        ) : (
          <ul className="divide-y divide-border/10">
            {subscriptions.map((s) => (
              <li key={s.id} className="flex items-center justify-between py-3">
                <div>
                  <p className="text-sm font-medium text-text-primary">{s.name}</p>
                  <p className="text-xs text-text-secondary">
                    {s.billing_cycle}
                    {s.next_billing_date && ` · renews ${s.next_billing_date}`}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-semibold tabular-nums text-text-primary">
                    {currency.format(s.amount)}
                  </span>
                  <button className="text-xs font-medium text-danger hover:underline">Cancel</button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </GlassCard>
    </div>
  );
}
