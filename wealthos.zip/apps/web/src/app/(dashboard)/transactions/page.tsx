"use client";

import { useState } from "react";
import { clsx } from "clsx";
import { GlassCard } from "@/components/ui/GlassCard";
import { useTransactions } from "@/hooks/useTransactions";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

const FILTERS = [
  { label: "All", value: undefined },
  { label: "Income", value: "income" },
  { label: "Expense", value: "expense" },
  { label: "Transfers", value: "transfer" },
] as const;

export default function TransactionsPage() {
  const [type, setType] = useState<string | undefined>(undefined);
  const { transactions, total, isLoading, error } = useTransactions({ type });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-text-primary">Transactions</h1>
          <p className="text-sm text-text-secondary">{total} total</p>
        </div>
        <button className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90">
          + Add Transaction
        </button>
      </div>

      <div className="flex gap-2">
        {FILTERS.map((f) => (
          <button
            key={f.label}
            onClick={() => setType(f.value)}
            className={clsx(
              "rounded-full px-4 py-1.5 text-sm font-medium transition",
              type === f.value
                ? "bg-primary text-white"
                : "bg-surface text-text-secondary hover:text-text-primary"
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      <GlassCard>
        {isLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-10 animate-pulse rounded bg-surface" />
            ))}
          </div>
        ) : error ? (
          <p className="text-sm text-danger">{error}</p>
        ) : transactions.length === 0 ? (
          <p className="py-8 text-center text-sm text-text-secondary">
            No transactions match this filter yet.
          </p>
        ) : (
          <ul className="divide-y divide-border/10">
            {transactions.map((t) => (
              <li key={t.id} className="flex items-center justify-between py-3">
                <div>
                  <p className="text-sm font-medium text-text-primary">
                    {t.merchant ?? (t.type === "income" ? "Income" : "Expense")}
                  </p>
                  <p className="text-xs text-text-secondary">{t.transaction_date}</p>
                </div>
                <span
                  className={clsx(
                    "text-sm font-semibold tabular-nums",
                    t.type === "income" ? "text-success" : "text-danger"
                  )}
                >
                  {t.type === "income" ? "+" : "-"}
                  {currency.format(t.amount)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </GlassCard>
    </div>
  );
}
