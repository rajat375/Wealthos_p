"use client";

import { GlassCard, StatTile } from "@/components/ui/GlassCard";
import { useTaxPlanner } from "@/hooks/useTaxPlanner";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export default function TaxPlannerPage() {
  const { fy, profile, estimate, suggestions, isLoading, error } = useTaxPlanner();

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="glass-card h-24 animate-pulse" />
        <div className="glass-card h-48 animate-pulse" />
      </div>
    );
  }

  if (error) {
    return (
      <GlassCard>
        <p className="text-sm text-danger">Couldn&apos;t load your tax planner: {error}</p>
      </GlassCard>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-text-primary">Tax Planner</h1>
        <p className="text-sm text-text-secondary">FY {fy} · {profile?.regime ?? "new"} regime</p>
      </div>

      {!profile?.gross_income ? (
        <GlassCard>
          <p className="py-6 text-center text-sm text-text-secondary">
            Set your gross income to see an estimated tax liability and deduction suggestions.
          </p>
          <div className="flex justify-center">
            <button className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90">
              Set Income
            </button>
          </div>
        </GlassCard>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <GlassCard>
              <StatTile label="Taxable Income" value={currency.format(estimate?.taxable_income ?? 0)} />
            </GlassCard>
            <GlassCard>
              <StatTile label="Estimated Tax" value={currency.format(estimate?.estimated_tax ?? 0)} />
            </GlassCard>
            <GlassCard>
              <StatTile label="Effective Rate" value={`${estimate?.effective_rate_pct ?? 0}%`} />
            </GlassCard>
          </div>

          {suggestions.length > 0 && (
            <GlassCard>
              <h2 className="mb-3 text-sm font-semibold text-text-primary">Deduction Room Remaining</h2>
              <ul className="divide-y divide-border/10">
                {suggestions.map((s) => (
                  <li key={s.section} className="py-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-text-primary">
                        Section {s.section}
                      </span>
                      <span className="text-sm font-semibold text-success">
                        {currency.format(s.remaining_room)} left
                      </span>
                    </div>
                    <p className="mt-0.5 text-xs text-text-secondary">{s.description}</p>
                  </li>
                ))}
              </ul>
            </GlassCard>
          )}
        </>
      )}
    </div>
  );
}
