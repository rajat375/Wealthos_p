"use client";

import { GlassCard, StatTile } from "@/components/ui/GlassCard";
import { useLiabilities } from "@/hooks/useLiabilities";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export default function LiabilitiesPage() {
  const { liabilities, totalOutstanding, isLoading, error } = useLiabilities();

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="glass-card h-24 animate-pulse" />
        <div className="glass-card h-64 animate-pulse" />
      </div>
    );
  }

  if (error) {
    return (
      <GlassCard>
        <p className="text-sm text-danger">Couldn&apos;t load your liabilities: {error}</p>
      </GlassCard>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-text-primary">Liabilities</h1>
          <p className="text-sm text-text-secondary">Loans and debts you&apos;re tracking</p>
        </div>
        <button className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90">
          + Add Liability
        </button>
      </div>

      <GlassCard>
        <StatTile label="Total Outstanding" value={currency.format(totalOutstanding)} />
      </GlassCard>

      <GlassCard>
        {liabilities.length === 0 ? (
          <p className="py-8 text-center text-sm text-text-secondary">
            No liabilities tracked yet — add a home loan, personal loan, or credit card debt.
          </p>
        ) : (
          <ul className="divide-y divide-border/10">
            {liabilities.map((l) => (
              <li key={l.id} className="flex items-center justify-between py-4">
                <div>
                  <p className="text-sm font-medium text-text-primary">{l.name}</p>
                  <p className="text-xs text-text-secondary">
                    {l.lender ?? "—"}
                    {l.interest_rate ? ` · ${l.interest_rate}% APR` : ""}
                    {l.emi_amount ? ` · EMI ${currency.format(l.emi_amount)}` : ""}
                  </p>
                </div>
                <span className="text-sm font-semibold tabular-nums text-danger">
                  {currency.format(l.outstanding_amount)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </GlassCard>
    </div>
  );
}
