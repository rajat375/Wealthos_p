"use client";

import { useState, FormEvent } from "react";
import { Bot, Send, User } from "lucide-react";
import { GlassCard } from "@/components/ui/GlassCard";
import { apiRequest, ApiError } from "@/lib/api-client";

interface Message {
  role: "user" | "assistant";
  text: string;
}

const SUGGESTIONS = ["How much did I spend on food in May?", "Show my investment growth", "What are my highest expenses?"];

export default function AssistantPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function ask(question: string) {
    if (!question.trim()) return;
    setError(null);
    setMessages((prev) => [...prev, { role: "user", text: question }]);
    setInput("");
    setSending(true);
    try {
      const res = await apiRequest<{ answer: string }>("/ai/query", {
        method: "POST",
        body: { question },
      });
      setMessages((prev) => [...prev, { role: "assistant", text: res.answer }]);
    } catch (err) {
      setError(
        err instanceof ApiError
          ? err.message
          : "The assistant couldn't answer that right now. Please try again."
      );
    } finally {
      setSending(false);
    }
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    ask(input);
  }

  return (
    <div className="mx-auto flex h-[calc(100vh-8rem)] max-w-2xl flex-col">
      <div className="mb-4">
        <h1 className="font-display text-2xl font-bold text-text-primary">AI Assistant</h1>
        <p className="text-sm text-text-secondary">Ask about your spending, income, or investments.</p>
      </div>

      <GlassCard className="flex flex-1 flex-col overflow-hidden">
        <div className="flex-1 space-y-4 overflow-y-auto p-1">
          {messages.length === 0 && (
            <div className="flex flex-col items-center gap-4 py-10 text-center">
              <Bot size={32} className="text-primary" />
              <p className="text-sm text-text-secondary">Try asking:</p>
              <div className="flex flex-wrap justify-center gap-2">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => ask(s)}
                    className="rounded-full border border-border/20 px-3 py-1.5 text-xs text-text-secondary hover:bg-surface hover:text-text-primary"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m, i) => (
            <div key={i} className={`flex gap-2 ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              {m.role === "assistant" && (
                <Bot size={18} className="mt-1 shrink-0 text-primary" />
              )}
              <div
                className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                  m.role === "user" ? "bg-primary text-white" : "bg-surface text-text-primary"
                }`}
              >
                {m.text}
              </div>
              {m.role === "user" && <User size={18} className="mt-1 shrink-0 text-text-secondary" />}
            </div>
          ))}

          {sending && <p className="text-xs text-text-secondary">Thinking…</p>}
          {error && <p className="text-sm text-danger">{error}</p>}
        </div>

        <form onSubmit={handleSubmit} className="mt-3 flex gap-2 border-t border-border/10 pt-3">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask a question about your finances…"
            className="flex-1 rounded-md border border-border/20 bg-surface px-3 py-2 text-sm text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
          />
          <button
            type="submit"
            disabled={sending || !input.trim()}
            className="rounded-md bg-primary px-3 py-2 text-white hover:opacity-90 disabled:opacity-50"
          >
            <Send size={16} />
          </button>
        </form>
      </GlassCard>
    </div>
  );
}
