"use client";

import { GlassCard } from "@/components/ui/GlassCard";
import { AllocationDonut } from "@/components/charts/AllocationDonut";
import { useAssets } from "@/hooks/useAssets";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export default function AssetsPage() {
  const { assets, summary, isLoading, error } = useAssets();

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="glass-card h-64 animate-pulse lg:col-span-1" />
        <div className="glass-card h-64 animate-pulse lg:col-span-2" />
      </div>
    );
  }

  if (error) {
    return (
      <GlassCard>
        <p className="text-sm text-danger">Couldn&apos;t load your assets: {error}</p>
      </GlassCard>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-text-primary">Assets</h1>
          <p className="text-sm text-text-secondary">
            {summary ? currency.format(summary.total_value) : "—"} across{" "}
            {summary?.allocation.length ?? 0} categories
          </p>
        </div>
        <button className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90">
          + Add Asset
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <GlassCard>
          <h2 className="mb-2 text-sm font-semibold text-text-primary">Allocation</h2>
          <AllocationDonut data={summary?.allocation ?? []} />
        </GlassCard>

        <GlassCard className="lg:col-span-2">
          <h2 className="mb-2 text-sm font-semibold text-text-primary">All Assets</h2>
          {assets.length === 0 ? (
            <p className="py-8 text-center text-sm text-text-secondary">
              No assets yet. Add your first mutual fund, stock, gold holding, or FD.
            </p>
          ) : (
            <ul className="divide-y divide-border/10">
              {assets.map((a) => (
                <li key={a.id} className="flex items-center justify-between py-3">
                  <div>
                    <p className="text-sm font-medium text-text-primary">{a.name}</p>
                    {a.institution && (
                      <p className="text-xs text-text-secondary">{a.institution}</p>
                    )}
                  </div>
                  <span className="text-sm font-semibold tabular-nums text-text-primary">
                    {currency.format(a.current_value)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </GlassCard>
      </div>
    </div>
  );
}
