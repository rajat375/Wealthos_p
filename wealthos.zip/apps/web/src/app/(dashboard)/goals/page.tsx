"use client";

import { GlassCard } from "@/components/ui/GlassCard";
import { GoalProgressCard } from "@/components/dashboard/GoalProgressCard";
import { useGoals } from "@/hooks/useGoals";

export default function GoalsPage() {
  const { goals, isLoading, error } = useGoals();

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="glass-card h-28 animate-pulse" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <GlassCard>
        <p className="text-sm text-danger">Couldn&apos;t load your goals: {error}</p>
      </GlassCard>
    );
  }

  const activeGoals = goals.filter((g) => g.status === "active");
  const completedGoals = goals.filter((g) => g.status === "completed");

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-text-primary">Goals</h1>
          <p className="text-sm text-text-secondary">
            {activeGoals.length} active · {completedGoals.length} completed
          </p>
        </div>
        <button className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90">
          + New Goal
        </button>
      </div>

      {goals.length === 0 ? (
        <GlassCard>
          <p className="py-8 text-center text-sm text-text-secondary">
            No goals yet. Start with an Emergency Fund — most people begin there.
          </p>
        </GlassCard>
      ) : (
        <GlassCard>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {goals.map((g) => (
              <GoalProgressCard key={g.id} goal={g} />
            ))}
          </div>
        </GlassCard>
      )}
    </div>
  );
}
