"use client";

import { CalendarClock, CreditCard, Repeat, Target } from "lucide-react";
import { GlassCard } from "@/components/ui/GlassCard";
import { useCalendar } from "@/hooks/useCalendar";
import type { CalendarEntry } from "@/types/finance";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

const TYPE_ICON: Record<CalendarEntry["type"], typeof CreditCard> = {
  bill: CreditCard,
  subscription: Repeat,
  goal_milestone: Target,
};

export default function CalendarPage() {
  const { entries, isLoading, error } = useCalendar();

  if (isLoading) return <div className="glass-card h-64 animate-pulse" />;

  if (error) {
    return (
      <GlassCard>
        <p className="text-sm text-danger">Couldn&apos;t load your calendar: {error}</p>
      </GlassCard>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-text-primary">Calendar</h1>
        <p className="text-sm text-text-secondary">Bills, subscriptions, and goal dates this month</p>
      </div>

      <GlassCard>
        {entries.length === 0 ? (
          <div className="flex flex-col items-center py-10 text-center">
            <CalendarClock size={28} className="mb-2 text-text-secondary" />
            <p className="text-sm text-text-secondary">Nothing scheduled this month.</p>
          </div>
        ) : (
          <ul className="divide-y divide-border/10">
            {entries.map((entry, i) => {
              const Icon = TYPE_ICON[entry.type];
              return (
                <li key={i} className="flex items-center gap-3 py-3">
                  <Icon size={18} className="shrink-0 text-primary" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-text-primary">{entry.title}</p>
                    <p className="text-xs text-text-secondary">{entry.date}</p>
                  </div>
                  {entry.amount !== null && (
                    <span className="text-sm font-semibold tabular-nums text-text-primary">
                      {currency.format(entry.amount)}
                    </span>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </GlassCard>
    </div>
  );
}
