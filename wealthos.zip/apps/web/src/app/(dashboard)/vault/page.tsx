"use client";

import { useRef, useState } from "react";
import { FileText, Upload } from "lucide-react";
import { GlassCard } from "@/components/ui/GlassCard";
import { useDocuments } from "@/hooks/useDocuments";
import { ApiError } from "@/lib/api-client";

function formatSize(kb: number | null): string {
  if (!kb) return "";
  return kb > 1024 ? `${(kb / 1024).toFixed(1)} MB` : `${kb} KB`;
}

export default function DocumentVaultPage() {
  const { documents, isLoading, error, uploading, upload } = useDocuments();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);

  async function handleFileSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadError(null);
    try {
      await upload(file, file.name);
    } catch (err) {
      setUploadError(err instanceof ApiError ? err.message : "Upload failed. Please try again.");
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  if (isLoading) return <div className="glass-card h-64 animate-pulse" />;

  if (error) {
    return (
      <GlassCard>
        <p className="text-sm text-danger">Couldn&apos;t load your document vault: {error}</p>
      </GlassCard>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-text-primary">Document Vault</h1>
          <p className="text-sm text-text-secondary">
            {documents.length} documents, stored encrypted
          </p>
        </div>
        <div>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/pdf,image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={handleFileSelected}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-50"
          >
            <Upload size={16} />
            {uploading ? "Uploading…" : "Upload Document"}
          </button>
        </div>
      </div>

      {uploadError && <p className="text-sm text-danger">{uploadError}</p>}

      <GlassCard>
        {documents.length === 0 ? (
          <p className="py-8 text-center text-sm text-text-secondary">
            No documents yet. Upload insurance policies, loan papers, or tax forms — PDF, JPEG, PNG, or WebP, up to 10MB.
          </p>
        ) : (
          <ul className="divide-y divide-border/10">
            {documents.map((d) => (
              <li key={d.id} className="flex items-center gap-3 py-3">
                <FileText size={20} className="shrink-0 text-primary" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-text-primary">{d.title}</p>
                  <p className="text-xs text-text-secondary">
                    {d.doc_type ?? "other"} · {formatSize(d.file_size_kb)}
                    {d.expiry_date && ` · expires ${d.expiry_date}`}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </GlassCard>
    </div>
  );
}
