"use client";

import { clsx } from "clsx";
import { GlassCard } from "@/components/ui/GlassCard";
import { useInsurance } from "@/hooks/useInsurance";
import type { PolicyType } from "@/types/finance";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

const POLICY_LABELS: Record<PolicyType, string> = {
  life: "Life",
  health: "Health",
  vehicle: "Vehicle",
  home: "Home",
  term: "Term",
  other: "Other",
};

function daysUntil(dateStr: string): number {
  return Math.ceil((new Date(dateStr).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
}

export default function InsurancePage() {
  const { policies, isLoading, error } = useInsurance();

  if (isLoading) return <div className="glass-card h-64 animate-pulse" />;

  if (error) {
    return (
      <GlassCard>
        <p className="text-sm text-danger">Couldn&apos;t load your insurance policies: {error}</p>
      </GlassCard>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-text-primary">Insurance</h1>
          <p className="text-sm text-text-secondary">{policies.length} policies tracked</p>
        </div>
        <button className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-white hover:opacity-90">
          + Add Policy
        </button>
      </div>

      <GlassCard>
        {policies.length === 0 ? (
          <p className="py-8 text-center text-sm text-text-secondary">
            No insurance policies yet — add life, health, vehicle, or home coverage.
          </p>
        ) : (
          <ul className="divide-y divide-border/10">
            {policies.map((p) => {
              const dueSoon = p.renewal_date ? daysUntil(p.renewal_date) <= 30 : false;
              return (
                <li key={p.id} className="flex items-center justify-between py-4">
                  <div>
                    <p className="text-sm font-medium text-text-primary">
                      {POLICY_LABELS[p.policy_type]} {p.provider ? `· ${p.provider}` : ""}
                    </p>
                    <p
                      className={clsx(
                        "text-xs",
                        dueSoon ? "font-medium text-warning" : "text-text-secondary"
                      )}
                    >
                      {p.renewal_date ? `Renews ${p.renewal_date}` : "No renewal date set"}
                      {p.sum_assured && ` · Sum assured ${currency.format(p.sum_assured)}`}
                    </p>
                  </div>
                  {p.premium_amount && (
                    <span className="text-sm font-semibold tabular-nums text-text-primary">
                      {currency.format(p.premium_amount)}
                      <span className="text-xs font-normal text-text-secondary">
                        /{p.premium_frequency}
                      </span>
                    </span>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </GlassCard>
    </div>
  );
}
