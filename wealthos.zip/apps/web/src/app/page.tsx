import { redirect } from "next/navigation";

export default function RootPage() {
  // Auth state lives in localStorage (see lib/auth-store.ts), which isn't
  // available during server-side rendering, so we redirect unauthenticated
  // visitors to /login by default; the login page itself sends already
  // logged-in users on to /dashboard client-side if a valid session exists.
  redirect("/login");
}
