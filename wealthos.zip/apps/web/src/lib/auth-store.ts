import { create } from "zustand";
import { apiRequest, clearTokens, setTokens } from "./api-client";
import type { UserPublic } from "@/types/finance";

interface AuthState {
  user: UserPublic | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, fullName: string) => Promise<void>;
  googleLogin: (idToken: string) => Promise<void>;
  logout: () => void;
}

interface TokenResponse {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  user: UserPublic;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isLoading: false,

  login: async (email, password) => {
    set({ isLoading: true });
    try {
      const data = await apiRequest<TokenResponse>("/auth/login", {
        method: "POST",
        body: { email, password },
        auth: false,
      });
      setTokens(data.access_token, data.refresh_token);
      set({ user: data.user });
    } finally {
      set({ isLoading: false });
    }
  },

  register: async (email, password, fullName) => {
    set({ isLoading: true });
    try {
      const data = await apiRequest<TokenResponse>("/auth/register", {
        method: "POST",
        body: { email, password, full_name: fullName },
        auth: false,
      });
      setTokens(data.access_token, data.refresh_token);
      set({ user: data.user });
    } finally {
      set({ isLoading: false });
    }
  },

  googleLogin: async (idToken) => {
    set({ isLoading: true });
    try {
      const data = await apiRequest<TokenResponse>("/auth/google", {
        method: "POST",
        body: { id_token: idToken },
        auth: false,
      });
      setTokens(data.access_token, data.refresh_token);
      set({ user: data.user });
    } finally {
      set({ isLoading: false });
    }
  },

  logout: () => {
    clearTokens();
    set({ user: null });
  },
}));
