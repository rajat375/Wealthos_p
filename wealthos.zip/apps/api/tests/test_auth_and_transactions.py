"""
Integration test sketch (requires a running Postgres — see docs/06 for the
Testcontainers-based setup used in CI). Demonstrates the intended flow:
register -> login -> create account -> create transaction -> balance updates.

Run in CI against an ephemeral Postgres via Testcontainers; this file shows
the shape of the test, with fixtures (`client`, `db_session`) assumed to be
provided by a conftest.py that spins up Postgres + runs Alembic migrations.
"""
import pytest


@pytest.mark.asyncio
async def test_register_login_and_transaction_flow(client):
    # Register
    resp = await client.post(
        "/api/v1/auth/register",
        json={"email": "aditi@example.com", "password": "SuperSecret123!", "full_name": "Aditi Sharma"},
    )
    assert resp.status_code == 201
    tokens = resp.json()
    access_token = tokens["access_token"]
    headers = {"Authorization": f"Bearer {access_token}"}

    # Create account
    resp = await client.post(
        "/api/v1/accounts",
        json={"account_type": "bank_savings", "name": "HDFC Savings", "current_balance": 10000},
        headers=headers,
    )
    assert resp.status_code == 201
    account_id = resp.json()["id"]

    # Add an expense transaction
    resp = await client.post(
        "/api/v1/transactions",
        json={
            "account_id": account_id,
            "type": "expense",
            "amount": 1500,
            "transaction_date": "2026-07-05",
            "merchant": "Blue Tokai Coffee",
        },
        headers=headers,
    )
    assert resp.status_code == 201

    # Verify the DB trigger synced the account balance: 10000 - 1500 = 8500
    resp = await client.get(f"/api/v1/accounts/{account_id}", headers=headers)
    assert resp.status_code == 200
    assert float(resp.json()["current_balance"]) == 8500.0


@pytest.mark.asyncio
async def test_cross_user_access_is_blocked(client):
    """A user must never be able to read another user's account (RLS + object check)."""
    # User A
    resp_a = await client.post(
        "/api/v1/auth/register",
        json={"email": "userA@example.com", "password": "SuperSecret123!", "full_name": "User A"},
    )
    token_a = resp_a.json()["access_token"]
    acc_resp = await client.post(
        "/api/v1/accounts",
        json={"account_type": "cash_wallet", "name": "Wallet"},
        headers={"Authorization": f"Bearer {token_a}"},
    )
    account_id = acc_resp.json()["id"]

    # User B
    resp_b = await client.post(
        "/api/v1/auth/register",
        json={"email": "userB@example.com", "password": "SuperSecret123!", "full_name": "User B"},
    )
    token_b = resp_b.json()["access_token"]

    # User B tries to access User A's account
    resp = await client.get(
        f"/api/v1/accounts/{account_id}", headers={"Authorization": f"Bearer {token_b}"}
    )
    assert resp.status_code == 404
