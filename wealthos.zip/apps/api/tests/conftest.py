"""
Shared pytest fixtures. Spins up a throwaway Postgres via Testcontainers,
runs Alembic migrations against it, and yields an httpx AsyncClient wired to
the FastAPI app so tests hit real endpoints against a real (ephemeral) DB —
this is what makes the RLS/authorization tests in
test_auth_and_transactions.py meaningful rather than mocked.
"""
import asyncio
import os

import pytest
import pytest_asyncio
from alembic import command
from alembic.config import Config
from httpx import ASGITransport, AsyncClient
from testcontainers.postgres import PostgresContainer


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="session")
def postgres_container():
    with PostgresContainer("postgres:16") as container:
        yield container


@pytest.fixture(scope="session", autouse=True)
def apply_migrations(postgres_container):
    db_url = postgres_container.get_connection_url().replace("psycopg2", "asyncpg")
    os.environ["DATABASE_URL"] = db_url

    alembic_cfg = Config("alembic.ini")
    alembic_cfg.set_main_option("sqlalchemy.url", db_url)
    command.upgrade(alembic_cfg, "head")
    yield


@pytest_asyncio.fixture
async def client():
    # Imported after DATABASE_URL is set so app.core.config picks up the test DB.
    from app.main import app

    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac
