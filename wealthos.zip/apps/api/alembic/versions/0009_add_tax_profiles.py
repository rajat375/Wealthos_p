"""add tax_profiles

Revision ID: 0009
Revises: 0008
Create Date: 2026-07-10
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0009"
down_revision = "0008"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "tax_profiles",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("financial_year", sa.String(9), nullable=False),
        sa.Column("regime", sa.String(10), nullable=False, server_default="new"),
        sa.Column("gross_income", sa.Numeric(18, 2)),
        sa.Column("deductions", pg.JSONB, nullable=False, server_default="{}"),
        sa.Column("estimated_tax", sa.Numeric(18, 2)),
        sa.UniqueConstraint("user_id", "financial_year", name="uq_tax_profile_year"),
    )

    op.execute("ALTER TABLE tax_profiles ENABLE ROW LEVEL SECURITY")
    op.execute(
        "CREATE POLICY user_isolation_tax_profiles ON tax_profiles "
        "USING (user_id = current_setting('app.current_user_id', true)::uuid)"
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS tax_profiles CASCADE")
