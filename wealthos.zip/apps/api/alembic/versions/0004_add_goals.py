"""add goals, goal_contributions

Revision ID: 0004
Revises: 0003
Create Date: 2026-07-10
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "goals",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("goal_type", sa.String(30), nullable=False),
        sa.Column("name", sa.String(150), nullable=False),
        sa.Column("target_amount", sa.Numeric(18, 2), nullable=False),
        sa.Column("current_amount", sa.Numeric(18, 2), nullable=False, server_default="0"),
        sa.Column("target_date", sa.Date),
        sa.Column("linked_account_id", pg.UUID(as_uuid=True), sa.ForeignKey("accounts.id")),
        sa.Column("status", sa.String(20), nullable=False, server_default="active"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.CheckConstraint(
            "goal_type IN ('emergency_fund','house','car','vacation','retirement','child_education','custom')",
            name="ck_goal_type",
        ),
        sa.CheckConstraint(
            "status IN ('active','completed','paused','cancelled')", name="ck_goal_status"
        ),
    )
    op.create_index("idx_goals_user", "goals", ["user_id"])

    op.create_table(
        "goal_contributions",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("goal_id", pg.UUID(as_uuid=True), sa.ForeignKey("goals.id", ondelete="CASCADE"), nullable=False),
        sa.Column("transaction_id", pg.UUID(as_uuid=True), sa.ForeignKey("transactions.id", ondelete="SET NULL")),
        sa.Column("amount", sa.Numeric(18, 2), nullable=False),
        sa.Column("contributed_at", sa.Date, nullable=False, server_default=sa.text("CURRENT_DATE")),
    )
    op.create_index("idx_goal_contrib_goal", "goal_contributions", ["goal_id"])

    # Now that `goals` exists, wire up the FK that transactions.goal_id has
    # been holding as a bare (unconstrained) UUID column since migration 0001.
    op.create_foreign_key(
        "fk_txn_goal", "transactions", "goals", ["goal_id"], ["id"], ondelete="SET NULL"
    )

    op.execute(
        "CREATE TRIGGER trg_goals_updated_at BEFORE UPDATE ON goals FOR EACH ROW EXECUTE FUNCTION set_updated_at();"
    )

    op.execute(
        """
        CREATE OR REPLACE FUNCTION apply_goal_contribution() RETURNS TRIGGER AS $$
        BEGIN
            UPDATE goals SET current_amount = current_amount + NEW.amount, updated_at = now()
            WHERE id = NEW.goal_id;
            IF (SELECT current_amount >= target_amount FROM goals WHERE id = NEW.goal_id) THEN
                UPDATE goals SET status = 'completed' WHERE id = NEW.goal_id;
            END IF;
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
        """
    )
    op.execute(
        "CREATE TRIGGER trg_goal_contribution AFTER INSERT ON goal_contributions FOR EACH ROW "
        "EXECUTE FUNCTION apply_goal_contribution();"
    )

    op.execute("ALTER TABLE goals ENABLE ROW LEVEL SECURITY")
    op.execute(
        "CREATE POLICY user_isolation_goals ON goals "
        "USING (user_id = current_setting('app.current_user_id', true)::uuid)"
    )


def downgrade() -> None:
    op.drop_constraint("fk_txn_goal", "transactions", type_="foreignkey")
    op.execute("DROP TABLE IF EXISTS goal_contributions CASCADE")
    op.execute("DROP TABLE IF EXISTS goals CASCADE")
    op.execute("DROP FUNCTION IF EXISTS apply_goal_contribution CASCADE")
