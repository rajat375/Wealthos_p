"""add bills, bill_payments

Revision ID: 0006
Revises: 0005
Create Date: 2026-07-10
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0006"
down_revision = "0005"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "bills",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(150), nullable=False),
        sa.Column("amount", sa.Numeric(18, 2), nullable=False),
        sa.Column("due_date", sa.Date, nullable=False),
        sa.Column("frequency", sa.String(20), nullable=False, server_default="monthly"),
        sa.Column("category_id", pg.UUID(as_uuid=True), sa.ForeignKey("categories.id")),
        sa.Column("account_id", pg.UUID(as_uuid=True), sa.ForeignKey("accounts.id")),
        sa.Column("is_autopay", sa.Boolean, nullable=False, server_default="false"),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default="true"),
        sa.CheckConstraint("frequency IN ('weekly','monthly','quarterly','yearly')", name="ck_bill_frequency"),
    )
    op.create_index("idx_bills_due", "bills", ["user_id", "due_date"], postgresql_where=sa.text("is_active = true"))

    op.create_table(
        "bill_payments",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("bill_id", pg.UUID(as_uuid=True), sa.ForeignKey("bills.id", ondelete="CASCADE"), nullable=False),
        sa.Column("transaction_id", pg.UUID(as_uuid=True), sa.ForeignKey("transactions.id", ondelete="SET NULL")),
        sa.Column("paid_amount", sa.Numeric(18, 2), nullable=False),
        sa.Column("paid_date", sa.Date, nullable=False),
    )
    op.create_index("idx_bill_payments_bill", "bill_payments", ["bill_id"])

    op.execute("ALTER TABLE bills ENABLE ROW LEVEL SECURITY")
    op.execute(
        "CREATE POLICY user_isolation_bills ON bills "
        "USING (user_id = current_setting('app.current_user_id', true)::uuid)"
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS bill_payments CASCADE")
    op.execute("DROP TABLE IF EXISTS bills CASCADE")
