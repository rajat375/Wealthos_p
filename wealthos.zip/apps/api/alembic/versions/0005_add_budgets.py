"""add budgets, budget_items

Revision ID: 0005
Revises: 0004
Create Date: 2026-07-10
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "budgets",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("period_type", sa.String(10), nullable=False, server_default="monthly"),
        sa.Column("period_start", sa.Date, nullable=False),
        sa.Column("period_end", sa.Date, nullable=False),
        sa.Column("total_planned", sa.Numeric(18, 2)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.UniqueConstraint("user_id", "period_start", "period_end", name="uq_budget_period"),
        sa.CheckConstraint("period_type IN ('monthly','yearly')", name="ck_budget_period_type"),
    )

    op.create_table(
        "budget_items",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("budget_id", pg.UUID(as_uuid=True), sa.ForeignKey("budgets.id", ondelete="CASCADE"), nullable=False),
        sa.Column("category_id", pg.UUID(as_uuid=True), sa.ForeignKey("categories.id"), nullable=False),
        sa.Column("planned_amount", sa.Numeric(18, 2), nullable=False),
        sa.UniqueConstraint("budget_id", "category_id", name="uq_budget_item_category"),
    )
    op.create_index("idx_budget_items_budget", "budget_items", ["budget_id"])

    op.execute("ALTER TABLE budgets ENABLE ROW LEVEL SECURITY")
    op.execute(
        "CREATE POLICY user_isolation_budgets ON budgets "
        "USING (user_id = current_setting('app.current_user_id', true)::uuid)"
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS budget_items CASCADE")
    op.execute("DROP TABLE IF EXISTS budgets CASCADE")
