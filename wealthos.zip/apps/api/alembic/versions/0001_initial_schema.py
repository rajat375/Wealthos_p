"""initial schema: roles, users, sessions, audit_logs, accounts, categories, transactions

This migration covers the modules implemented in this scaffold. The full
schema for assets, liabilities, goals, budgets, bills, subscriptions,
insurance, tax, documents, notifications, and AI tables is specified in
docs/02-Database-Design.md and should be added as subsequent migrations,
one per module, as each is built out.

Revision ID: 0001
Revises:
Create Date: 2026-07-10
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute('CREATE EXTENSION IF NOT EXISTS "pgcrypto"')
    op.execute('CREATE EXTENSION IF NOT EXISTS "pg_trgm"')

    op.create_table(
        "roles",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("name", sa.String(50), nullable=False, unique=True),
        sa.Column("permissions", pg.JSONB, nullable=False, server_default="{}"),
    )

    op.create_table(
        "users",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("email", sa.String(255), nullable=False, unique=True),
        sa.Column("password_hash", sa.String(255)),
        sa.Column("full_name", sa.String(150), nullable=False),
        sa.Column("phone", sa.String(20)),
        sa.Column("auth_provider", sa.String(20), nullable=False, server_default="email"),
        sa.Column("google_id", sa.String(255), unique=True),
        sa.Column("is_verified", sa.Boolean, nullable=False, server_default="false"),
        sa.Column("two_factor_enabled", sa.Boolean, nullable=False, server_default="false"),
        sa.Column("two_factor_secret", sa.String(255)),
        sa.Column("base_currency", sa.String(3), nullable=False, server_default="INR"),
        sa.Column("country_code", sa.String(2), nullable=False, server_default="IN"),
        sa.Column("timezone", sa.String(50), nullable=False, server_default="Asia/Kolkata"),
        sa.Column("role_id", pg.UUID(as_uuid=True), sa.ForeignKey("roles.id"), nullable=False),
        sa.Column("plan_tier", sa.String(20), nullable=False, server_default="free"),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default="true"),
        sa.Column("last_login_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("deleted_at", sa.DateTime(timezone=True)),
    )
    op.create_index("idx_users_email", "users", ["email"], postgresql_where=sa.text("deleted_at IS NULL"))

    op.create_table(
        "sessions",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("refresh_token_hash", sa.String(255), nullable=False),
        sa.Column("user_agent", sa.String(255)),
        sa.Column("ip_address", sa.String(45)),
        sa.Column("is_revoked", sa.Boolean, nullable=False, server_default="false"),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("idx_sessions_user", "sessions", ["user_id"])
    op.create_index("idx_sessions_token", "sessions", ["refresh_token_hash"])

    op.create_table(
        "audit_logs",
        sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="SET NULL")),
        sa.Column("action", sa.String(100), nullable=False),
        sa.Column("entity_type", sa.String(50)),
        sa.Column("entity_id", pg.UUID(as_uuid=True)),
        sa.Column("ip_address", sa.String(45)),
        sa.Column("user_agent", sa.String(255)),
        sa.Column("metadata", pg.JSONB),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("idx_audit_user_date", "audit_logs", ["user_id", "created_at"])

    op.create_table(
        "accounts",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("account_type", sa.String(30), nullable=False),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("institution_name", sa.String(100)),
        sa.Column("account_number_last4", sa.String(4)),
        sa.Column("current_balance", sa.Numeric(18, 2), nullable=False, server_default="0"),
        sa.Column("credit_limit", sa.Numeric(18, 2)),
        sa.Column("currency", sa.String(3), nullable=False, server_default="INR"),
        sa.Column("source", sa.String(20), nullable=False, server_default="manual"),
        sa.Column("external_account_id", sa.String(255)),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.CheckConstraint(
            "account_type IN ('bank_savings','bank_current','cash_wallet','credit_card')",
            name="ck_accounts_type",
        ),
    )
    op.create_index("idx_accounts_user", "accounts", ["user_id"], postgresql_where=sa.text("is_active = true"))

    op.create_table(
        "categories",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE")),
        sa.Column("parent_id", pg.UUID(as_uuid=True), sa.ForeignKey("categories.id", ondelete="CASCADE")),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("type", sa.String(10), nullable=False),
        sa.Column("icon", sa.String(50)),
        sa.Column("color", sa.String(7)),
        sa.Column("is_system_default", sa.Boolean, nullable=False, server_default="false"),
        sa.CheckConstraint("type IN ('income','expense')", name="ck_categories_type"),
    )
    op.create_index("idx_categories_user", "categories", ["user_id"])

    op.create_table(
        "transactions",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("account_id", pg.UUID(as_uuid=True), sa.ForeignKey("accounts.id", ondelete="CASCADE"), nullable=False),
        sa.Column("category_id", pg.UUID(as_uuid=True), sa.ForeignKey("categories.id")),
        sa.Column("type", sa.String(10), nullable=False),
        sa.Column("income_source", sa.String(30)),
        sa.Column("amount", sa.Numeric(18, 2), nullable=False),
        sa.Column("currency", sa.String(3), nullable=False, server_default="INR"),
        sa.Column("transaction_date", sa.Date, nullable=False),
        sa.Column("merchant", sa.String(150)),
        sa.Column("notes", sa.Text),
        sa.Column("is_recurring", sa.Boolean, nullable=False, server_default="false"),
        sa.Column("recurring_id", pg.UUID(as_uuid=True)),
        sa.Column("goal_id", pg.UUID(as_uuid=True)),
        sa.Column("transfer_account_id", pg.UUID(as_uuid=True), sa.ForeignKey("accounts.id")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("deleted_at", sa.DateTime(timezone=True)),
        sa.CheckConstraint("type IN ('income','expense','transfer')", name="ck_txn_type"),
        sa.CheckConstraint("amount > 0", name="ck_txn_amount_positive"),
    )
    op.create_index("idx_txn_user_date", "transactions", ["user_id", "transaction_date"], postgresql_where=sa.text("deleted_at IS NULL"))
    op.create_index("idx_txn_account", "transactions", ["account_id"])
    op.create_index("idx_txn_category", "transactions", ["category_id"])
    op.execute("CREATE INDEX idx_txn_notes_trgm ON transactions USING gin (notes gin_trgm_ops)")

    # --- updated_at triggers ---
    op.execute(
        """
        CREATE OR REPLACE FUNCTION set_updated_at() RETURNS TRIGGER AS $$
        BEGIN NEW.updated_at = now(); RETURN NEW; END;
        $$ LANGUAGE plpgsql;
        """
    )
    for table in ("users", "accounts", "transactions"):
        op.execute(
            f"CREATE TRIGGER trg_{table}_updated_at BEFORE UPDATE ON {table} "
            f"FOR EACH ROW EXECUTE FUNCTION set_updated_at();"
        )

    # --- balance-sync trigger (see docs/02-Database-Design.md §3) ---
    op.execute(
        """
        CREATE OR REPLACE FUNCTION apply_transaction_to_balance() RETURNS TRIGGER AS $$
        BEGIN
            IF TG_OP = 'INSERT' THEN
                IF NEW.type = 'income' THEN
                    UPDATE accounts SET current_balance = current_balance + NEW.amount WHERE id = NEW.account_id;
                ELSIF NEW.type = 'expense' THEN
                    UPDATE accounts SET current_balance = current_balance - NEW.amount WHERE id = NEW.account_id;
                ELSIF NEW.type = 'transfer' THEN
                    UPDATE accounts SET current_balance = current_balance - NEW.amount WHERE id = NEW.account_id;
                    UPDATE accounts SET current_balance = current_balance + NEW.amount WHERE id = NEW.transfer_account_id;
                END IF;
            ELSIF TG_OP = 'DELETE' THEN
                IF OLD.type = 'income' THEN
                    UPDATE accounts SET current_balance = current_balance - OLD.amount WHERE id = OLD.account_id;
                ELSIF OLD.type = 'expense' THEN
                    UPDATE accounts SET current_balance = current_balance + OLD.amount WHERE id = OLD.account_id;
                ELSIF OLD.type = 'transfer' THEN
                    UPDATE accounts SET current_balance = current_balance + OLD.amount WHERE id = OLD.account_id;
                    UPDATE accounts SET current_balance = current_balance - OLD.amount WHERE id = OLD.transfer_account_id;
                END IF;
            END IF;
            RETURN NULL;
        END;
        $$ LANGUAGE plpgsql;
        """
    )
    op.execute(
        "CREATE TRIGGER trg_txn_balance_insert AFTER INSERT ON transactions FOR EACH ROW "
        "WHEN (NEW.deleted_at IS NULL) EXECUTE FUNCTION apply_transaction_to_balance();"
    )
    op.execute(
        "CREATE TRIGGER trg_txn_balance_delete AFTER DELETE ON transactions FOR EACH ROW "
        "EXECUTE FUNCTION apply_transaction_to_balance();"
    )

    # --- Row Level Security ---
    for table in ("accounts", "transactions", "categories"):
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
    op.execute(
        "CREATE POLICY user_isolation_accounts ON accounts "
        "USING (user_id = current_setting('app.current_user_id', true)::uuid)"
    )
    op.execute(
        "CREATE POLICY user_isolation_txn ON transactions "
        "USING (user_id = current_setting('app.current_user_id', true)::uuid)"
    )
    op.execute(
        "CREATE POLICY user_isolation_categories ON categories "
        "USING (user_id IS NULL OR user_id = current_setting('app.current_user_id', true)::uuid)"
    )

    # --- Seed data: default role + system default categories ---
    op.execute(
        "INSERT INTO roles (name, permissions) VALUES "
        "('owner', '{\"*\": true}'), ('member', '{}'), ('viewer', '{}')"
    )
    op.execute(
        """
        INSERT INTO categories (name, type, is_system_default) VALUES
        ('Salary', 'income', true), ('Freelance', 'income', true),
        ('Rental Income', 'income', true), ('Dividend', 'income', true),
        ('Interest', 'income', true), ('Other Income', 'income', true),
        ('Food & Dining', 'expense', true), ('Groceries', 'expense', true),
        ('Transportation', 'expense', true), ('Utilities', 'expense', true),
        ('Rent', 'expense', true), ('Shopping', 'expense', true),
        ('Healthcare', 'expense', true), ('Entertainment', 'expense', true),
        ('Insurance', 'expense', true), ('Education', 'expense', true),
        ('Travel', 'expense', true), ('Other Expense', 'expense', true)
        """
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS transactions CASCADE")
    op.execute("DROP TABLE IF EXISTS categories CASCADE")
    op.execute("DROP TABLE IF EXISTS accounts CASCADE")
    op.execute("DROP TABLE IF EXISTS audit_logs CASCADE")
    op.execute("DROP TABLE IF EXISTS sessions CASCADE")
    op.execute("DROP TABLE IF EXISTS users CASCADE")
    op.execute("DROP TABLE IF EXISTS roles CASCADE")
    op.execute("DROP FUNCTION IF EXISTS apply_transaction_to_balance CASCADE")
    op.execute("DROP FUNCTION IF EXISTS set_updated_at CASCADE")
