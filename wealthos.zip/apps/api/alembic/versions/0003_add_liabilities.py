"""add liabilities, liability_types, loan_payments

Revision ID: 0003
Revises: 0002
Create Date: 2026-07-10
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "liability_types",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("code", sa.String(30), nullable=False, unique=True),
        sa.Column("label", sa.String(100), nullable=False),
    )

    op.create_table(
        "liabilities",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("liability_type_id", pg.UUID(as_uuid=True), sa.ForeignKey("liability_types.id"), nullable=False),
        sa.Column("name", sa.String(150), nullable=False),
        sa.Column("lender", sa.String(150)),
        sa.Column("principal_amount", sa.Numeric(18, 2), nullable=False),
        sa.Column("outstanding_amount", sa.Numeric(18, 2), nullable=False),
        sa.Column("interest_rate", sa.Numeric(5, 2)),
        sa.Column("emi_amount", sa.Numeric(18, 2)),
        sa.Column("tenure_months", sa.Integer),
        sa.Column("start_date", sa.Date),
        sa.Column("end_date", sa.Date),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.CheckConstraint("outstanding_amount >= 0", name="ck_liability_outstanding_nonneg"),
    )
    op.create_index("idx_liabilities_user", "liabilities", ["user_id"], postgresql_where=sa.text("is_active = true"))

    op.create_table(
        "loan_payments",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("liability_id", pg.UUID(as_uuid=True), sa.ForeignKey("liabilities.id", ondelete="CASCADE"), nullable=False),
        sa.Column("amount", sa.Numeric(18, 2), nullable=False),
        sa.Column("principal_component", sa.Numeric(18, 2)),
        sa.Column("interest_component", sa.Numeric(18, 2)),
        sa.Column("payment_date", sa.Date, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("idx_loan_payments_liability", "loan_payments", ["liability_id", "payment_date"])

    op.execute(
        """
        CREATE OR REPLACE FUNCTION apply_loan_payment() RETURNS TRIGGER AS $$
        BEGIN
            UPDATE liabilities
            SET outstanding_amount = GREATEST(outstanding_amount - COALESCE(NEW.principal_component, 0), 0)
            WHERE id = NEW.liability_id;
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
        """
    )
    op.execute(
        "CREATE TRIGGER trg_loan_payment AFTER INSERT ON loan_payments FOR EACH ROW "
        "EXECUTE FUNCTION apply_loan_payment();"
    )

    op.execute("ALTER TABLE liabilities ENABLE ROW LEVEL SECURITY")
    op.execute(
        "CREATE POLICY user_isolation_liabilities ON liabilities "
        "USING (user_id = current_setting('app.current_user_id', true)::uuid)"
    )

    op.execute(
        """
        INSERT INTO liability_types (code, label) VALUES
        ('home_loan', 'Home Loan'), ('personal_loan', 'Personal Loan'),
        ('education_loan', 'Education Loan'), ('car_loan', 'Car Loan'),
        ('credit_card_debt', 'Credit Card Debt'), ('other', 'Other Loans')
        """
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS loan_payments CASCADE")
    op.execute("DROP TABLE IF EXISTS liabilities CASCADE")
    op.execute("DROP TABLE IF EXISTS liability_types CASCADE")
    op.execute("DROP FUNCTION IF EXISTS apply_loan_payment CASCADE")
