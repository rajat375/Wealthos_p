"""add ai_insights, financial_health_scores

Revision ID: 0012
Revises: 0011
Create Date: 2026-07-10
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0012"
down_revision = "0011"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "ai_insights",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("insight_type", sa.String(50), nullable=False),
        sa.Column("period_start", sa.Date),
        sa.Column("period_end", sa.Date),
        sa.Column("content", pg.JSONB, nullable=False),
        sa.Column("is_dismissed", sa.Boolean, nullable=False, server_default="false"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("idx_ai_insights_user_date", "ai_insights", ["user_id", "created_at"])

    op.create_table(
        "financial_health_scores",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("score", sa.Integer, nullable=False),
        sa.Column("components", pg.JSONB, nullable=False),
        sa.Column("calculated_at", sa.Date, nullable=False, server_default=sa.text("CURRENT_DATE")),
        sa.UniqueConstraint("user_id", "calculated_at", name="uq_health_score_date"),
        sa.CheckConstraint("score BETWEEN 0 AND 100", name="ck_health_score_range"),
    )

    for table in ("ai_insights", "financial_health_scores"):
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
    op.execute(
        "CREATE POLICY user_isolation_ai_insights ON ai_insights "
        "USING (user_id = current_setting('app.current_user_id', true)::uuid)"
    )
    op.execute(
        "CREATE POLICY user_isolation_health_scores ON financial_health_scores "
        "USING (user_id = current_setting('app.current_user_id', true)::uuid)"
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS financial_health_scores CASCADE")
    op.execute("DROP TABLE IF EXISTS ai_insights CASCADE")
