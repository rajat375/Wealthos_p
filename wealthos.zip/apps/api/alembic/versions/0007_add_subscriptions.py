"""add subscriptions

Revision ID: 0007
Revises: 0006
Create Date: 2026-07-10
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0007"
down_revision = "0006"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "subscriptions",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(150), nullable=False),
        sa.Column("amount", sa.Numeric(18, 2), nullable=False),
        sa.Column("billing_cycle", sa.String(20), nullable=False, server_default="monthly"),
        sa.Column("next_billing_date", sa.Date),
        sa.Column("category_id", pg.UUID(as_uuid=True), sa.ForeignKey("categories.id")),
        sa.Column("account_id", pg.UUID(as_uuid=True), sa.ForeignKey("accounts.id")),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default="true"),
        sa.Column("cancel_url", sa.String(500)),
        sa.CheckConstraint("billing_cycle IN ('weekly','monthly','yearly')", name="ck_subscription_cycle"),
    )
    op.create_index(
        "idx_subs_user", "subscriptions", ["user_id"], postgresql_where=sa.text("is_active = true")
    )

    op.execute("ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY")
    op.execute(
        "CREATE POLICY user_isolation_subscriptions ON subscriptions "
        "USING (user_id = current_setting('app.current_user_id', true)::uuid)"
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS subscriptions CASCADE")
