"""add documents

Revision ID: 0010
Revises: 0009
Create Date: 2026-07-10
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0010"
down_revision = "0009"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "documents",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("title", sa.String(200), nullable=False),
        sa.Column("doc_type", sa.String(50)),
        sa.Column("file_url", sa.String(500), nullable=False),
        sa.Column("file_size_kb", sa.Integer),
        sa.Column("linked_entity_type", sa.String(30)),
        sa.Column("linked_entity_id", pg.UUID(as_uuid=True)),
        sa.Column("expiry_date", sa.Date),
        sa.Column("is_encrypted", sa.Boolean, nullable=False, server_default="true"),
        sa.Column("uploaded_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("idx_documents_user", "documents", ["user_id"])
    op.create_index("idx_documents_linked", "documents", ["linked_entity_type", "linked_entity_id"])

    op.execute("ALTER TABLE documents ENABLE ROW LEVEL SECURITY")
    op.execute(
        "CREATE POLICY user_isolation_documents ON documents "
        "USING (user_id = current_setting('app.current_user_id', true)::uuid)"
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS documents CASCADE")
