"""add insurance_policies

Revision ID: 0008
Revises: 0007
Create Date: 2026-07-10
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0008"
down_revision = "0007"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "insurance_policies",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("policy_type", sa.String(30), nullable=False),
        sa.Column("provider", sa.String(150)),
        sa.Column("policy_number", sa.String(100)),
        sa.Column("sum_assured", sa.Numeric(18, 2)),
        sa.Column("premium_amount", sa.Numeric(18, 2)),
        sa.Column("premium_frequency", sa.String(20), nullable=False, server_default="yearly"),
        sa.Column("start_date", sa.Date),
        sa.Column("renewal_date", sa.Date),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default="true"),
        sa.CheckConstraint(
            "policy_type IN ('life','health','vehicle','home','term','other')", name="ck_policy_type"
        ),
    )
    op.create_index("idx_insurance_user", "insurance_policies", ["user_id"])

    op.execute("ALTER TABLE insurance_policies ENABLE ROW LEVEL SECURITY")
    op.execute(
        "CREATE POLICY user_isolation_insurance ON insurance_policies "
        "USING (user_id = current_setting('app.current_user_id', true)::uuid)"
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS insurance_policies CASCADE")
