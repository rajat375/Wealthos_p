"""add assets, asset_types, asset_valuations

Revision ID: 0002
Revises: 0001
Create Date: 2026-07-10
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "asset_types",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("code", sa.String(30), nullable=False, unique=True),
        sa.Column("label", sa.String(100), nullable=False),
        sa.Column("category", sa.String(20), nullable=False),
    )

    op.create_table(
        "assets",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", pg.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("asset_type_id", pg.UUID(as_uuid=True), sa.ForeignKey("asset_types.id"), nullable=False),
        sa.Column("name", sa.String(150), nullable=False),
        sa.Column("quantity", sa.Numeric(18, 4)),
        sa.Column("purchase_value", sa.Numeric(18, 2)),
        sa.Column("current_value", sa.Numeric(18, 2), nullable=False),
        sa.Column("purchase_date", sa.Date),
        sa.Column("maturity_date", sa.Date),
        sa.Column("interest_rate", sa.Numeric(5, 2)),
        sa.Column("institution", sa.String(150)),
        sa.Column("metadata", pg.JSONB, nullable=False, server_default="{}"),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("idx_assets_user", "assets", ["user_id"], postgresql_where=sa.text("is_active = true"))
    op.create_index("idx_assets_type", "assets", ["asset_type_id"])

    op.create_table(
        "asset_valuations",
        sa.Column("id", pg.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("asset_id", pg.UUID(as_uuid=True), sa.ForeignKey("assets.id", ondelete="CASCADE"), nullable=False),
        sa.Column("value", sa.Numeric(18, 2), nullable=False),
        sa.Column("valued_at", sa.Date, nullable=False),
        sa.Column("source", sa.String(20), nullable=False, server_default="manual"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
        sa.UniqueConstraint("asset_id", "valued_at", name="uq_asset_valuation_per_day"),
    )
    op.create_index("idx_valuations_asset_date", "asset_valuations", ["asset_id", "valued_at"])

    op.execute("CREATE TRIGGER trg_assets_updated_at BEFORE UPDATE ON assets FOR EACH ROW EXECUTE FUNCTION set_updated_at();")

    op.execute("ALTER TABLE assets ENABLE ROW LEVEL SECURITY")
    op.execute(
        "CREATE POLICY user_isolation_assets ON assets "
        "USING (user_id = current_setting('app.current_user_id', true)::uuid)"
    )

    op.execute(
        """
        INSERT INTO asset_types (code, label, category) VALUES
        ('mutual_fund', 'Mutual Funds', 'investment'),
        ('stock', 'Stocks', 'investment'),
        ('gold', 'Gold', 'physical'),
        ('silver', 'Silver', 'physical'),
        ('fd', 'Fixed Deposits', 'investment'),
        ('ppf', 'PPF', 'retirement'),
        ('epf', 'EPF', 'retirement'),
        ('nps', 'NPS', 'retirement'),
        ('real_estate', 'Real Estate', 'physical'),
        ('crypto', 'Crypto', 'investment'),
        ('bond', 'Bonds', 'investment'),
        ('vehicle', 'Vehicles', 'physical'),
        ('other', 'Other Assets', 'other')
        """
    )


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS asset_valuations CASCADE")
    op.execute("DROP TABLE IF EXISTS assets CASCADE")
    op.execute("DROP TABLE IF EXISTS asset_types CASCADE")
