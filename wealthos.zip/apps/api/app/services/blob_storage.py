"""
Storage abstraction for the Document Vault (and, later, transaction
receipts). Everything else in the app talks to `upload()` and
`generate_download_url()` below — never to Azure Blob or the filesystem
directly — so swapping providers only touches this file.

See docs/05-Security-Design.md §4: documents are stored in a private
container (never public) and downloaded via short-lived SAS tokens, never a
permanent public URL.

This scaffold ships a local-disk implementation so the app runs without
Azure credentials in development. When AZURE_STORAGE_CONNECTION_STRING is
set, swap in the azure-storage-blob SDK implementation noted below.
"""
import os
import uuid
from pathlib import Path

from app.core.config import settings

_LOCAL_STORAGE_ROOT = Path("/tmp/wealthos-documents")


class StorageError(Exception):
    pass


async def upload(user_id: str, filename: str, content: bytes) -> tuple[str, int]:
    """Stores a file and returns (file_url, size_kb).

    `file_url` is an opaque storage key in this local implementation, not a
    publicly resolvable URL — `generate_download_url()` is required to
    actually retrieve the file, matching how the Azure Blob version (private
    container + SAS token) will behave.
    """
    if settings.AZURE_STORAGE_CONNECTION_STRING:
        raise StorageError(
            "AZURE_STORAGE_CONNECTION_STRING is set but the Azure Blob backend "
            "isn't wired up in this scaffold yet. Implement upload()/"
            "generate_download_url() here using azure-storage-blob's "
            "BlobServiceClient, uploading to settings.AZURE_STORAGE_CONTAINER "
            "and generating a user_delegation_sas / SAS token with a short "
            "expiry for downloads (see docs/05-Security-Design.md §4)."
        )

    user_dir = _LOCAL_STORAGE_ROOT / user_id
    user_dir.mkdir(parents=True, exist_ok=True)
    key = f"{uuid.uuid4()}_{filename}"
    (user_dir / key).write_bytes(content)
    return f"local://{user_id}/{key}", len(content) // 1024


async def generate_download_url(file_url: str, expires_in_seconds: int = 300) -> str:
    """Returns a short-lived download URL for a previously uploaded file.

    In the local backend this just points back at a signed local-serving
    endpoint (not implemented as a route in this scaffold — see TODO below);
    in the Azure backend this generates a SAS URL directly against Blob
    Storage with `expires_in_seconds` validity, so the API server itself
    never proxies file bytes.
    """
    if settings.AZURE_STORAGE_CONNECTION_STRING:
        raise StorageError("Azure Blob backend not wired up — see upload() docstring.")

    # TODO: add a GET /documents/{id}/raw route that checks ownership and
    # streams from _LOCAL_STORAGE_ROOT for local development only; never do
    # this in production (that's exactly what SAS tokens exist to avoid).
    return file_url
