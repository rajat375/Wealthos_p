import uuid
from datetime import date

from sqlalchemy import Boolean, Date, ForeignKey, Integer, Numeric, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.mixins import UUIDPKMixin


class LiabilityType(Base, UUIDPKMixin):
    __tablename__ = "liability_types"

    code: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    label: Mapped[str] = mapped_column(String(100), nullable=False)


class Liability(Base, UUIDPKMixin):
    __tablename__ = "liabilities"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    liability_type_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("liability_types.id"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    lender: Mapped[str | None] = mapped_column(String(150))
    principal_amount: Mapped[float] = mapped_column(Numeric(18, 2), nullable=False)
    outstanding_amount: Mapped[float] = mapped_column(Numeric(18, 2), nullable=False)
    interest_rate: Mapped[float | None] = mapped_column(Numeric(5, 2))
    emi_amount: Mapped[float | None] = mapped_column(Numeric(18, 2))
    tenure_months: Mapped[int | None] = mapped_column(Integer)
    start_date: Mapped[date | None] = mapped_column(Date)
    end_date: Mapped[date | None] = mapped_column(Date)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class LoanPayment(Base, UUIDPKMixin):
    __tablename__ = "loan_payments"

    liability_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("liabilities.id", ondelete="CASCADE"), nullable=False, index=True
    )
    amount: Mapped[float] = mapped_column(Numeric(18, 2), nullable=False)
    principal_component: Mapped[float | None] = mapped_column(Numeric(18, 2))
    interest_component: Mapped[float | None] = mapped_column(Numeric(18, 2))
    payment_date: Mapped[date] = mapped_column(Date, nullable=False)
