import uuid
from datetime import date, datetime

from sqlalchemy import Boolean, Date, DateTime, ForeignKey, Integer, String, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.mixins import UUIDPKMixin


class Document(Base, UUIDPKMixin):
    __tablename__ = "documents"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    doc_type: Mapped[str | None] = mapped_column(String(50))  # insurance|loan|tax|identity|other
    file_url: Mapped[str] = mapped_column(String(500), nullable=False)
    file_size_kb: Mapped[int | None] = mapped_column(Integer)
    linked_entity_type: Mapped[str | None] = mapped_column(String(30))  # asset|liability|insurance_policy
    linked_entity_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True))
    expiry_date: Mapped[date | None] = mapped_column(Date)
    is_encrypted: Mapped[bool] = mapped_column(Boolean, default=True)
    uploaded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
