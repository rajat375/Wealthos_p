import uuid
from datetime import date

from sqlalchemy import Date, ForeignKey, Numeric, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.mixins import UUIDPKMixin


class Budget(Base, UUIDPKMixin):
    __tablename__ = "budgets"
    __table_args__ = (UniqueConstraint("user_id", "period_start", "period_end", name="uq_budget_period"),)

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    period_type: Mapped[str] = mapped_column(String(10), default="monthly")
    period_start: Mapped[date] = mapped_column(Date, nullable=False)
    period_end: Mapped[date] = mapped_column(Date, nullable=False)
    total_planned: Mapped[float | None] = mapped_column(Numeric(18, 2))


class BudgetItem(Base, UUIDPKMixin):
    __tablename__ = "budget_items"
    __table_args__ = (UniqueConstraint("budget_id", "category_id", name="uq_budget_item_category"),)

    budget_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("budgets.id", ondelete="CASCADE"), nullable=False, index=True
    )
    category_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("categories.id"), nullable=False)
    planned_amount: Mapped[float] = mapped_column(Numeric(18, 2), nullable=False)
