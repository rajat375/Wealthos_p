import uuid

from sqlalchemy import ForeignKey, Numeric, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.mixins import UUIDPKMixin


class TaxProfile(Base, UUIDPKMixin):
    __tablename__ = "tax_profiles"
    __table_args__ = (UniqueConstraint("user_id", "financial_year", name="uq_tax_profile_year"),)

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    financial_year: Mapped[str] = mapped_column(String(9), nullable=False)  # e.g. '2025-2026'
    regime: Mapped[str] = mapped_column(String(10), default="new")
    gross_income: Mapped[float | None] = mapped_column(Numeric(18, 2))
    deductions: Mapped[dict] = mapped_column(JSONB, default=dict)  # {"80C": 150000, "80D": 25000, ...}
    estimated_tax: Mapped[float | None] = mapped_column(Numeric(18, 2))
