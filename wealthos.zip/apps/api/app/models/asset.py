import uuid
from datetime import date

from sqlalchemy import Boolean, Date, ForeignKey, Numeric, String
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.mixins import TimestampMixin, UUIDPKMixin


class AssetType(Base, UUIDPKMixin):
    __tablename__ = "asset_types"

    code: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    label: Mapped[str] = mapped_column(String(100), nullable=False)
    category: Mapped[str] = mapped_column(String(20), nullable=False)


class Asset(Base, UUIDPKMixin, TimestampMixin):
    __tablename__ = "assets"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    asset_type_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("asset_types.id"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    quantity: Mapped[float | None] = mapped_column(Numeric(18, 4))
    purchase_value: Mapped[float | None] = mapped_column(Numeric(18, 2))
    current_value: Mapped[float] = mapped_column(Numeric(18, 2), nullable=False)
    purchase_date: Mapped[date | None] = mapped_column(Date)
    maturity_date: Mapped[date | None] = mapped_column(Date)
    interest_rate: Mapped[float | None] = mapped_column(Numeric(5, 2))
    institution: Mapped[str | None] = mapped_column(String(150))
    metadata_json: Mapped[dict] = mapped_column("metadata", JSONB, default=dict)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class AssetValuation(Base, UUIDPKMixin):
    __tablename__ = "asset_valuations"

    asset_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("assets.id", ondelete="CASCADE"), nullable=False, index=True
    )
    value: Mapped[float] = mapped_column(Numeric(18, 2), nullable=False)
    valued_at: Mapped[date] = mapped_column(Date, nullable=False)
    source: Mapped[str] = mapped_column(String(20), default="manual")
