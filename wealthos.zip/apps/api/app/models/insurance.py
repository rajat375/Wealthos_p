import uuid
from datetime import date

from sqlalchemy import Boolean, Date, ForeignKey, Numeric, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.mixins import UUIDPKMixin


class InsurancePolicy(Base, UUIDPKMixin):
    __tablename__ = "insurance_policies"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    policy_type: Mapped[str] = mapped_column(String(30), nullable=False)
    provider: Mapped[str | None] = mapped_column(String(150))
    policy_number: Mapped[str | None] = mapped_column(String(100))
    sum_assured: Mapped[float | None] = mapped_column(Numeric(18, 2))
    premium_amount: Mapped[float | None] = mapped_column(Numeric(18, 2))
    premium_frequency: Mapped[str] = mapped_column(String(20), default="yearly")
    start_date: Mapped[date | None] = mapped_column(Date)
    renewal_date: Mapped[date | None] = mapped_column(Date)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
