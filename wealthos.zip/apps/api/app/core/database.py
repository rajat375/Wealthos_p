from collections.abc import AsyncGenerator
from contextvars import ContextVar

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from app.core.config import settings

# Holds the current authenticated user's id for the duration of a request so it
# can be applied as a Postgres session variable, enabling Row Level Security
# policies (see docs/02-Database-Design.md §4) to isolate tenant data even if
# an application-layer check is ever missed.
current_user_id_ctx: ContextVar[str | None] = ContextVar("current_user_id", default=None)


class Base(DeclarativeBase):
    pass


engine = create_async_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20,
    echo=settings.ENVIRONMENT == "local",
)

AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    autoflush=False,
    autocommit=False,
    expire_on_commit=False,
)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency: yields a plain DB session.

    Note: RLS context (app.current_user_id) is NOT set here. Dependency
    resolution order means get_db's setup code would run before an auth
    dependency has decoded the token, so the context would always be empty
    at this point. Instead, `get_current_user` (app/api/deps.py) sets the
    context on this same session immediately after verifying the JWT, before
    any user-owned-table query runs. Endpoints that don't require auth never
    touch RLS-protected tables, so this ordering is safe.
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def set_rls_user(session: AsyncSession, user_id: str) -> None:
    """Applies the authenticated user's id to this transaction's Postgres
    session state so Row Level Security policies scope every subsequent
    query on this session to that user's rows."""
    await session.execute(
        text("SELECT set_config('app.current_user_id', :uid, true)"), {"uid": user_id}
    )
