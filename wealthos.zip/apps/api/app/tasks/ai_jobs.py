"""
AI background jobs:
- generate_monthly_financial_summary: aggregates prior month's income/expense/
  investment deltas into an anonymized JSON payload, sends it to the AI
  Gateway (app/ai/gateway.py), and stores the narrative result in
  `ai_insights`.
- recompute_financial_health_scores: recalculates each user's 0-100 score
  from savings rate, debt-to-income, and emergency-fund coverage, storing a
  daily snapshot in `financial_health_scores` for trend charts.

Both are stubbed pending the AI module (Sprint 10-12, see docs/07-Roadmap).
"""
from app.tasks.celery_app import celery_app


@celery_app.task(name="app.tasks.ai_jobs.generate_monthly_financial_summary")
def generate_monthly_financial_summary() -> str:
    # TODO: for each active user, aggregate last month's transactions/assets,
    # call app.ai.gateway.complete() with an anonymized JSON payload only
    # (never raw account numbers or notes — see docs/05-Security-Design.md §4),
    # and persist the response into `ai_insights`.
    return "generate_monthly_financial_summary: not yet implemented"


@celery_app.task(name="app.tasks.ai_jobs.recompute_financial_health_scores")
def recompute_financial_health_scores() -> str:
    # TODO: for each active user, compute score components (savings rate,
    # debt ratio, emergency fund months) and upsert into
    # `financial_health_scores` for the current date.
    return "recompute_financial_health_scores: not yet implemented"
