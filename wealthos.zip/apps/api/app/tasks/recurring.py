"""
Daily job: finds recurring_transactions whose next_run_date has arrived,
creates the corresponding transaction row (which fires the balance-sync
trigger automatically), and advances next_run_date per its frequency.

Implementation intentionally left as a stub in this scaffold — wire it to
`RecurringTransaction` model and an async SQLAlchemy session once that
module (Sprint 4, see docs/07-Roadmap) is built out.
"""
from app.tasks.celery_app import celery_app


@celery_app.task(name="app.tasks.recurring.materialize_due_recurring_transactions")
def materialize_due_recurring_transactions() -> str:
    # TODO: query recurring_transactions WHERE next_run_date <= today AND is_active,
    # create a Transaction for each, advance next_run_date by `frequency`.
    return "materialize_due_recurring_transactions: not yet implemented"
