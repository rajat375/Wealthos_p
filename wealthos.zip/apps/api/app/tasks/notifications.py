"""
Daily job: finds bills due within the reminder window and creates
in-app + email notifications. Stubbed pending the Bills module (Sprint 6).
"""
from app.tasks.celery_app import celery_app


@celery_app.task(name="app.tasks.notifications.send_upcoming_bill_reminders")
def send_upcoming_bill_reminders() -> str:
    # TODO: query bills WHERE due_date BETWEEN today AND today+3 AND is_active,
    # insert a `notifications` row per bill, dispatch email via SendGrid/ACS.
    return "send_upcoming_bill_reminders: not yet implemented"
