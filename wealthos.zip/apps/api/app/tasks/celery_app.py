"""
Celery application entrypoint. Wires up the task queue used for recurring
transaction materialization, bill reminders, AI monthly summaries, and
financial health score recomputation (see docs/07-Roadmap for the sprint
each task set lands in).
"""
from celery import Celery
from celery.schedules import crontab

from app.core.config import settings

celery_app = Celery(
    "wealthos",
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL,
    include=["app.tasks.recurring", "app.tasks.notifications", "app.tasks.ai_jobs"],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
)

celery_app.conf.beat_schedule = {
    "materialize-recurring-transactions-daily": {
        "task": "app.tasks.recurring.materialize_due_recurring_transactions",
        "schedule": crontab(hour=0, minute=5),
    },
    "send-bill-reminders-daily": {
        "task": "app.tasks.notifications.send_upcoming_bill_reminders",
        "schedule": crontab(hour=8, minute=0),
    },
    "generate-monthly-summary": {
        "task": "app.tasks.ai_jobs.generate_monthly_financial_summary",
        "schedule": crontab(day_of_month=1, hour=6, minute=0),
    },
    "recompute-health-scores-daily": {
        "task": "app.tasks.ai_jobs.recompute_financial_health_scores",
        "schedule": crontab(hour=2, minute=0),
    },
}
