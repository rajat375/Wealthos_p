"""
Natural Language Search (see docs/03-API-Documentation.md §15).

Flow: user question -> lightweight intent classification -> parameterized
data query (never raw SQL string interpolation of user input) -> aggregated
result -> AI Gateway composes a narrative answer citing the numbers.

This module is stubbed with a working end-to-end shape for the single most
common intent (category spend in a given month) so the pattern is clear;
additional intents (investment growth, highest expenses, net worth trend)
follow the same structure and are listed as TODOs.
"""
import re
from datetime import date

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.ai.gateway import complete
from app.models.category import Category
from app.models.transaction import Transaction

SYSTEM_PROMPT = (
    "You are WealthOS's financial assistant. You will be given a JSON object "
    "with pre-computed, aggregated financial figures for the user. Answer the "
    "user's question in one or two friendly sentences using ONLY the figures "
    "provided — never invent numbers. Do not restate the raw JSON."
)

_MONTH_CATEGORY_PATTERN = re.compile(
    r"spend.*on\s+(?P<category>[\w\s]+?)\s+in\s+(?P<month>\w+)", re.IGNORECASE
)


async def answer_query(db: AsyncSession, user_id: str, question: str) -> dict:
    match = _MONTH_CATEGORY_PATTERN.search(question)
    if not match:
        return {
            "answer": "I can currently answer questions like \"How much did I spend on food in May?\". "
                      "More question types are on the way — see docs/07-Roadmap-Sprints-Future.md.",
            "data": None,
        }

    category_name = match.group("category").strip()
    # In production, resolve `month` text -> a concrete date range via a small
    # month-name parser; omitted here for brevity.

    category_result = await db.execute(
        select(Category).where(func.lower(Category.name) == category_name.lower())
    )
    category = category_result.scalar_one_or_none()
    if not category:
        return {"answer": f"I couldn't find a category called \"{category_name}\".", "data": None}

    total_result = await db.execute(
        select(func.coalesce(func.sum(Transaction.amount), 0)).where(
            Transaction.user_id == user_id,
            Transaction.category_id == category.id,
            Transaction.type == "expense",
            Transaction.deleted_at.is_(None),
        )
    )
    total = float(total_result.scalar_one())

    aggregate_payload = {"category": category.name, "total": total, "as_of": date.today().isoformat()}

    narrative = await complete(
        system_prompt=SYSTEM_PROMPT,
        user_message=f"User question: {question}\nAggregated data: {aggregate_payload}",
    )

    return {"answer": narrative, "data": aggregate_payload}

    # TODO additional intents: investment growth ("Show my investment growth"),
    # highest expenses ("What are my highest expenses?"), net worth trend,
    # goal progress — each follows the same "classify -> aggregate -> narrate"
    # shape and should live in its own small handler function.
