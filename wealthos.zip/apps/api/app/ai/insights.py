"""
Overspending Detection: flags categories where this month's spend is
significantly above the user's own trailing 3-month average for that
category — a personalized baseline rather than an arbitrary threshold,
since "normal" spending varies enormously person to person.

Like health_score.py, the detection itself is deterministic (percentage
comparison) so it's reproducible and explainable; only the human-readable
framing of the alert is a candidate for the AI Gateway, and even that is
optional — see the `narrative` field's fallback below.
"""
from datetime import date
from decimal import Decimal

from dateutil.relativedelta import relativedelta
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.category import Category
from app.models.transaction import Transaction

OVERSPEND_THRESHOLD_PCT = 25  # flag if this month is 25%+ above the 3-month average


async def detect_overspending(db: AsyncSession, user_id) -> list[dict]:
    today = date.today()
    this_month_start = today.replace(day=1)
    baseline_start = this_month_start - relativedelta(months=3)
    baseline_end = this_month_start - relativedelta(days=1)

    this_month_result = await db.execute(
        select(Transaction.category_id, func.sum(Transaction.amount))
        .where(
            Transaction.user_id == user_id,
            Transaction.type == "expense",
            Transaction.transaction_date >= this_month_start,
            Transaction.deleted_at.is_(None),
        )
        .group_by(Transaction.category_id)
    )
    this_month = dict(this_month_result.all())

    baseline_result = await db.execute(
        select(Transaction.category_id, func.sum(Transaction.amount))
        .where(
            Transaction.user_id == user_id,
            Transaction.type == "expense",
            Transaction.transaction_date >= baseline_start,
            Transaction.transaction_date <= baseline_end,
            Transaction.deleted_at.is_(None),
        )
        .group_by(Transaction.category_id)
    )
    baseline_totals = dict(baseline_result.all())

    alerts = []
    for category_id, current_total in this_month.items():
        if category_id is None:
            continue
        baseline_total = baseline_totals.get(category_id)
        if not baseline_total:
            continue  # no baseline yet — nothing to compare against

        baseline_monthly_avg = Decimal(str(baseline_total)) / Decimal("3")
        if baseline_monthly_avg <= 0:
            continue

        delta_pct = float((Decimal(str(current_total)) - baseline_monthly_avg) / baseline_monthly_avg * 100)
        if delta_pct >= OVERSPEND_THRESHOLD_PCT:
            category = await db.get(Category, category_id)
            alerts.append(
                {
                    "category_id": str(category_id),
                    "category_name": category.name if category else "Unknown",
                    "current_month_total": float(current_total),
                    "baseline_monthly_avg": float(baseline_monthly_avg),
                    "delta_pct": round(delta_pct, 1),
                    "narrative": (
                        f"{category.name if category else 'This category'} spending is "
                        f"{round(delta_pct)}% above your usual monthly average this month."
                    ),
                }
            )

    return sorted(alerts, key=lambda a: a["delta_pct"], reverse=True)
