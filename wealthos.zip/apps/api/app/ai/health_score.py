"""
Financial Health Score: a 0-100 composite score computed from three
components, each scored 0-100 and weighted:

- savings_rate (40%): (income - expense) / income over the trailing month.
  Scored on a curve where 20%+ savings rate = 100, 0% or negative = 0.
- debt_to_income (30%): total monthly EMI/debt service vs. monthly income.
  Lower is better; 0% = 100, 50%+ = 0.
- emergency_fund_months (30%): liquid balance (bank + cash accounts) divided
  by average monthly expense, capped at 6 months = 100.

This is intentionally a transparent, rule-based score rather than an LLM
call — health scores need to be reproducible and explainable to the user,
which points at deterministic computation with the AI layer reserved for
the *narrative* around the score (see insights.py) rather than the number
itself.
"""
from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.account import Account
from app.models.liability import Liability
from app.models.transaction import Transaction


def _clamp(value: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, value))


async def compute_health_score(db: AsyncSession, user_id) -> dict:
    today = date.today()
    month_start = today.replace(day=1)
    trailing_90_start = today - timedelta(days=90)

    income_result = await db.execute(
        select(func.coalesce(func.sum(Transaction.amount), 0)).where(
            Transaction.user_id == user_id,
            Transaction.type == "income",
            Transaction.transaction_date >= month_start,
            Transaction.deleted_at.is_(None),
        )
    )
    expense_result = await db.execute(
        select(func.coalesce(func.sum(Transaction.amount), 0)).where(
            Transaction.user_id == user_id,
            Transaction.type == "expense",
            Transaction.transaction_date >= month_start,
            Transaction.deleted_at.is_(None),
        )
    )
    income = Decimal(str(income_result.scalar_one()))
    expense = Decimal(str(expense_result.scalar_one()))

    # --- Savings rate component ---
    if income > 0:
        savings_rate = float((income - expense) / income * 100)
    else:
        savings_rate = 0.0
    savings_component = _clamp(savings_rate / 20 * 100)  # 20% savings rate -> full marks

    # --- Debt-to-income component ---
    emi_result = await db.execute(
        select(func.coalesce(func.sum(Liability.emi_amount), 0)).where(
            Liability.user_id == user_id, Liability.is_active.is_(True)
        )
    )
    total_emi = Decimal(str(emi_result.scalar_one()))
    debt_to_income_pct = float(total_emi / income * 100) if income > 0 else 0.0
    debt_component = _clamp(100 - (debt_to_income_pct / 50 * 100))  # 50%+ DTI -> 0

    # --- Emergency fund component ---
    liquid_result = await db.execute(
        select(func.coalesce(func.sum(Account.current_balance), 0)).where(
            Account.user_id == user_id,
            Account.is_active.is_(True),
            Account.account_type.in_(["bank_savings", "bank_current", "cash_wallet"]),
        )
    )
    liquid_balance = Decimal(str(liquid_result.scalar_one()))

    avg_monthly_expense_result = await db.execute(
        select(func.coalesce(func.sum(Transaction.amount), 0)).where(
            Transaction.user_id == user_id,
            Transaction.type == "expense",
            Transaction.transaction_date >= trailing_90_start,
            Transaction.deleted_at.is_(None),
        )
    )
    avg_monthly_expense = Decimal(str(avg_monthly_expense_result.scalar_one())) / Decimal("3")
    months_covered = float(liquid_balance / avg_monthly_expense) if avg_monthly_expense > 0 else 0.0
    emergency_component = _clamp(months_covered / 6 * 100)  # 6 months -> full marks

    overall = round(savings_component * 0.4 + debt_component * 0.3 + emergency_component * 0.3)

    return {
        "score": overall,
        "components": {
            "savings_rate": {"value_pct": round(savings_rate, 1), "score": round(savings_component)},
            "debt_to_income": {"value_pct": round(debt_to_income_pct, 1), "score": round(debt_component)},
            "emergency_fund": {"months_covered": round(months_covered, 1), "score": round(emergency_component)},
        },
    }
