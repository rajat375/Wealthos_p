"""
AI Gateway: the single choke point through which the rest of the app talks
to an LLM provider. Keeping this abstraction means swapping providers (or
running evals against a new model) never touches business logic — every
caller (nl_search.py, insights.py, health_score.py, Celery AI jobs) goes
through `complete()` below.

Security note (see docs/05-Security-Design.md §4): callers must only ever
pass anonymized, aggregated JSON here — never raw account numbers, names, or
free-text notes that could contain PII. System prompts are also
constructed server-side only; never interpolate raw user input into the
system role, to avoid prompt injection altering instructions.
"""
import httpx

from app.core.config import settings


class AIGatewayError(Exception):
    pass


async def complete(system_prompt: str, user_message: str, max_tokens: int = 1024) -> str:
    if not settings.AI_PROVIDER_API_KEY:
        raise AIGatewayError("AI_PROVIDER_API_KEY is not configured")

    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(
            f"{settings.AI_PROVIDER_BASE_URL}/v1/messages",
            headers={
                "x-api-key": settings.AI_PROVIDER_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": settings.AI_MODEL,
                "max_tokens": max_tokens,
                "system": system_prompt,
                "messages": [{"role": "user", "content": user_message}],
            },
        )
        if response.status_code != 200:
            raise AIGatewayError(f"AI provider returned {response.status_code}: {response.text}")

        data = response.json()
        text_blocks = [b["text"] for b in data.get("content", []) if b.get("type") == "text"]
        return "\n".join(text_blocks)
