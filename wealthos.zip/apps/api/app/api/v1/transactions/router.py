import uuid
from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.account import Account
from app.models.transaction import Transaction
from app.models.user import User
from app.schemas.transaction import (
    PaginatedTransactions,
    TransactionCreate,
    TransactionOut,
    TransactionUpdate,
)

router = APIRouter(prefix="/transactions", tags=["transactions"])


@router.get("", response_model=PaginatedTransactions)
async def list_transactions(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    type: str | None = None,
    category_id: uuid.UUID | None = None,
    account_id: uuid.UUID | None = None,
    date_from: date | None = None,
    date_to: date | None = None,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
):
    stmt = select(Transaction).where(
        Transaction.user_id == user.id, Transaction.deleted_at.is_(None)
    )
    if type:
        stmt = stmt.where(Transaction.type == type)
    if category_id:
        stmt = stmt.where(Transaction.category_id == category_id)
    if account_id:
        stmt = stmt.where(Transaction.account_id == account_id)
    if date_from:
        stmt = stmt.where(Transaction.transaction_date >= date_from)
    if date_to:
        stmt = stmt.where(Transaction.transaction_date <= date_to)

    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = (await db.execute(count_stmt)).scalar_one()

    stmt = (
        stmt.order_by(Transaction.transaction_date.desc())
        .offset((page - 1) * limit)
        .limit(limit)
    )
    rows = (await db.execute(stmt)).scalars().all()

    return PaginatedTransactions(
        data=[TransactionOut.model_validate(r) for r in rows],
        meta={"page": page, "limit": limit, "total": total},
    )


async def _get_owned_account_or_404(db: AsyncSession, user: User, account_id: uuid.UUID) -> Account:
    result = await db.execute(
        select(Account).where(Account.id == account_id, Account.user_id == user.id)
    )
    account = result.scalar_one_or_none()
    if not account:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Account not found")
    return account


@router.post("", response_model=TransactionOut, status_code=status.HTTP_201_CREATED)
async def create_transaction(
    payload: TransactionCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    # Ensure the account (and transfer target, if any) actually belongs to this user —
    # RLS backs this up, but we fail fast with a clean 404 rather than a DB error.
    await _get_owned_account_or_404(db, user, payload.account_id)
    if payload.type == "transfer":
        if not payload.transfer_account_id:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "transfer_account_id required for transfers")
        await _get_owned_account_or_404(db, user, payload.transfer_account_id)

    txn = Transaction(user_id=user.id, **payload.model_dump())
    db.add(txn)
    await db.flush()
    # NOTE: account balance is kept in sync by the `trg_txn_balance_insert`
    # Postgres trigger defined in docs/02-Database-Design.md — no application
    # code needed here, which keeps balance updates atomic with the insert
    # even under concurrent writes.
    return txn


async def _get_owned_transaction(db: AsyncSession, user: User, txn_id: uuid.UUID) -> Transaction:
    result = await db.execute(
        select(Transaction).where(
            Transaction.id == txn_id, Transaction.user_id == user.id, Transaction.deleted_at.is_(None)
        )
    )
    txn = result.scalar_one_or_none()
    if not txn:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Transaction not found")
    return txn


@router.get("/{transaction_id}", response_model=TransactionOut)
async def get_transaction(
    transaction_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await _get_owned_transaction(db, user, transaction_id)


@router.patch("/{transaction_id}", response_model=TransactionOut)
async def update_transaction(
    transaction_id: uuid.UUID,
    payload: TransactionUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    txn = await _get_owned_transaction(db, user, transaction_id)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(txn, field, value)
    await db.flush()
    return txn


@router.delete("/{transaction_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_transaction(
    transaction_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    txn = await _get_owned_transaction(db, user, transaction_id)
    await db.delete(txn)
