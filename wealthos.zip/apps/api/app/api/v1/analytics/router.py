from datetime import date

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.ai.health_score import compute_health_score
from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.ai_insight import FinancialHealthScore
from app.models.user import User
from app.schemas.report import HealthScoreOut

router = APIRouter(prefix="/analytics", tags=["analytics"])


@router.get("/health-score", response_model=HealthScoreOut)
async def get_health_score(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    today = date.today()

    existing = await db.execute(
        select(FinancialHealthScore).where(
            FinancialHealthScore.user_id == user.id, FinancialHealthScore.calculated_at == today
        )
    )
    row = existing.scalar_one_or_none()
    if row:
        return HealthScoreOut(score=row.score, components=row.components, calculated_at=row.calculated_at)

    # Not yet computed today (the nightly Celery job normally handles this —
    # see app/tasks/ai_jobs.py — but computing on-demand keeps the endpoint
    # useful even before that job has run for a brand-new user).
    result = await compute_health_score(db, user.id)
    row = FinancialHealthScore(
        user_id=user.id, score=result["score"], components=result["components"], calculated_at=today
    )
    db.add(row)
    await db.flush()
    return HealthScoreOut(score=row.score, components=row.components, calculated_at=row.calculated_at)


@router.get("/health-score/history", response_model=list[HealthScoreOut])
async def health_score_history(
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    result = await db.execute(
        select(FinancialHealthScore)
        .where(FinancialHealthScore.user_id == user.id)
        .order_by(FinancialHealthScore.calculated_at.desc())
        .limit(90)
    )
    rows = result.scalars().all()
    return [HealthScoreOut(score=r.score, components=r.components, calculated_at=r.calculated_at) for r in rows]
