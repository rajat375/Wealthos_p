import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.ai.insights import detect_overspending
from app.ai.nl_search import answer_query
from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.ai_insight import AIInsight
from app.models.user import User

router = APIRouter(prefix="/ai", tags=["ai"])


class AIQueryRequest(BaseModel):
    question: str


@router.post("/query")
async def ai_query(
    payload: AIQueryRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await answer_query(db, str(user.id), payload.question)


@router.get("/insights")
async def list_insights(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    """
    Returns overspending alerts computed live (see app/ai/insights.py) plus
    any previously generated insights (monthly summaries, saving tips) that
    haven't been dismissed. The nightly Celery job in app/tasks/ai_jobs.py
    is what normally populates the stored `ai_insights` rows; this endpoint
    computes overspending on-demand so it's useful before that job has run.
    """
    overspending = await detect_overspending(db, user.id)

    stored_result = await db.execute(
        select(AIInsight)
        .where(AIInsight.user_id == user.id, AIInsight.is_dismissed.is_(False))
        .order_by(AIInsight.created_at.desc())
        .limit(20)
    )
    stored = [
        {
            "id": str(row.id),
            "insight_type": row.insight_type,
            "content": row.content,
            "created_at": row.created_at.isoformat(),
        }
        for row in stored_result.scalars().all()
    ]

    return {
        "overspending_alerts": overspending,
        "insights": stored,
    }


@router.post("/insights/{insight_id}/dismiss", status_code=status.HTTP_204_NO_CONTENT)
async def dismiss_insight(
    insight_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(AIInsight).where(AIInsight.id == insight_id, AIInsight.user_id == user.id)
    )
    insight = result.scalar_one_or_none()
    if not insight:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Insight not found")
    insight.is_dismissed = True
