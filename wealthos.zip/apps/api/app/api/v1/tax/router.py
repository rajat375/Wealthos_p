from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.tax import TaxProfile
from app.models.user import User
from app.schemas.tax import DeductionSuggestion, TaxEstimate, TaxProfileOut, TaxProfileUpdate

router = APIRouter(prefix="/tax", tags=["tax"])

# India-specific slabs for the "new" regime (FY 2025-26 style, simplified for
# this scaffold). A real implementation would version these by financial
# year and support multiple country tax systems (see docs/07-Roadmap).
_NEW_REGIME_SLABS: list[tuple[Decimal, Decimal | None, Decimal]] = [
    (Decimal("0"), Decimal("400000"), Decimal("0")),
    (Decimal("400000"), Decimal("800000"), Decimal("0.05")),
    (Decimal("800000"), Decimal("1200000"), Decimal("0.10")),
    (Decimal("1200000"), Decimal("1600000"), Decimal("0.15")),
    (Decimal("1600000"), Decimal("2000000"), Decimal("0.20")),
    (Decimal("2000000"), Decimal("2400000"), Decimal("0.25")),
    (Decimal("2400000"), None, Decimal("0.30")),
]

# Illustrative deduction limits (India, simplified). A production system
# would version these per financial year and per country — see
# docs/07-Roadmap-Sprints-Future.md's Tax Planner backlog item.
_DEDUCTION_LIMITS = {
    "80C": (Decimal("150000"), "PPF, ELSS, life insurance premiums, principal repayment on home loan"),
    "80D": (Decimal("25000"), "Health insurance premiums (self & family)"),
    "80CCD1B": (Decimal("50000"), "Additional NPS contribution"),
}


def _compute_slab_tax(taxable_income: Decimal) -> Decimal:
    tax = Decimal("0")
    for lower, upper, rate in _NEW_REGIME_SLABS:
        if taxable_income <= lower:
            break
        band_top = upper if upper is not None and taxable_income > upper else taxable_income
        tax += (band_top - lower) * rate
        if upper is None or taxable_income <= upper:
            break
    return tax.quantize(Decimal("1"))


async def _get_or_create_profile(db: AsyncSession, user: User, financial_year: str) -> TaxProfile:
    result = await db.execute(
        select(TaxProfile).where(TaxProfile.user_id == user.id, TaxProfile.financial_year == financial_year)
    )
    profile = result.scalar_one_or_none()
    if not profile:
        profile = TaxProfile(user_id=user.id, financial_year=financial_year)
        db.add(profile)
        await db.flush()
    return profile


@router.get("/profile", response_model=TaxProfileOut)
async def get_profile(
    fy: str = Query(..., description="Financial year, e.g. 2025-2026"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await _get_or_create_profile(db, user, fy)


@router.patch("/profile", response_model=TaxProfileOut)
async def update_profile(
    payload: TaxProfileUpdate,
    fy: str = Query(..., description="Financial year, e.g. 2025-2026"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    profile = await _get_or_create_profile(db, user, fy)
    profile.regime = payload.regime
    if payload.gross_income is not None:
        profile.gross_income = payload.gross_income
    if payload.deductions:
        profile.deductions = {k: float(v) for k, v in payload.deductions.items()}
    await db.flush()
    return profile


@router.get("/estimate", response_model=TaxEstimate)
async def estimate_tax(
    fy: str = Query(..., description="Financial year, e.g. 2025-2026"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    profile = await _get_or_create_profile(db, user, fy)
    if not profile.gross_income:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Set gross_income on the tax profile first")

    gross = Decimal(str(profile.gross_income))
    total_deductions = sum((Decimal(str(v)) for v in (profile.deductions or {}).values()), start=Decimal("0"))
    # New regime doesn't allow most itemized deductions — kept simple/illustrative here.
    taxable_income = gross if profile.regime == "new" else max(gross - total_deductions, Decimal("0"))

    estimated_tax = _compute_slab_tax(taxable_income)
    profile.estimated_tax = estimated_tax
    await db.flush()

    effective_rate = float(estimated_tax / gross * 100) if gross > 0 else 0.0

    return TaxEstimate(
        financial_year=fy,
        regime=profile.regime,
        taxable_income=taxable_income,
        estimated_tax=estimated_tax,
        effective_rate_pct=round(effective_rate, 2),
    )


@router.get("/deduction-suggestions", response_model=list[DeductionSuggestion])
async def deduction_suggestions(
    fy: str = Query(..., description="Financial year, e.g. 2025-2026"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    profile = await _get_or_create_profile(db, user, fy)
    if profile.regime == "new":
        # Most Section 80 deductions aren't available under the new regime.
        return []

    claimed = profile.deductions or {}
    suggestions = []
    for section, (limit, description) in _DEDUCTION_LIMITS.items():
        current = Decimal(str(claimed.get(section, 0)))
        suggestions.append(
            DeductionSuggestion(
                section=section,
                description=description,
                max_limit=limit,
                currently_claimed=current,
                remaining_room=max(limit - current, Decimal("0")),
            )
        )
    return suggestions
    # NOTE: a richer version (see docs/07-Roadmap) would route through the AI
    # Gateway with the user's actual investment mix to suggest *which*
    # specific instruments (ELSS vs PPF vs insurance) close the remaining
    # room, rather than just showing the numeric gap.
