import uuid
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.budget import Budget, BudgetItem
from app.models.category import Category
from app.models.transaction import Transaction
from app.models.user import User
from app.schemas.budget import BudgetCreate, BudgetItemStatus, BudgetOut, BudgetStatus

router = APIRouter(prefix="/budgets", tags=["budgets"])


@router.get("", response_model=BudgetOut | None)
async def get_budget_for_period(
    period: str = Query(..., description="YYYY-MM, e.g. 2026-07"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    year, month = (int(p) for p in period.split("-"))
    result = await db.execute(
        select(Budget).where(
            Budget.user_id == user.id,
            func.extract("year", Budget.period_start) == year,
            func.extract("month", Budget.period_start) == month,
        )
    )
    return result.scalar_one_or_none()


@router.post("", response_model=BudgetOut, status_code=status.HTTP_201_CREATED)
async def create_budget(
    payload: BudgetCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    existing = await db.execute(
        select(Budget).where(
            Budget.user_id == user.id,
            Budget.period_start == payload.period_start,
            Budget.period_end == payload.period_end,
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status.HTTP_409_CONFLICT, "A budget for this period already exists")

    total_planned = sum((item.planned_amount for item in payload.items), start=Decimal("0"))
    budget = Budget(
        user_id=user.id,
        period_start=payload.period_start,
        period_end=payload.period_end,
        total_planned=total_planned,
    )
    db.add(budget)
    await db.flush()

    for item in payload.items:
        db.add(BudgetItem(budget_id=budget.id, category_id=item.category_id, planned_amount=item.planned_amount))
    await db.flush()
    return budget


@router.patch("/{budget_id}/items/{category_id}", status_code=status.HTTP_200_OK)
async def upsert_budget_item(
    budget_id: uuid.UUID,
    category_id: uuid.UUID,
    planned_amount: Decimal,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    budget_result = await db.execute(select(Budget).where(Budget.id == budget_id, Budget.user_id == user.id))
    budget = budget_result.scalar_one_or_none()
    if not budget:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Budget not found")

    item_result = await db.execute(
        select(BudgetItem).where(BudgetItem.budget_id == budget_id, BudgetItem.category_id == category_id)
    )
    item = item_result.scalar_one_or_none()
    if item:
        item.planned_amount = planned_amount
    else:
        item = BudgetItem(budget_id=budget_id, category_id=category_id, planned_amount=planned_amount)
        db.add(item)
    await db.flush()
    return {"category_id": str(category_id), "planned_amount": float(planned_amount)}


@router.get("/{budget_id}/status", response_model=BudgetStatus)
async def budget_status(
    budget_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    budget_result = await db.execute(select(Budget).where(Budget.id == budget_id, Budget.user_id == user.id))
    budget = budget_result.scalar_one_or_none()
    if not budget:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Budget not found")

    items_result = await db.execute(
        select(BudgetItem, Category.name)
        .join(Category, Category.id == BudgetItem.category_id)
        .where(BudgetItem.budget_id == budget_id)
    )
    rows = items_result.all()

    item_statuses: list[BudgetItemStatus] = []
    for item, category_name in rows:
        actual_result = await db.execute(
            select(func.coalesce(func.sum(Transaction.amount), 0)).where(
                Transaction.user_id == user.id,
                Transaction.category_id == item.category_id,
                Transaction.type == "expense",
                Transaction.transaction_date >= budget.period_start,
                Transaction.transaction_date <= budget.period_end,
                Transaction.deleted_at.is_(None),
            )
        )
        actual = actual_result.scalar_one()
        planned = Decimal(str(item.planned_amount))
        pct = round(float(actual) / float(planned) * 100, 1) if planned > 0 else 0.0
        item_statuses.append(
            BudgetItemStatus(
                category_id=item.category_id,
                category_name=category_name,
                planned_amount=planned,
                actual_amount=actual,
                percentage_used=pct,
            )
        )

    return BudgetStatus(
        budget_id=budget.id,
        period_start=budget.period_start,
        period_end=budget.period_end,
        items=item_statuses,
    )
