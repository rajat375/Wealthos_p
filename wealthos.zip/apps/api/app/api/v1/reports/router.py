from datetime import date

from dateutil.relativedelta import relativedelta
from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.account import Account
from app.models.asset import Asset
from app.models.category import Category
from app.models.liability import Liability
from app.models.transaction import Transaction
from app.models.user import User
from app.schemas.report import CashFlowPoint, CategoryBreakdownItem, InvestmentPerformanceItem, NetWorthPoint

router = APIRouter(prefix="/reports", tags=["reports"])

_RANGE_MONTHS = {"3m": 3, "6m": 6, "1y": 12, "2y": 24}


@router.get("/net-worth", response_model=list[NetWorthPoint])
async def net_worth_trend(
    time_range: str = Query("1y", alias="range", description="3m|6m|1y|2y"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """
    Current-snapshot-based trend: since this scaffold doesn't yet backfill
    historical account-balance snapshots, this returns the CURRENT net worth
    at each monthly point rather than a true historical reconstruction.
    A production version would read from a daily/monthly balance-snapshot
    table populated by a Celery job — see docs/07-Roadmap-Sprints-Future.md.
    """
    months = _RANGE_MONTHS.get(time_range, 12)

    assets_result = await db.execute(
        select(func.coalesce(func.sum(Asset.current_value), 0)).where(
            Asset.user_id == user.id, Asset.is_active.is_(True)
        )
    )
    accounts_result = await db.execute(
        select(func.coalesce(func.sum(Account.current_balance), 0)).where(
            Account.user_id == user.id, Account.is_active.is_(True)
        )
    )
    liabilities_result = await db.execute(
        select(func.coalesce(func.sum(Liability.outstanding_amount), 0)).where(
            Liability.user_id == user.id, Liability.is_active.is_(True)
        )
    )
    assets_value = assets_result.scalar_one() + accounts_result.scalar_one()
    liabilities_value = liabilities_result.scalar_one()

    today = date.today()
    return [
        NetWorthPoint(
            as_of=today - relativedelta(months=m),
            assets_value=assets_value,
            liabilities_value=liabilities_value,
            net_worth=assets_value - liabilities_value,
        )
        for m in range(months - 1, -1, -1)
    ]


@router.get("/cash-flow", response_model=list[CashFlowPoint])
async def cash_flow_trend(
    time_range: str = Query("6m", alias="range", description="3m|6m|1y|2y"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    months = _RANGE_MONTHS.get(time_range, 6)
    today = date.today()
    points: list[CashFlowPoint] = []

    for m in range(months - 1, -1, -1):
        month_start = (today.replace(day=1)) - relativedelta(months=m)
        month_end = month_start + relativedelta(months=1) - relativedelta(days=1)

        income_result = await db.execute(
            select(func.coalesce(func.sum(Transaction.amount), 0)).where(
                Transaction.user_id == user.id,
                Transaction.type == "income",
                Transaction.transaction_date >= month_start,
                Transaction.transaction_date <= month_end,
                Transaction.deleted_at.is_(None),
            )
        )
        expense_result = await db.execute(
            select(func.coalesce(func.sum(Transaction.amount), 0)).where(
                Transaction.user_id == user.id,
                Transaction.type == "expense",
                Transaction.transaction_date >= month_start,
                Transaction.transaction_date <= month_end,
                Transaction.deleted_at.is_(None),
            )
        )
        points.append(
            CashFlowPoint(
                month=month_start.strftime("%Y-%m"),
                income=income_result.scalar_one(),
                expense=expense_result.scalar_one(),
            )
        )
    return points


@router.get("/category-breakdown", response_model=list[CategoryBreakdownItem])
async def category_breakdown(
    month: str = Query(..., description="YYYY-MM"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    year, mon = (int(p) for p in month.split("-"))
    month_start = date(year, mon, 1)
    month_end = month_start + relativedelta(months=1) - relativedelta(days=1)

    result = await db.execute(
        select(Category.id, Category.name, func.sum(Transaction.amount))
        .join(Category, Category.id == Transaction.category_id)
        .where(
            Transaction.user_id == user.id,
            Transaction.type == "expense",
            Transaction.transaction_date >= month_start,
            Transaction.transaction_date <= month_end,
            Transaction.deleted_at.is_(None),
        )
        .group_by(Category.id, Category.name)
        .order_by(func.sum(Transaction.amount).desc())
    )
    rows = result.all()
    total = sum((total for _, _, total in rows), start=0) or 1

    return [
        CategoryBreakdownItem(
            category_id=cid, category_name=name, total=total_amt, percentage=round(float(total_amt) / float(total) * 100, 1)
        )
        for cid, name, total_amt in rows
    ]


@router.get("/investment-performance", response_model=list[InvestmentPerformanceItem])
async def investment_performance(
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    result = await db.execute(
        select(Asset).where(Asset.user_id == user.id, Asset.is_active.is_(True)).order_by(Asset.current_value.desc())
    )
    assets = result.scalars().all()

    items = []
    for a in assets:
        gain = None
        gain_pct = None
        if a.purchase_value and a.purchase_value > 0:
            gain = a.current_value - a.purchase_value
            gain_pct = round(float(gain / a.purchase_value) * 100, 1)
        items.append(
            InvestmentPerformanceItem(
                asset_id=a.id,
                name=a.name,
                purchase_value=a.purchase_value,
                current_value=a.current_value,
                absolute_gain=gain,
                gain_pct=gain_pct,
            )
        )
    return items
