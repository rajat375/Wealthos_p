import uuid

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.document import Document
from app.models.user import User
from app.schemas.document import DocumentDownload, DocumentOut
from app.services import blob_storage

router = APIRouter(prefix="/documents", tags=["documents"])

_MAX_UPLOAD_BYTES = 10 * 1024 * 1024  # 10MB, matches docs/03-API-Documentation.md §17 rate-limit note
_ALLOWED_CONTENT_TYPES = {"application/pdf", "image/jpeg", "image/png", "image/webp"}


@router.get("", response_model=list[DocumentOut])
async def list_documents(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    doc_type: str | None = None,
    linked_entity_type: str | None = None,
):
    stmt = select(Document).where(Document.user_id == user.id)
    if doc_type:
        stmt = stmt.where(Document.doc_type == doc_type)
    if linked_entity_type:
        stmt = stmt.where(Document.linked_entity_type == linked_entity_type)
    result = await db.execute(stmt)
    return result.scalars().all()


@router.post("", response_model=DocumentOut, status_code=status.HTTP_201_CREATED)
async def upload_document(
    file: UploadFile = File(...),
    title: str = Form(...),
    doc_type: str | None = Form(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if file.content_type not in _ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            f"Unsupported file type '{file.content_type}'. Allowed: PDF, JPEG, PNG, WebP.",
        )

    content = await file.read()
    if len(content) > _MAX_UPLOAD_BYTES:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "File exceeds the 10MB limit")

    file_url, size_kb = await blob_storage.upload(str(user.id), file.filename or "document", content)

    document = Document(
        user_id=user.id,
        title=title,
        doc_type=doc_type,
        file_url=file_url,
        file_size_kb=size_kb,
    )
    db.add(document)
    await db.flush()
    return document


async def _get_owned_document(db: AsyncSession, user: User, document_id: uuid.UUID) -> Document:
    result = await db.execute(select(Document).where(Document.id == document_id, Document.user_id == user.id))
    document = result.scalar_one_or_none()
    if not document:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found")
    return document


@router.get("/{document_id}", response_model=DocumentDownload)
async def get_document(
    document_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    document = await _get_owned_document(db, user, document_id)
    expires_in = 300
    download_url = await blob_storage.generate_download_url(document.file_url, expires_in)
    return DocumentDownload(
        id=document.id, title=document.title, download_url=download_url, expires_in_seconds=expires_in
    )


@router.delete("/{document_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_document(
    document_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    document = await _get_owned_document(db, user, document_id)
    await db.delete(document)
    # NOTE: the underlying blob is intentionally left in storage here; a
    # production implementation should also delete it from Blob Storage (or
    # move it to a soft-delete/quarantine container) as part of this
    # transaction — omitted in this scaffold to keep the local-disk backend
    # simple.
