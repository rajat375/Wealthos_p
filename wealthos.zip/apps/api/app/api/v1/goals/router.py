import uuid
from datetime import date
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.goal import Goal, GoalContribution
from app.models.user import User
from app.schemas.goal import (
    GoalContributionCreate,
    GoalCreate,
    GoalOut,
    GoalRecommendation,
    GoalUpdate,
)

router = APIRouter(prefix="/goals", tags=["goals"])


@router.get("", response_model=list[GoalOut])
async def list_goals(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    result = await db.execute(select(Goal).where(Goal.user_id == user.id).order_by(Goal.created_at.desc()))
    return result.scalars().all()


@router.post("", response_model=GoalOut, status_code=status.HTTP_201_CREATED)
async def create_goal(
    payload: GoalCreate, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    goal = Goal(user_id=user.id, **payload.model_dump())
    db.add(goal)
    await db.flush()
    return goal


async def _get_owned_goal(db: AsyncSession, user: User, goal_id: uuid.UUID) -> Goal:
    result = await db.execute(select(Goal).where(Goal.id == goal_id, Goal.user_id == user.id))
    goal = result.scalar_one_or_none()
    if not goal:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Goal not found")
    return goal


@router.get("/{goal_id}", response_model=GoalOut)
async def get_goal(
    goal_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    return await _get_owned_goal(db, user, goal_id)


@router.patch("/{goal_id}", response_model=GoalOut)
async def update_goal(
    goal_id: uuid.UUID,
    payload: GoalUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    goal = await _get_owned_goal(db, user, goal_id)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(goal, field, value)
    await db.flush()
    return goal


@router.delete("/{goal_id}", status_code=status.HTTP_204_NO_CONTENT)
async def cancel_goal(
    goal_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    goal = await _get_owned_goal(db, user, goal_id)
    goal.status = "cancelled"


@router.post("/{goal_id}/contributions", response_model=GoalOut, status_code=status.HTTP_201_CREATED)
async def add_contribution(
    goal_id: uuid.UUID,
    payload: GoalContributionCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    goal = await _get_owned_goal(db, user, goal_id)
    contribution = GoalContribution(
        goal_id=goal.id,
        amount=payload.amount,
        contributed_at=payload.contributed_at or date.today(),
    )
    db.add(contribution)
    # NOTE: current_amount is also incremented by the `trg_goal_contribution`
    # Postgres trigger (docs/02-Database-Design.md §3), which also flips
    # status to 'completed' once target is reached; mirrored here so the
    # response returned from this request reflects the change immediately.
    goal.current_amount = Decimal(str(goal.current_amount)) + payload.amount
    if goal.current_amount >= goal.target_amount:
        goal.status = "completed"
    await db.flush()
    return goal


@router.get("/{goal_id}/recommendation", response_model=GoalRecommendation)
async def goal_recommendation(
    goal_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    goal = await _get_owned_goal(db, user, goal_id)
    remaining = Decimal(str(goal.target_amount)) - Decimal(str(goal.current_amount))

    if not goal.target_date:
        return GoalRecommendation(
            suggested_monthly_contribution=remaining,
            months_to_target=None,
            rationale="No target date set — set one to get a monthly contribution plan.",
        )

    months = max(
        (goal.target_date.year - date.today().year) * 12 + (goal.target_date.month - date.today().month), 1
    )
    monthly = (remaining / months).quantize(Decimal("0.01")) if remaining > 0 else Decimal("0")

    return GoalRecommendation(
        suggested_monthly_contribution=monthly,
        months_to_target=months,
        rationale=(
            f"You need {remaining} more to reach \"{goal.name}\" by {goal.target_date}. "
            f"Contributing {monthly} per month gets you there on time."
            if remaining > 0
            else "You've already reached this goal's target amount!"
        ),
    )
    # NOTE: this is a simple linear projection. A richer version (Sprint 11,
    # see docs/07-Roadmap-Sprints-Future.md) would route through the AI
    # Gateway with the user's actual savings-rate history to suggest a
    # contribution that's realistic given their cash flow, not just target/months.
