import uuid
from datetime import date, timedelta

from dateutil.relativedelta import relativedelta
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.bill import Bill, BillPayment
from app.models.user import User
from app.schemas.bill import BillCreate, BillOut, BillPaymentCreate, BillUpdate

router = APIRouter(prefix="/bills", tags=["bills"])

_FREQUENCY_DELTA = {
    "weekly": relativedelta(weeks=1),
    "monthly": relativedelta(months=1),
    "quarterly": relativedelta(months=3),
    "yearly": relativedelta(years=1),
}


@router.get("", response_model=list[BillOut])
async def list_bills(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    upcoming_only: bool = False,
):
    stmt = select(Bill).where(Bill.user_id == user.id, Bill.is_active.is_(True))
    if upcoming_only:
        stmt = stmt.where(Bill.due_date >= date.today(), Bill.due_date <= date.today() + timedelta(days=30))
    result = await db.execute(stmt.order_by(Bill.due_date))
    return result.scalars().all()


@router.post("", response_model=BillOut, status_code=status.HTTP_201_CREATED)
async def create_bill(
    payload: BillCreate, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    bill = Bill(user_id=user.id, **payload.model_dump())
    db.add(bill)
    await db.flush()
    return bill


async def _get_owned_bill(db: AsyncSession, user: User, bill_id: uuid.UUID) -> Bill:
    result = await db.execute(select(Bill).where(Bill.id == bill_id, Bill.user_id == user.id))
    bill = result.scalar_one_or_none()
    if not bill:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Bill not found")
    return bill


@router.patch("/{bill_id}", response_model=BillOut)
async def update_bill(
    bill_id: uuid.UUID,
    payload: BillUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    bill = await _get_owned_bill(db, user, bill_id)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(bill, field, value)
    await db.flush()
    return bill


@router.delete("/{bill_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_bill(
    bill_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    bill = await _get_owned_bill(db, user, bill_id)
    bill.is_active = False


@router.post("/{bill_id}/pay", response_model=BillOut)
async def pay_bill(
    bill_id: uuid.UUID,
    payload: BillPaymentCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    bill = await _get_owned_bill(db, user, bill_id)
    payment = BillPayment(
        bill_id=bill.id,
        paid_amount=payload.paid_amount or bill.amount,
        paid_date=payload.paid_date or date.today(),
    )
    db.add(payment)

    # Roll the due date forward to the next occurrence per the bill's frequency —
    # this is what makes a bill a recurring "reminder" rather than a one-off.
    delta = _FREQUENCY_DELTA.get(bill.frequency, relativedelta(months=1))
    bill.due_date = bill.due_date + delta

    await db.flush()
    return bill
