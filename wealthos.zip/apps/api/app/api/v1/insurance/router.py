import uuid
from datetime import date

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.insurance import InsurancePolicy
from app.models.user import User
from app.schemas.insurance import (
    InsurancePolicyCreate,
    InsurancePolicyOut,
    InsurancePolicyUpdate,
    RenewalReminderOut,
)

router = APIRouter(prefix="/insurance", tags=["insurance"])

RENEWAL_DUE_SOON_DAYS = 30


@router.get("", response_model=list[InsurancePolicyOut])
async def list_policies(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    result = await db.execute(
        select(InsurancePolicy).where(
            InsurancePolicy.user_id == user.id, InsurancePolicy.is_active.is_(True)
        )
    )
    return result.scalars().all()


@router.post("", response_model=InsurancePolicyOut, status_code=status.HTTP_201_CREATED)
async def create_policy(
    payload: InsurancePolicyCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    policy = InsurancePolicy(user_id=user.id, **payload.model_dump())
    db.add(policy)
    await db.flush()
    return policy


async def _get_owned_policy(db: AsyncSession, user: User, policy_id: uuid.UUID) -> InsurancePolicy:
    result = await db.execute(
        select(InsurancePolicy).where(InsurancePolicy.id == policy_id, InsurancePolicy.user_id == user.id)
    )
    policy = result.scalar_one_or_none()
    if not policy:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Insurance policy not found")
    return policy


@router.get("/{policy_id}", response_model=InsurancePolicyOut)
async def get_policy(
    policy_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    return await _get_owned_policy(db, user, policy_id)


@router.patch("/{policy_id}", response_model=InsurancePolicyOut)
async def update_policy(
    policy_id: uuid.UUID,
    payload: InsurancePolicyUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    policy = await _get_owned_policy(db, user, policy_id)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(policy, field, value)
    await db.flush()
    return policy


@router.delete("/{policy_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_policy(
    policy_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    policy = await _get_owned_policy(db, user, policy_id)
    policy.is_active = False


@router.get("/{policy_id}/renewal-reminder", response_model=RenewalReminderOut)
async def renewal_reminder(
    policy_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    policy = await _get_owned_policy(db, user, policy_id)
    if not policy.renewal_date:
        return RenewalReminderOut(
            policy_id=policy.id, renewal_date=None, days_until_renewal=None, is_due_soon=False
        )

    days_until = (policy.renewal_date - date.today()).days
    return RenewalReminderOut(
        policy_id=policy.id,
        renewal_date=policy.renewal_date,
        days_until_renewal=days_until,
        is_due_soon=0 <= days_until <= RENEWAL_DUE_SOON_DAYS,
    )
