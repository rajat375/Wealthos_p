from datetime import date

from dateutil.relativedelta import relativedelta
from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.bill import Bill
from app.models.goal import Goal
from app.models.subscription import Subscription
from app.models.user import User
from app.schemas.report import CalendarEntry

router = APIRouter(prefix="/calendar", tags=["calendar"])


@router.get("", response_model=list[CalendarEntry])
async def get_calendar(
    month: str = Query(..., description="YYYY-MM"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    year, mon = (int(p) for p in month.split("-"))
    month_start = date(year, mon, 1)
    month_end = month_start + relativedelta(months=1) - relativedelta(days=1)

    entries: list[CalendarEntry] = []

    bills_result = await db.execute(
        select(Bill).where(
            Bill.user_id == user.id,
            Bill.is_active.is_(True),
            Bill.due_date >= month_start,
            Bill.due_date <= month_end,
        )
    )
    for bill in bills_result.scalars().all():
        entries.append(CalendarEntry(date=bill.due_date, type="bill", title=bill.name, amount=bill.amount))

    subs_result = await db.execute(
        select(Subscription).where(
            Subscription.user_id == user.id,
            Subscription.is_active.is_(True),
            Subscription.next_billing_date >= month_start,
            Subscription.next_billing_date <= month_end,
        )
    )
    for sub in subs_result.scalars().all():
        entries.append(
            CalendarEntry(date=sub.next_billing_date, type="subscription", title=sub.name, amount=sub.amount)
        )

    goals_result = await db.execute(
        select(Goal).where(
            Goal.user_id == user.id,
            Goal.status == "active",
            Goal.target_date >= month_start,
            Goal.target_date <= month_end,
        )
    )
    for goal in goals_result.scalars().all():
        entries.append(
            CalendarEntry(date=goal.target_date, type="goal_milestone", title=f"{goal.name} target date", amount=None)
        )

    return sorted(entries, key=lambda e: e.date)
