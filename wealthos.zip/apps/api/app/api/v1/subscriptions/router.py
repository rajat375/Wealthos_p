import uuid
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.subscription import Subscription
from app.models.user import User
from app.schemas.subscription import (
    SubscriptionCreate,
    SubscriptionOut,
    SubscriptionSummary,
    SubscriptionUpdate,
)

router = APIRouter(prefix="/subscriptions", tags=["subscriptions"])

# Normalizes any billing cycle to a monthly-equivalent cost so totals are comparable.
_CYCLE_TO_MONTHLY = {"weekly": Decimal("4.345"), "monthly": Decimal("1"), "yearly": Decimal("1") / Decimal("12")}


@router.get("", response_model=list[SubscriptionOut])
async def list_subscriptions(
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    result = await db.execute(
        select(Subscription)
        .where(Subscription.user_id == user.id, Subscription.is_active.is_(True))
        .order_by(Subscription.next_billing_date)
    )
    return result.scalars().all()


@router.get("/summary", response_model=SubscriptionSummary)
async def subscriptions_summary(
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    result = await db.execute(
        select(Subscription).where(Subscription.user_id == user.id, Subscription.is_active.is_(True))
    )
    subs = result.scalars().all()

    monthly_total = sum(
        (Decimal(str(s.amount)) * _CYCLE_TO_MONTHLY.get(s.billing_cycle, Decimal("1")) for s in subs),
        start=Decimal("0"),
    ).quantize(Decimal("0.01"))

    return SubscriptionSummary(
        monthly_total=monthly_total,
        yearly_total=(monthly_total * 12).quantize(Decimal("0.01")),
        active_count=len(subs),
    )


@router.post("", response_model=SubscriptionOut, status_code=status.HTTP_201_CREATED)
async def create_subscription(
    payload: SubscriptionCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    subscription = Subscription(user_id=user.id, **payload.model_dump())
    db.add(subscription)
    await db.flush()
    return subscription


async def _get_owned_subscription(db: AsyncSession, user: User, sub_id: uuid.UUID) -> Subscription:
    result = await db.execute(
        select(Subscription).where(Subscription.id == sub_id, Subscription.user_id == user.id)
    )
    subscription = result.scalar_one_or_none()
    if not subscription:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Subscription not found")
    return subscription


@router.patch("/{subscription_id}", response_model=SubscriptionOut)
async def update_subscription(
    subscription_id: uuid.UUID,
    payload: SubscriptionUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    subscription = await _get_owned_subscription(db, user, subscription_id)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(subscription, field, value)
    await db.flush()
    return subscription


@router.delete("/{subscription_id}", status_code=status.HTTP_204_NO_CONTENT)
async def cancel_subscription(
    subscription_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    subscription = await _get_owned_subscription(db, user, subscription_id)
    subscription.is_active = False
