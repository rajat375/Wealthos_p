import uuid
from datetime import date
from decimal import Decimal

from dateutil.relativedelta import relativedelta
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.liability import Liability, LiabilityType, LoanPayment
from app.models.user import User
from app.schemas.liability import (
    AmortizationRow,
    LiabilityCreate,
    LiabilityOut,
    LiabilityUpdate,
    LoanPaymentCreate,
    LoanPaymentOut,
)

router = APIRouter(prefix="/liabilities", tags=["liabilities"])


async def _get_liability_type_or_404(db: AsyncSession, code: str) -> LiabilityType:
    result = await db.execute(select(LiabilityType).where(LiabilityType.code == code))
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, f"Unknown liability_type '{code}'")
    return row


@router.get("", response_model=list[LiabilityOut])
async def list_liabilities(
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    result = await db.execute(
        select(Liability).where(Liability.user_id == user.id, Liability.is_active.is_(True))
    )
    return result.scalars().all()


@router.post("", response_model=LiabilityOut, status_code=status.HTTP_201_CREATED)
async def create_liability(
    payload: LiabilityCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    liability_type = await _get_liability_type_or_404(db, payload.liability_type)
    data = payload.model_dump(exclude={"liability_type"})
    liability = Liability(user_id=user.id, liability_type_id=liability_type.id, **data)
    db.add(liability)
    await db.flush()
    return liability


async def _get_owned_liability(db: AsyncSession, user: User, liability_id: uuid.UUID) -> Liability:
    result = await db.execute(
        select(Liability).where(Liability.id == liability_id, Liability.user_id == user.id)
    )
    liability = result.scalar_one_or_none()
    if not liability:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Liability not found")
    return liability


@router.get("/{liability_id}", response_model=LiabilityOut)
async def get_liability(
    liability_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    return await _get_owned_liability(db, user, liability_id)


@router.patch("/{liability_id}", response_model=LiabilityOut)
async def update_liability(
    liability_id: uuid.UUID,
    payload: LiabilityUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    liability = await _get_owned_liability(db, user, liability_id)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(liability, field, value)
    await db.flush()
    return liability


@router.delete("/{liability_id}", status_code=status.HTTP_204_NO_CONTENT)
async def close_liability(
    liability_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    liability = await _get_owned_liability(db, user, liability_id)
    liability.is_active = False


@router.post("/{liability_id}/payments", response_model=LoanPaymentOut, status_code=status.HTTP_201_CREATED)
async def add_payment(
    liability_id: uuid.UUID,
    payload: LoanPaymentCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    liability = await _get_owned_liability(db, user, liability_id)
    payment = LoanPayment(liability_id=liability.id, **payload.model_dump())
    db.add(payment)
    # NOTE: outstanding_amount is also reduced by the `trg_loan_payment`
    # Postgres trigger (docs/02-Database-Design.md §3) for atomicity under
    # concurrent writes; this direct update keeps the in-request response
    # consistent even before that trigger's effect would be re-read.
    if payload.principal_component:
        liability.outstanding_amount = max(
            Decimal(str(liability.outstanding_amount)) - payload.principal_component, Decimal("0")
        )
    await db.flush()
    return payment


@router.get("/{liability_id}/amortization-schedule", response_model=list[AmortizationRow])
async def amortization_schedule(
    liability_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    liability = await _get_owned_liability(db, user, liability_id)
    if not liability.emi_amount or not liability.interest_rate or not liability.tenure_months:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            "emi_amount, interest_rate, and tenure_months are required to compute a schedule",
        )

    balance = Decimal(str(liability.outstanding_amount))
    monthly_rate = Decimal(str(liability.interest_rate)) / Decimal("100") / Decimal("12")
    emi = Decimal(str(liability.emi_amount))
    start = liability.start_date or date.today()

    rows: list[AmortizationRow] = []
    for m in range(1, liability.tenure_months + 1):
        if balance <= 0:
            break
        interest_component = (balance * monthly_rate).quantize(Decimal("0.01"))
        principal_component = min(emi - interest_component, balance)
        balance -= principal_component
        rows.append(
            AmortizationRow(
                month=m,
                payment_date=start + relativedelta(months=m - 1),
                principal_component=principal_component,
                interest_component=interest_component,
                remaining_balance=balance,
            )
        )
    return rows
