from datetime import date

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.account import Account
from app.models.transaction import Transaction
from app.models.user import User

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("/summary")
async def get_dashboard_summary(
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    today = date.today()
    month_start = today.replace(day=1)

    # Net worth (V1, manual-entry): sum of active account balances.
    # Full net worth (accounts + assets - liabilities) is computed in the
    # Reports service once the assets/liabilities modules are wired in —
    # see docs/03-API-Documentation.md §13.
    balance_result = await db.execute(
        select(func.coalesce(func.sum(Account.current_balance), 0)).where(
            Account.user_id == user.id, Account.is_active.is_(True)
        )
    )
    total_balance = balance_result.scalar_one()

    income_result = await db.execute(
        select(func.coalesce(func.sum(Transaction.amount), 0)).where(
            Transaction.user_id == user.id,
            Transaction.type == "income",
            Transaction.transaction_date >= month_start,
            Transaction.deleted_at.is_(None),
        )
    )
    expense_result = await db.execute(
        select(func.coalesce(func.sum(Transaction.amount), 0)).where(
            Transaction.user_id == user.id,
            Transaction.type == "expense",
            Transaction.transaction_date >= month_start,
            Transaction.deleted_at.is_(None),
        )
    )
    month_income = income_result.scalar_one()
    month_expense = expense_result.scalar_one()
    savings_rate = float((month_income - month_expense) / month_income * 100) if month_income else 0.0

    recent_result = await db.execute(
        select(Transaction)
        .where(Transaction.user_id == user.id, Transaction.deleted_at.is_(None))
        .order_by(Transaction.transaction_date.desc())
        .limit(5)
    )
    recent = recent_result.scalars().all()

    return {
        "net_worth": float(total_balance),
        "month_income": float(month_income),
        "month_expense": float(month_expense),
        "savings_rate_pct": round(savings_rate, 1),
        "recent_transactions": [
            {
                "id": str(t.id),
                "type": t.type,
                "amount": float(t.amount),
                "merchant": t.merchant,
                "date": t.transaction_date.isoformat(),
            }
            for t in recent
        ],
    }
