import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.database import get_db
from app.models.asset import Asset, AssetType, AssetValuation
from app.models.user import User
from app.schemas.asset import (
    AssetAllocationItem,
    AssetCreate,
    AssetOut,
    AssetSummary,
    AssetUpdate,
    AssetValuationCreate,
)

router = APIRouter(prefix="/assets", tags=["assets"])


async def _get_asset_type_or_404(db: AsyncSession, code: str) -> AssetType:
    result = await db.execute(select(AssetType).where(AssetType.code == code))
    asset_type = result.scalar_one_or_none()
    if not asset_type:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, f"Unknown asset_type '{code}'")
    return asset_type


@router.get("", response_model=list[AssetOut])
async def list_assets(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    asset_type: str | None = None,
):
    stmt = select(Asset).where(Asset.user_id == user.id, Asset.is_active.is_(True))
    if asset_type:
        asset_type_row = await _get_asset_type_or_404(db, asset_type)
        stmt = stmt.where(Asset.asset_type_id == asset_type_row.id)
    result = await db.execute(stmt.order_by(Asset.current_value.desc()))
    return result.scalars().all()


@router.get("/summary", response_model=AssetSummary)
async def asset_allocation_summary(
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    result = await db.execute(
        select(AssetType.label, func.coalesce(func.sum(Asset.current_value), 0))
        .join(Asset, Asset.asset_type_id == AssetType.id)
        .where(Asset.user_id == user.id, Asset.is_active.is_(True))
        .group_by(AssetType.label)
    )
    rows = result.all()
    total = sum(float(v) for _, v in rows) or 1.0  # avoid div-by-zero when empty

    return AssetSummary(
        total_value=sum((v for _, v in rows), start=0),
        allocation=[
            AssetAllocationItem(asset_type=label, total_value=value, percentage=round(float(value) / total * 100, 1))
            for label, value in rows
        ],
    )


@router.post("", response_model=AssetOut, status_code=status.HTTP_201_CREATED)
async def create_asset(
    payload: AssetCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    asset_type_row = await _get_asset_type_or_404(db, payload.asset_type)
    data = payload.model_dump(exclude={"asset_type", "metadata"})
    asset = Asset(user_id=user.id, asset_type_id=asset_type_row.id, metadata_json=payload.metadata, **data)
    db.add(asset)
    await db.flush()
    return asset


async def _get_owned_asset(db: AsyncSession, user: User, asset_id: uuid.UUID) -> Asset:
    result = await db.execute(select(Asset).where(Asset.id == asset_id, Asset.user_id == user.id))
    asset = result.scalar_one_or_none()
    if not asset:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Asset not found")
    return asset


@router.get("/{asset_id}", response_model=AssetOut)
async def get_asset(
    asset_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    return await _get_owned_asset(db, user, asset_id)


@router.patch("/{asset_id}", response_model=AssetOut)
async def update_asset(
    asset_id: uuid.UUID,
    payload: AssetUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    asset = await _get_owned_asset(db, user, asset_id)
    updates = payload.model_dump(exclude_unset=True)
    if "metadata" in updates:
        asset.metadata_json = updates.pop("metadata")
    for field, value in updates.items():
        setattr(asset, field, value)
    await db.flush()
    return asset


@router.delete("/{asset_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_asset(
    asset_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    asset = await _get_owned_asset(db, user, asset_id)
    asset.is_active = False


@router.post("/{asset_id}/valuations", status_code=status.HTTP_201_CREATED)
async def add_valuation(
    asset_id: uuid.UUID,
    payload: AssetValuationCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    asset = await _get_owned_asset(db, user, asset_id)
    valuation = AssetValuation(asset_id=asset.id, value=payload.value, valued_at=payload.valued_at)
    asset.current_value = payload.value  # keep the denormalized current_value in sync
    db.add(valuation)
    await db.flush()
    return {"id": str(valuation.id), "value": float(valuation.value), "valued_at": valuation.valued_at.isoformat()}
