import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel

LiabilityTypeCode = Literal[
    "home_loan", "personal_loan", "education_loan", "car_loan", "credit_card_debt", "other"
]


class LiabilityCreate(BaseModel):
    liability_type: LiabilityTypeCode
    name: str
    lender: str | None = None
    principal_amount: Decimal
    outstanding_amount: Decimal
    interest_rate: Decimal | None = None
    emi_amount: Decimal | None = None
    tenure_months: int | None = None
    start_date: date | None = None
    end_date: date | None = None


class LiabilityUpdate(BaseModel):
    name: str | None = None
    outstanding_amount: Decimal | None = None
    interest_rate: Decimal | None = None
    emi_amount: Decimal | None = None
    end_date: date | None = None


class LiabilityOut(BaseModel):
    id: uuid.UUID
    name: str
    lender: str | None
    principal_amount: Decimal
    outstanding_amount: Decimal
    interest_rate: Decimal | None
    emi_amount: Decimal | None
    end_date: date | None

    model_config = {"from_attributes": True}


class LoanPaymentCreate(BaseModel):
    amount: Decimal
    principal_component: Decimal | None = None
    interest_component: Decimal | None = None
    payment_date: date


class LoanPaymentOut(BaseModel):
    id: uuid.UUID
    amount: Decimal
    principal_component: Decimal | None
    interest_component: Decimal | None
    payment_date: date

    model_config = {"from_attributes": True}


class AmortizationRow(BaseModel):
    month: int
    payment_date: date
    principal_component: Decimal
    interest_component: Decimal
    remaining_balance: Decimal
