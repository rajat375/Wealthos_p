import uuid
from typing import Literal

from pydantic import BaseModel

CategoryType = Literal["income", "expense"]


class CategoryCreate(BaseModel):
    name: str
    type: CategoryType
    parent_id: uuid.UUID | None = None
    icon: str | None = None
    color: str | None = None


class CategoryUpdate(BaseModel):
    name: str | None = None
    icon: str | None = None
    color: str | None = None


class CategoryOut(BaseModel):
    id: uuid.UUID
    name: str
    type: str
    parent_id: uuid.UUID | None
    icon: str | None
    color: str | None
    is_system_default: bool

    model_config = {"from_attributes": True}
