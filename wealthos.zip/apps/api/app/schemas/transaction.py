import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, Field

TransactionType = Literal["income", "expense", "transfer"]


class TransactionCreate(BaseModel):
    account_id: uuid.UUID
    type: TransactionType
    amount: Decimal = Field(gt=0)
    category_id: uuid.UUID | None = None
    income_source: str | None = None
    transaction_date: date
    merchant: str | None = None
    notes: str | None = None
    is_recurring: bool = False
    transfer_account_id: uuid.UUID | None = None


class TransactionUpdate(BaseModel):
    amount: Decimal | None = Field(default=None, gt=0)
    category_id: uuid.UUID | None = None
    transaction_date: date | None = None
    merchant: str | None = None
    notes: str | None = None


class TransactionOut(BaseModel):
    id: uuid.UUID
    account_id: uuid.UUID
    type: str
    amount: Decimal
    category_id: uuid.UUID | None
    transaction_date: date
    merchant: str | None
    notes: str | None
    is_recurring: bool

    model_config = {"from_attributes": True}


class PaginatedTransactions(BaseModel):
    data: list[TransactionOut]
    meta: dict
