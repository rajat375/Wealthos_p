import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel

AssetTypeCode = Literal[
    "mutual_fund", "stock", "gold", "silver", "fd", "ppf", "epf", "nps",
    "real_estate", "crypto", "bond", "vehicle", "other",
]


class AssetCreate(BaseModel):
    asset_type: AssetTypeCode
    name: str
    quantity: Decimal | None = None
    purchase_value: Decimal | None = None
    current_value: Decimal
    purchase_date: date | None = None
    maturity_date: date | None = None
    interest_rate: Decimal | None = None
    institution: str | None = None
    metadata: dict = {}


class AssetUpdate(BaseModel):
    name: str | None = None
    quantity: Decimal | None = None
    current_value: Decimal | None = None
    interest_rate: Decimal | None = None
    metadata: dict | None = None


class AssetOut(BaseModel):
    id: uuid.UUID
    name: str
    quantity: Decimal | None
    purchase_value: Decimal | None
    current_value: Decimal
    purchase_date: date | None
    institution: str | None

    model_config = {"from_attributes": True}


class AssetValuationCreate(BaseModel):
    value: Decimal
    valued_at: date


class AssetAllocationItem(BaseModel):
    asset_type: str
    total_value: Decimal
    percentage: float


class AssetSummary(BaseModel):
    total_value: Decimal
    allocation: list[AssetAllocationItem]
