import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel

PolicyType = Literal["life", "health", "vehicle", "home", "term", "other"]


class InsurancePolicyCreate(BaseModel):
    policy_type: PolicyType
    provider: str | None = None
    policy_number: str | None = None
    sum_assured: Decimal | None = None
    premium_amount: Decimal | None = None
    premium_frequency: Literal["monthly", "quarterly", "yearly"] = "yearly"
    start_date: date | None = None
    renewal_date: date | None = None


class InsurancePolicyUpdate(BaseModel):
    provider: str | None = None
    sum_assured: Decimal | None = None
    premium_amount: Decimal | None = None
    renewal_date: date | None = None
    is_active: bool | None = None


class InsurancePolicyOut(BaseModel):
    id: uuid.UUID
    policy_type: str
    provider: str | None
    policy_number: str | None
    sum_assured: Decimal | None
    premium_amount: Decimal | None
    premium_frequency: str
    renewal_date: date | None
    is_active: bool

    model_config = {"from_attributes": True}


class RenewalReminderOut(BaseModel):
    policy_id: uuid.UUID
    renewal_date: date | None
    days_until_renewal: int | None
    is_due_soon: bool
