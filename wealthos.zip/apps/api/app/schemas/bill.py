import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel

BillFrequency = Literal["weekly", "monthly", "quarterly", "yearly"]


class BillCreate(BaseModel):
    name: str
    amount: Decimal
    due_date: date
    frequency: BillFrequency = "monthly"
    category_id: uuid.UUID | None = None
    account_id: uuid.UUID | None = None
    is_autopay: bool = False


class BillUpdate(BaseModel):
    name: str | None = None
    amount: Decimal | None = None
    due_date: date | None = None
    is_autopay: bool | None = None
    is_active: bool | None = None


class BillOut(BaseModel):
    id: uuid.UUID
    name: str
    amount: Decimal
    due_date: date
    frequency: str
    is_autopay: bool
    is_active: bool

    model_config = {"from_attributes": True}


class BillPaymentCreate(BaseModel):
    paid_amount: Decimal | None = None  # defaults to bill.amount if omitted
    paid_date: date | None = None  # defaults to today
