import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, computed_field

GoalType = Literal[
    "emergency_fund", "house", "car", "vacation", "retirement", "child_education", "custom"
]


class GoalCreate(BaseModel):
    goal_type: GoalType
    name: str
    target_amount: Decimal
    target_date: date | None = None
    linked_account_id: uuid.UUID | None = None


class GoalUpdate(BaseModel):
    name: str | None = None
    target_amount: Decimal | None = None
    target_date: date | None = None
    status: Literal["active", "completed", "paused", "cancelled"] | None = None


class GoalOut(BaseModel):
    id: uuid.UUID
    goal_type: str
    name: str
    target_amount: Decimal
    current_amount: Decimal
    target_date: date | None
    status: str

    model_config = {"from_attributes": True}

    @computed_field  # type: ignore[misc]
    @property
    def progress_pct(self) -> float:
        if self.target_amount <= 0:
            return 0.0
        return round(float(self.current_amount / self.target_amount) * 100, 1)


class GoalContributionCreate(BaseModel):
    amount: Decimal
    contributed_at: date | None = None


class GoalRecommendation(BaseModel):
    suggested_monthly_contribution: Decimal
    months_to_target: int | None
    rationale: str
