import uuid
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel


class TaxProfileUpdate(BaseModel):
    regime: Literal["old", "new"] = "new"
    gross_income: Decimal | None = None
    deductions: dict[str, Decimal] = {}


class TaxProfileOut(BaseModel):
    id: uuid.UUID
    financial_year: str
    regime: str
    gross_income: Decimal | None
    deductions: dict
    estimated_tax: Decimal | None

    model_config = {"from_attributes": True}


class TaxEstimate(BaseModel):
    financial_year: str
    regime: str
    taxable_income: Decimal
    estimated_tax: Decimal
    effective_rate_pct: float


class DeductionSuggestion(BaseModel):
    section: str
    description: str
    max_limit: Decimal
    currently_claimed: Decimal
    remaining_room: Decimal
