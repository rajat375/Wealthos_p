import uuid
from datetime import date
from typing import Literal

from pydantic import BaseModel

DocType = Literal["insurance", "loan", "tax", "identity", "other"]
LinkedEntityType = Literal["asset", "liability", "insurance_policy"]


class DocumentCreate(BaseModel):
    title: str
    doc_type: DocType | None = None
    linked_entity_type: LinkedEntityType | None = None
    linked_entity_id: uuid.UUID | None = None
    expiry_date: date | None = None


class DocumentOut(BaseModel):
    id: uuid.UUID
    title: str
    doc_type: str | None
    file_size_kb: int | None
    linked_entity_type: str | None
    linked_entity_id: uuid.UUID | None
    expiry_date: date | None
    is_encrypted: bool

    model_config = {"from_attributes": True}


class DocumentDownload(BaseModel):
    id: uuid.UUID
    title: str
    download_url: str
    expires_in_seconds: int
