import uuid
from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel

BillingCycle = Literal["weekly", "monthly", "yearly"]


class SubscriptionCreate(BaseModel):
    name: str
    amount: Decimal
    billing_cycle: BillingCycle = "monthly"
    next_billing_date: date | None = None
    category_id: uuid.UUID | None = None
    account_id: uuid.UUID | None = None
    cancel_url: str | None = None


class SubscriptionUpdate(BaseModel):
    name: str | None = None
    amount: Decimal | None = None
    next_billing_date: date | None = None
    is_active: bool | None = None


class SubscriptionOut(BaseModel):
    id: uuid.UUID
    name: str
    amount: Decimal
    billing_cycle: str
    next_billing_date: date | None
    is_active: bool
    cancel_url: str | None

    model_config = {"from_attributes": True}


class SubscriptionSummary(BaseModel):
    monthly_total: Decimal
    yearly_total: Decimal
    active_count: int
