import uuid
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, Field

AccountType = Literal["bank_savings", "bank_current", "cash_wallet", "credit_card"]


class AccountCreate(BaseModel):
    account_type: AccountType
    name: str = Field(min_length=1, max_length=100)
    institution_name: str | None = None
    current_balance: Decimal = Decimal("0")
    credit_limit: Decimal | None = None
    currency: str = "INR"


class AccountUpdate(BaseModel):
    name: str | None = None
    institution_name: str | None = None
    current_balance: Decimal | None = None
    credit_limit: Decimal | None = None
    is_active: bool | None = None


class AccountOut(BaseModel):
    id: uuid.UUID
    account_type: str
    name: str
    institution_name: str | None
    current_balance: Decimal
    credit_limit: Decimal | None
    currency: str
    is_active: bool

    model_config = {"from_attributes": True}
