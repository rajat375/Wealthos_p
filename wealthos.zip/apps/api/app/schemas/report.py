import uuid
from datetime import date
from decimal import Decimal

from pydantic import BaseModel


class NetWorthPoint(BaseModel):
    as_of: date
    assets_value: Decimal
    liabilities_value: Decimal
    net_worth: Decimal


class CashFlowPoint(BaseModel):
    month: str  # "2026-07"
    income: Decimal
    expense: Decimal


class CategoryBreakdownItem(BaseModel):
    category_id: uuid.UUID
    category_name: str
    total: Decimal
    percentage: float


class InvestmentPerformanceItem(BaseModel):
    asset_id: uuid.UUID
    name: str
    purchase_value: Decimal | None
    current_value: Decimal
    absolute_gain: Decimal | None
    gain_pct: float | None


class HealthScoreOut(BaseModel):
    score: int
    components: dict
    calculated_at: date


class CalendarEntry(BaseModel):
    date: date
    type: str  # bill|subscription|goal_milestone
    title: str
    amount: Decimal | None
