import uuid
from datetime import date
from decimal import Decimal

from pydantic import BaseModel


class BudgetItemInput(BaseModel):
    category_id: uuid.UUID
    planned_amount: Decimal


class BudgetCreate(BaseModel):
    period_start: date
    period_end: date
    items: list[BudgetItemInput] = []


class BudgetItemOut(BaseModel):
    category_id: uuid.UUID
    planned_amount: Decimal

    model_config = {"from_attributes": True}


class BudgetOut(BaseModel):
    id: uuid.UUID
    period_start: date
    period_end: date
    total_planned: Decimal | None

    model_config = {"from_attributes": True}


class BudgetItemStatus(BaseModel):
    category_id: uuid.UUID
    category_name: str
    planned_amount: Decimal
    actual_amount: Decimal
    percentage_used: float


class BudgetStatus(BaseModel):
    budget_id: uuid.UUID
    period_start: date
    period_end: date
    items: list[BudgetItemStatus]
