# WealthOS — Testing, CI/CD, Docker & Azure Deployment Guide

## 1. Testing Strategy

### 1.1 Test Pyramid
- **Unit tests (70%)** — pytest for backend services/repositories (mocked DB), Jest/React Testing Library for frontend components/hooks. Target ≥85% coverage on `services/` and `ai/` modules.
- **Integration tests (20%)** — pytest against a real ephemeral Postgres (Testcontainers) exercising full request→DB round trips per module (transactions, assets, goals, budgets); verifies triggers (balance sync, goal contribution) actually fire.
- **E2E tests (10%)** — Playwright covering critical user journeys: signup→onboarding, add transaction→dashboard updates, create goal→contribute→progress reflects, AI Assistant query→answer renders.

### 1.2 Specialized Testing
- **Security testing:** OWASP ZAP baseline scan in CI on staging; dependency scanning (`pip-audit`, `npm audit`, Dependabot); annual third-party pentest before GA.
- **Load testing:** k6 scripts simulating 5,000 concurrent users on dashboard + transaction-create endpoints; target p95 < 300ms read / < 800ms write at that load.
- **RLS/authorization testing:** dedicated test suite that logs in as User A and asserts every endpoint returns 403/404 (never data) for User B's resource IDs.
- **AI testing:** golden-set of 50+ natural-language queries with expected structured output, run in CI against a pinned model version to catch regressions; prompt-injection red-team test cases.
- **Accessibility testing:** axe-core automated checks in CI + manual screen-reader pass before major releases.

### 1.3 Environments
`local` (docker-compose) → `dev` (auto-deploy every merge to `develop`) → `staging` (mirrors prod, used for QA/UAT + pentest) → `production`.

---

## 2. CI/CD Pipeline (GitHub Actions)

```yaml
# .github/workflows/ci.yml
name: CI
on:
  pull_request:
  push:
    branches: [develop, main]

jobs:
  backend-test:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:16
        env: { POSTGRES_PASSWORD: test, POSTGRES_DB: wealthos_test }
        ports: ["5432:5432"]
      redis:
        image: redis:7
        ports: ["6379:6379"]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }
      - run: pip install -r apps/api/requirements.txt
      - run: pip install -r apps/api/requirements-dev.txt
      - run: alembic upgrade head
        working-directory: apps/api
      - run: pytest --cov=app --cov-report=xml --cov-fail-under=85
        working-directory: apps/api
      - run: pip-audit -r requirements.txt
        working-directory: apps/api
      - uses: codecov/codecov-action@v4

  frontend-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: "20" }
      - run: npm ci
        working-directory: apps/web
      - run: npm run lint
        working-directory: apps/web
      - run: npm run type-check
        working-directory: apps/web
      - run: npm run test -- --coverage
        working-directory: apps/web
      - run: npm audit --audit-level=critical
        working-directory: apps/web

  e2e-test:
    needs: [backend-test, frontend-test]
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: docker compose -f infra/docker-compose.yml up -d
      - run: npx playwright install --with-deps
      - run: npx playwright test
        working-directory: apps/web
      - run: docker compose -f infra/docker-compose.yml down

  build-images:
    needs: [backend-test, frontend-test]
    if: github.ref == 'refs/heads/main' || github.ref == 'refs/heads/develop'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: docker/login-action@v3
        with:
          registry: wealthosacr.azurecr.io
          username: ${{ secrets.ACR_USERNAME }}
          password: ${{ secrets.ACR_PASSWORD }}
      - uses: docker/build-push-action@v5
        with:
          context: apps/api
          push: true
          tags: wealthosacr.azurecr.io/wealthos-api:${{ github.sha }}
      - uses: docker/build-push-action@v5
        with:
          context: apps/web
          push: true
          tags: wealthosacr.azurecr.io/wealthos-web:${{ github.sha }}
```

```yaml
# .github/workflows/cd.yml
name: CD
on:
  workflow_run:
    workflows: ["CI"]
    branches: [main]
    types: [completed]

jobs:
  deploy-staging:
    if: github.event.workflow_run.conclusion == 'success'
    runs-on: ubuntu-latest
    environment: staging
    steps:
      - uses: azure/login@v2
        with: { creds: ${{ secrets.AZURE_CREDENTIALS }} }
      - run: az webapp deploy --resource-group wealthos-rg --name wealthos-api-staging --type container --container-image-name wealthosacr.azurecr.io/wealthos-api:${{ github.sha }}
      - run: az webapp deploy --resource-group wealthos-rg --name wealthos-web-staging --type container --container-image-name wealthosacr.azurecr.io/wealthos-web:${{ github.sha }}
      - run: cd apps/api && alembic upgrade head   # against staging DB via secure runner

  deploy-production:
    needs: deploy-staging
    runs-on: ubuntu-latest
    environment:
      name: production
      # requires manual approval gate configured in GitHub Environments
    steps:
      - uses: azure/login@v2
        with: { creds: ${{ secrets.AZURE_CREDENTIALS }} }
      - run: az webapp deployment slot swap --resource-group wealthos-rg --name wealthos-api --slot staging --target-slot production
      - run: az webapp deployment slot swap --resource-group wealthos-rg --name wealthos-web --slot staging --target-slot production
```

**Deployment strategy:** blue-green via Azure App Service deployment slots — new version deployed to `staging` slot, smoke-tested, then swapped into production with zero downtime and instant rollback (swap back).

---

## 3. Docker Configuration

```dockerfile
# apps/api/Dockerfile
FROM python:3.12-slim AS base
WORKDIR /app
RUN apt-get update && apt-get install -y --no-install-recommends libpq-dev gcc && rm -rf /var/lib/apt/lists/*
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
RUN useradd -m appuser && chown -R appuser /app
USER appuser
EXPOSE 8000
HEALTHCHECK --interval=30s --timeout=5s CMD curl -f http://localhost:8000/health || exit 1
CMD ["gunicorn", "app.main:app", "-k", "uvicorn.workers.UvicornWorker", "-w", "4", "-b", "0.0.0.0:8000"]
```

```dockerfile
# apps/web/Dockerfile
FROM node:20-alpine AS deps
WORKDIR /app
COPY package*.json ./
RUN npm ci

FROM node:20-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
RUN addgroup -S nodejs && adduser -S nextjs -G nodejs
COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static
USER nextjs
EXPOSE 3000
CMD ["node", "server.js"]
```

```yaml
# infra/docker-compose.yml (local dev)
version: "3.9"
services:
  postgres:
    image: postgres:16
    environment:
      POSTGRES_DB: wealthos
      POSTGRES_USER: wealthos
      POSTGRES_PASSWORD: devpassword
    ports: ["5432:5432"]
    volumes: ["pgdata:/var/lib/postgresql/data"]

  redis:
    image: redis:7
    ports: ["6379:6379"]

  api:
    build: ../apps/api
    env_file: ../apps/api/.env
    ports: ["8000:8000"]
    depends_on: [postgres, redis]
    volumes: ["../apps/api:/app"]

  worker:
    build: ../apps/api
    command: celery -A app.tasks.celery_app worker --loglevel=info
    env_file: ../apps/api/.env
    depends_on: [postgres, redis]

  beat:
    build: ../apps/api
    command: celery -A app.tasks.celery_app beat --loglevel=info
    env_file: ../apps/api/.env
    depends_on: [postgres, redis]

  web:
    build: ../apps/web
    ports: ["3000:3000"]
    environment:
      NEXT_PUBLIC_API_URL: http://localhost:8000/api/v1
    depends_on: [api]

volumes:
  pgdata:
```

---

## 4. Azure Deployment Guide

### 4.1 Target Resources
| Resource | Purpose | SKU (starting point) |
|---|---|---|
| Azure App Service (Linux, container) ×2 | API + Web, each with staging/prod slots | P1v3 (scale to P2v3/P3v3 under load) |
| Azure Database for PostgreSQL – Flexible Server | Primary DB | General Purpose, 4 vCore, HA zone-redundant |
| Azure Cache for Redis | Sessions, rate limiting, Celery broker | Standard C1 |
| Azure Blob Storage | Receipts & Document Vault | Hot tier, private containers, CMK optional |
| Azure Container Registry | Docker image storage | Standard |
| Azure Front Door + WAF | CDN, TLS termination, WAF rules | Premium (WAF included) |
| Azure Key Vault | Secrets, encryption keys | Standard |
| Azure Monitor + Application Insights | Logging, tracing, alerting | Pay-as-you-go |
| Azure Communication/SendGrid | Transactional email | Standard |

### 4.2 Provisioning Steps (CLI outline)
```bash
az group create -n wealthos-rg -l centralindia

az postgres flexible-server create \
  --resource-group wealthos-rg --name wealthos-pg \
  --location centralindia --tier GeneralPurpose --sku-name Standard_D4ds_v4 \
  --storage-size 128 --version 16 --high-availability ZoneRedundant \
  --admin-user wealthosadmin --admin-password <from-key-vault>

az redis create -g wealthos-rg -n wealthos-redis -l centralindia --sku Standard --vm-size C1

az storage account create -g wealthos-rg -n wealthosstorage --sku Standard_LRS --kind StorageV2 --https-only true

az acr create -g wealthos-rg -n wealthosacr --sku Standard

az appservice plan create -g wealthos-rg -n wealthos-plan --is-linux --sku P1v3

az webapp create -g wealthos-rg -p wealthos-plan -n wealthos-api --deployment-container-image-name wealthosacr.azurecr.io/wealthos-api:latest
az webapp create -g wealthos-rg -p wealthos-plan -n wealthos-web --deployment-container-image-name wealthosacr.azurecr.io/wealthos-web:latest

az webapp deployment slot create -g wealthos-rg -n wealthos-api -s staging
az webapp deployment slot create -g wealthos-rg -n wealthos-web -s staging

az keyvault create -g wealthos-rg -n wealthos-kv -l centralindia
az keyvault secret set --vault-name wealthos-kv -n DATABASE-URL --value "postgresql+asyncpg://..."
az keyvault secret set --vault-name wealthos-kv -n JWT-PRIVATE-KEY --value "@jwt_private.pem"

az webapp config appsettings set -g wealthos-rg -n wealthos-api --settings \
  DATABASE_URL="@Microsoft.KeyVault(SecretUri=https://wealthos-kv.vault.azure.net/secrets/DATABASE-URL/)" \
  REDIS_URL="rediss://wealthos-redis.redis.cache.windows.net:6380" \
  ENVIRONMENT="production"
```

### 4.3 Networking & Hardening
- All App Services deployed with VNet integration; Postgres and Redis have public network access **disabled**, reachable only via private endpoints inside the same VNet.
- Azure Front Door + WAF in front of `wealthos-web`/`wealthos-api`; App Services restrict inbound to Front Door's IP range only.
- Managed identities for App Services to access Key Vault — no secrets in app settings as plain text beyond the Key Vault reference.

### 4.4 Database Migrations in Production
- Migrations run as a one-off `az webapp ssh` / dedicated GitHub Actions job (`alembic upgrade head`) against a private-network runner **before** the slot swap, never inside the container's default start command (avoids concurrent migration races across scaled instances).

### 4.5 Observability
- Application Insights SDK in both FastAPI (OpenTelemetry) and Next.js for distributed tracing.
- Alerts: p95 latency > 1s for 5 min, 5xx rate > 1%, DB CPU > 80%, Redis memory > 80%, failed login spike (possible credential-stuffing).
- Structured JSON logs shipped to Log Analytics workspace; 90-day hot retention, archived to Blob for compliance retention.

---

## 5. Production Checklist
- [ ] All secrets in Key Vault, none in repo/app settings plaintext
- [ ] RLS enabled and tested on every user-owned table
- [ ] TLS enforced end-to-end, HSTS on
- [ ] Automated backups verified with a real restore drill
- [ ] Rate limiting active on auth + AI endpoints
- [ ] WAF rules tuned (no false-positive blocking of legit traffic) after 2-week staging soak
- [ ] Load test passed at 2x expected launch traffic
- [ ] Error monitoring + on-call alerting configured
- [ ] GDPR/DPDP data export & erasure endpoints tested
- [ ] Incident response runbook reviewed by team
- [ ] Rollback (slot-swap-back) tested in staging
- [ ] Accessibility audit (axe + manual) passed
- [ ] Legal: Privacy Policy, Terms of Service, cookie banner reviewed
- [ ] Support channel (email/chat) live before public launch
