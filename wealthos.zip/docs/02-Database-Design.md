# WealthOS — Database Design (PostgreSQL)

## 1. ER Diagram (Mermaid)

```mermaid
erDiagram
    USERS ||--o{ ACCOUNTS : owns
    USERS ||--o{ TRANSACTIONS : creates
    USERS ||--o{ ASSETS : owns
    USERS ||--o{ LIABILITIES : owns
    USERS ||--o{ GOALS : sets
    USERS ||--o{ BUDGETS : plans
    USERS ||--o{ BILLS : tracks
    USERS ||--o{ SUBSCRIPTIONS : tracks
    USERS ||--o{ INSURANCE_POLICIES : holds
    USERS ||--o{ DOCUMENTS : uploads
    USERS ||--o{ CATEGORIES : customizes
    USERS ||--o{ AUDIT_LOGS : generates
    USERS ||--o{ NOTIFICATIONS : receives
    USERS ||--o{ AI_INSIGHTS : receives
    USERS ||--o{ SESSIONS : has
    USERS }o--|| ROLES : has

    ACCOUNTS ||--o{ TRANSACTIONS : records
    ACCOUNTS ||--o{ RECURRING_TRANSACTIONS : schedules

    TRANSACTIONS }o--|| CATEGORIES : classified_by
    TRANSACTIONS }o--o{ TAGS : tagged_with
    TRANSACTIONS ||--o{ TRANSACTION_SPLITS : splits_into
    TRANSACTIONS ||--o{ RECEIPTS : has
    TRANSACTIONS }o--o| GOALS : contributes_to

    CATEGORIES ||--o{ CATEGORIES : parent_of
    CATEGORIES ||--o{ BUDGET_ITEMS : used_in

    BUDGETS ||--o{ BUDGET_ITEMS : contains

    ASSETS }o--|| ASSET_TYPES : typed_as
    ASSETS ||--o{ ASSET_VALUATIONS : valued_over_time

    LIABILITIES }o--|| LIABILITY_TYPES : typed_as
    LIABILITIES ||--o{ LOAN_PAYMENTS : paid_via

    GOALS ||--o{ GOAL_CONTRIBUTIONS : funded_by

    BILLS ||--o{ BILL_PAYMENTS : paid_via

    DOCUMENTS }o--o| ASSETS : attached_to
    DOCUMENTS }o--o| LIABILITIES : attached_to
    DOCUMENTS }o--o| INSURANCE_POLICIES : attached_to

    USERS {
        uuid id PK
        string email UK
        string password_hash
        string full_name
        string auth_provider
        string google_id
        boolean is_verified
        boolean two_factor_enabled
        string base_currency
        string country_code
        uuid role_id FK
        timestamptz created_at
        timestamptz updated_at
        timestamptz deleted_at
    }

    ACCOUNTS {
        uuid id PK
        uuid user_id FK
        string account_type
        string name
        string institution_name
        numeric current_balance
        string currency
        string source
        string external_account_id
        boolean is_active
        timestamptz created_at
    }

    TRANSACTIONS {
        uuid id PK
        uuid user_id FK
        uuid account_id FK
        uuid category_id FK
        string type
        numeric amount
        string currency
        date transaction_date
        text notes
        boolean is_recurring
        uuid recurring_id FK
        uuid goal_id FK
        timestamptz created_at
        timestamptz updated_at
    }

    CATEGORIES {
        uuid id PK
        uuid user_id FK
        uuid parent_id FK
        string name
        string type
        string icon
        boolean is_system_default
    }

    ASSETS {
        uuid id PK
        uuid user_id FK
        uuid asset_type_id FK
        string name
        numeric quantity
        numeric current_value
        numeric purchase_value
        date purchase_date
        jsonb metadata
        timestamptz created_at
    }

    LIABILITIES {
        uuid id PK
        uuid user_id FK
        uuid liability_type_id FK
        string name
        numeric principal_amount
        numeric outstanding_amount
        numeric interest_rate
        date start_date
        date end_date
        numeric emi_amount
    }

    GOALS {
        uuid id PK
        uuid user_id FK
        string goal_type
        string name
        numeric target_amount
        numeric current_amount
        date target_date
        string status
    }
```

---

## 2. Full Table Definitions (DDL)

```sql
-- ============================================================
-- EXTENSIONS
-- ============================================================
CREATE EXTENSION IF NOT EXISTS "pgcrypto";   -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS "pg_trgm";    -- fuzzy search on notes/names

-- ============================================================
-- ROLES & USERS
-- ============================================================
CREATE TABLE roles (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(50) UNIQUE NOT NULL,     -- 'owner','admin','member','viewer'
    permissions     JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE users (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email                VARCHAR(255) UNIQUE NOT NULL,
    password_hash        VARCHAR(255),                 -- null if google-only
    full_name            VARCHAR(150) NOT NULL,
    phone                VARCHAR(20),
    auth_provider        VARCHAR(20) NOT NULL DEFAULT 'email', -- 'email','google'
    google_id            VARCHAR(255) UNIQUE,
    is_verified          BOOLEAN NOT NULL DEFAULT FALSE,
    two_factor_enabled   BOOLEAN NOT NULL DEFAULT FALSE,
    two_factor_secret    VARCHAR(255),
    base_currency         CHAR(3) NOT NULL DEFAULT 'INR',
    country_code          CHAR(2) NOT NULL DEFAULT 'IN',
    timezone              VARCHAR(50) NOT NULL DEFAULT 'Asia/Kolkata',
    role_id               UUID NOT NULL REFERENCES roles(id),
    plan_tier              VARCHAR(20) NOT NULL DEFAULT 'free', -- free/premium/family
    is_active              BOOLEAN NOT NULL DEFAULT TRUE,
    last_login_at          TIMESTAMPTZ,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at              TIMESTAMPTZ                    -- soft delete
);
CREATE INDEX idx_users_email ON users(email) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_role ON users(role_id);

CREATE TABLE sessions (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id           UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    refresh_token_hash VARCHAR(255) NOT NULL,
    user_agent        VARCHAR(255),
    ip_address        INET,
    is_revoked        BOOLEAN NOT NULL DEFAULT FALSE,
    expires_at        TIMESTAMPTZ NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_sessions_token ON sessions(refresh_token_hash);

CREATE TABLE password_resets (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash  VARCHAR(255) NOT NULL,
    expires_at  TIMESTAMPTZ NOT NULL,
    used_at     TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE audit_logs (
    id           BIGSERIAL PRIMARY KEY,
    user_id      UUID REFERENCES users(id) ON DELETE SET NULL,
    action        VARCHAR(100) NOT NULL,     -- 'LOGIN','TXN_CREATE','ASSET_UPDATE',...
    entity_type   VARCHAR(50),
    entity_id     UUID,
    ip_address    INET,
    user_agent    VARCHAR(255),
    metadata      JSONB,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_user_date ON audit_logs(user_id, created_at DESC);

-- ============================================================
-- ACCOUNTS (Bank / Cash / Credit Card)
-- ============================================================
CREATE TABLE accounts (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id              UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    account_type         VARCHAR(30) NOT NULL CHECK (account_type IN
                          ('bank_savings','bank_current','cash_wallet','credit_card')),
    name                 VARCHAR(100) NOT NULL,
    institution_name     VARCHAR(100),
    account_number_last4 VARCHAR(4),
    current_balance      NUMERIC(18,2) NOT NULL DEFAULT 0,
    credit_limit         NUMERIC(18,2),               -- for credit cards
    currency             CHAR(3) NOT NULL DEFAULT 'INR',
    source               VARCHAR(20) NOT NULL DEFAULT 'manual' CHECK (source IN ('manual','aggregator')),
    external_account_id  VARCHAR(255),                -- future bank-sync ready
    is_active             BOOLEAN NOT NULL DEFAULT TRUE,
    created_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_accounts_user ON accounts(user_id) WHERE is_active = TRUE;

-- ============================================================
-- CATEGORIES / TAGS
-- ============================================================
CREATE TABLE categories (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id           UUID REFERENCES users(id) ON DELETE CASCADE,  -- null = system default
    parent_id         UUID REFERENCES categories(id) ON DELETE CASCADE,
    name              VARCHAR(100) NOT NULL,
    type              VARCHAR(10) NOT NULL CHECK (type IN ('income','expense')),
    icon              VARCHAR(50),
    color             VARCHAR(7),
    is_system_default BOOLEAN NOT NULL DEFAULT FALSE,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(user_id, parent_id, name)
);
CREATE INDEX idx_categories_user ON categories(user_id);

CREATE TABLE tags (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name       VARCHAR(50) NOT NULL,
    color      VARCHAR(7),
    UNIQUE(user_id, name)
);

-- ============================================================
-- RECURRING TEMPLATES
-- ============================================================
CREATE TABLE recurring_transactions (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    account_id       UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    category_id      UUID REFERENCES categories(id),
    type             VARCHAR(10) NOT NULL CHECK (type IN ('income','expense')),
    amount           NUMERIC(18,2) NOT NULL,
    frequency        VARCHAR(20) NOT NULL CHECK (frequency IN ('daily','weekly','biweekly','monthly','yearly')),
    next_run_date    DATE NOT NULL,
    end_date         DATE,
    is_active        BOOLEAN NOT NULL DEFAULT TRUE,
    notes            TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_recurring_next_run ON recurring_transactions(next_run_date) WHERE is_active = TRUE;

-- ============================================================
-- TRANSACTIONS (Income + Expense + Transfer)
-- ============================================================
CREATE TABLE transactions (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id           UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    account_id        UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    category_id       UUID REFERENCES categories(id),
    type              VARCHAR(10) NOT NULL CHECK (type IN ('income','expense','transfer')),
    income_source     VARCHAR(30) CHECK (income_source IN
                       ('salary','freelance','rental','dividend','interest','other')),
    amount            NUMERIC(18,2) NOT NULL CHECK (amount > 0),
    currency          CHAR(3) NOT NULL DEFAULT 'INR',
    transaction_date  DATE NOT NULL,
    merchant          VARCHAR(150),
    notes             TEXT,
    is_recurring      BOOLEAN NOT NULL DEFAULT FALSE,
    recurring_id      UUID REFERENCES recurring_transactions(id) ON DELETE SET NULL,
    goal_id           UUID,                             -- FK added after goals table
    transfer_account_id UUID REFERENCES accounts(id),   -- for transfer type
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at        TIMESTAMPTZ
);
CREATE INDEX idx_txn_user_date ON transactions(user_id, transaction_date DESC) WHERE deleted_at IS NULL;
CREATE INDEX idx_txn_account ON transactions(account_id);
CREATE INDEX idx_txn_category ON transactions(category_id);
CREATE INDEX idx_txn_notes_trgm ON transactions USING gin (notes gin_trgm_ops);

CREATE TABLE transaction_tags (
    transaction_id UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
    tag_id         UUID NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (transaction_id, tag_id)
);

CREATE TABLE transaction_splits (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_id UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
    category_id    UUID REFERENCES categories(id),
    amount         NUMERIC(18,2) NOT NULL CHECK (amount > 0),
    notes          VARCHAR(255)
);
CREATE INDEX idx_splits_txn ON transaction_splits(transaction_id);

CREATE TABLE receipts (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_id UUID NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
    file_url       VARCHAR(500) NOT NULL,               -- Azure Blob URL
    file_size_kb   INTEGER,
    uploaded_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================
-- ASSETS
-- ============================================================
CREATE TABLE asset_types (
    id    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code  VARCHAR(30) UNIQUE NOT NULL,   -- 'mutual_fund','stock','gold','silver','fd','ppf','epf','nps','real_estate','crypto','bond','vehicle','other'
    label VARCHAR(100) NOT NULL,
    category VARCHAR(20) NOT NULL       -- 'investment','physical','retirement','other'
);

CREATE TABLE assets (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    asset_type_id   UUID NOT NULL REFERENCES asset_types(id),
    name            VARCHAR(150) NOT NULL,
    quantity        NUMERIC(18,4),                 -- units/shares/grams
    purchase_value  NUMERIC(18,2),
    current_value   NUMERIC(18,2) NOT NULL,
    purchase_date   DATE,
    maturity_date   DATE,                          -- FD/PPF/Bonds
    interest_rate   NUMERIC(5,2),
    institution      VARCHAR(150),
    metadata         JSONB NOT NULL DEFAULT '{}',   -- flexible: folio no., ticker, address, VIN, etc.
    is_active         BOOLEAN NOT NULL DEFAULT TRUE,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_assets_user ON assets(user_id) WHERE is_active = TRUE;
CREATE INDEX idx_assets_type ON assets(asset_type_id);

CREATE TABLE asset_valuations (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    asset_id    UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
    value        NUMERIC(18,2) NOT NULL,
    valued_at    DATE NOT NULL,
    source        VARCHAR(20) NOT NULL DEFAULT 'manual',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(asset_id, valued_at)
);
CREATE INDEX idx_valuations_asset_date ON asset_valuations(asset_id, valued_at DESC);

-- ============================================================
-- LIABILITIES
-- ============================================================
CREATE TABLE liability_types (
    id    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code  VARCHAR(30) UNIQUE NOT NULL,  -- 'home_loan','personal_loan','education_loan','car_loan','credit_card_debt','other'
    label VARCHAR(100) NOT NULL
);

CREATE TABLE liabilities (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    liability_type_id   UUID NOT NULL REFERENCES liability_types(id),
    name                VARCHAR(150) NOT NULL,
    lender              VARCHAR(150),
    principal_amount    NUMERIC(18,2) NOT NULL,
    outstanding_amount  NUMERIC(18,2) NOT NULL,
    interest_rate       NUMERIC(5,2),
    emi_amount          NUMERIC(18,2),
    tenure_months       INTEGER,
    start_date          DATE,
    end_date            DATE,
    is_active            BOOLEAN NOT NULL DEFAULT TRUE,
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (outstanding_amount >= 0)
);
CREATE INDEX idx_liabilities_user ON liabilities(user_id) WHERE is_active = TRUE;

CREATE TABLE loan_payments (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    liability_id   UUID NOT NULL REFERENCES liabilities(id) ON DELETE CASCADE,
    amount         NUMERIC(18,2) NOT NULL,
    principal_component NUMERIC(18,2),
    interest_component  NUMERIC(18,2),
    payment_date    DATE NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_loan_payments_liability ON loan_payments(liability_id, payment_date DESC);

-- ============================================================
-- GOALS
-- ============================================================
CREATE TABLE goals (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    goal_type      VARCHAR(30) NOT NULL CHECK (goal_type IN
                    ('emergency_fund','house','car','vacation','retirement','child_education','custom')),
    name           VARCHAR(150) NOT NULL,
    target_amount  NUMERIC(18,2) NOT NULL,
    current_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
    target_date    DATE,
    linked_account_id UUID REFERENCES accounts(id),
    status          VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active','completed','paused','cancelled')),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_goals_user ON goals(user_id);

ALTER TABLE transactions
  ADD CONSTRAINT fk_txn_goal FOREIGN KEY (goal_id) REFERENCES goals(id) ON DELETE SET NULL;

CREATE TABLE goal_contributions (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    goal_id      UUID NOT NULL REFERENCES goals(id) ON DELETE CASCADE,
    transaction_id UUID REFERENCES transactions(id) ON DELETE SET NULL,
    amount        NUMERIC(18,2) NOT NULL,
    contributed_at DATE NOT NULL DEFAULT CURRENT_DATE
);
CREATE INDEX idx_goal_contrib_goal ON goal_contributions(goal_id);

-- ============================================================
-- BUDGET PLANNER
-- ============================================================
CREATE TABLE budgets (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    period_type VARCHAR(10) NOT NULL DEFAULT 'monthly' CHECK (period_type IN ('monthly','yearly')),
    period_start DATE NOT NULL,
    period_end   DATE NOT NULL,
    total_planned NUMERIC(18,2),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(user_id, period_start, period_end)
);

CREATE TABLE budget_items (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    budget_id    UUID NOT NULL REFERENCES budgets(id) ON DELETE CASCADE,
    category_id  UUID NOT NULL REFERENCES categories(id),
    planned_amount NUMERIC(18,2) NOT NULL,
    UNIQUE(budget_id, category_id)
);
CREATE INDEX idx_budget_items_budget ON budget_items(budget_id);

-- ============================================================
-- BILLS & SUBSCRIPTIONS
-- ============================================================
CREATE TABLE bills (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name         VARCHAR(150) NOT NULL,
    amount       NUMERIC(18,2) NOT NULL,
    due_date     DATE NOT NULL,
    frequency    VARCHAR(20) NOT NULL DEFAULT 'monthly',
    category_id  UUID REFERENCES categories(id),
    account_id   UUID REFERENCES accounts(id),
    is_autopay   BOOLEAN NOT NULL DEFAULT FALSE,
    is_active    BOOLEAN NOT NULL DEFAULT TRUE,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_bills_due ON bills(user_id, due_date) WHERE is_active = TRUE;

CREATE TABLE bill_payments (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    bill_id     UUID NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
    transaction_id UUID REFERENCES transactions(id) ON DELETE SET NULL,
    paid_amount NUMERIC(18,2) NOT NULL,
    paid_date   DATE NOT NULL
);

CREATE TABLE subscriptions (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name          VARCHAR(150) NOT NULL,
    amount        NUMERIC(18,2) NOT NULL,
    billing_cycle VARCHAR(20) NOT NULL DEFAULT 'monthly' CHECK (billing_cycle IN ('monthly','yearly','weekly')),
    next_billing_date DATE,
    category_id   UUID REFERENCES categories(id),
    account_id    UUID REFERENCES accounts(id),
    is_active     BOOLEAN NOT NULL DEFAULT TRUE,
    cancel_url    VARCHAR(500),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_subs_user ON subscriptions(user_id) WHERE is_active = TRUE;

-- ============================================================
-- INSURANCE
-- ============================================================
CREATE TABLE insurance_policies (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    policy_type    VARCHAR(30) NOT NULL CHECK (policy_type IN ('life','health','vehicle','home','term','other')),
    provider       VARCHAR(150),
    policy_number  VARCHAR(100),
    sum_assured    NUMERIC(18,2),
    premium_amount NUMERIC(18,2),
    premium_frequency VARCHAR(20) DEFAULT 'yearly',
    start_date     DATE,
    renewal_date   DATE,
    is_active      BOOLEAN NOT NULL DEFAULT TRUE,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_insurance_user ON insurance_policies(user_id);

-- ============================================================
-- TAX PLANNER
-- ============================================================
CREATE TABLE tax_profiles (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    financial_year  VARCHAR(9) NOT NULL,          -- '2025-2026'
    regime          VARCHAR(10) DEFAULT 'new',    -- India-specific 'old'/'new'; extensible
    gross_income    NUMERIC(18,2),
    deductions      JSONB NOT NULL DEFAULT '{}',  -- {"80C": 150000, "80D": 25000, ...}
    estimated_tax   NUMERIC(18,2),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(user_id, financial_year)
);

-- ============================================================
-- DOCUMENT VAULT
-- ============================================================
CREATE TABLE documents (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title           VARCHAR(200) NOT NULL,
    doc_type        VARCHAR(50),                  -- 'insurance','loan','tax','identity','other'
    file_url        VARCHAR(500) NOT NULL,
    file_size_kb    INTEGER,
    linked_entity_type VARCHAR(30),                -- 'asset','liability','insurance_policy'
    linked_entity_id   UUID,
    expiry_date      DATE,
    is_encrypted     BOOLEAN NOT NULL DEFAULT TRUE,
    uploaded_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_documents_user ON documents(user_id);
CREATE INDEX idx_documents_linked ON documents(linked_entity_type, linked_entity_id);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================
CREATE TABLE notifications (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type        VARCHAR(50) NOT NULL,     -- 'bill_due','budget_exceeded','goal_milestone','ai_insight'
    title       VARCHAR(200) NOT NULL,
    body        TEXT,
    is_read     BOOLEAN NOT NULL DEFAULT FALSE,
    action_url  VARCHAR(500),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notifications_user_unread ON notifications(user_id, is_read);

-- ============================================================
-- AI INSIGHTS
-- ============================================================
CREATE TABLE ai_insights (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    insight_type VARCHAR(50) NOT NULL,   -- 'monthly_summary','overspend_alert','saving_tip','allocation_suggestion'
    period_start DATE,
    period_end   DATE,
    content      JSONB NOT NULL,          -- structured payload rendered by frontend
    is_dismissed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_ai_insights_user_date ON ai_insights(user_id, created_at DESC);

CREATE TABLE financial_health_scores (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    score          INTEGER NOT NULL CHECK (score BETWEEN 0 AND 100),
    components     JSONB NOT NULL,   -- {"savings_rate":80,"debt_ratio":70,"emergency_fund":60,...}
    calculated_at   DATE NOT NULL DEFAULT CURRENT_DATE,
    UNIQUE(user_id, calculated_at)
);
```

---

## 3. Triggers & Functions

```sql
-- Generic updated_at trigger
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_accounts_updated_at BEFORE UPDATE ON accounts
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_transactions_updated_at BEFORE UPDATE ON transactions
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_assets_updated_at BEFORE UPDATE ON assets
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_goals_updated_at BEFORE UPDATE ON goals
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Keep account.current_balance in sync with transactions
CREATE OR REPLACE FUNCTION apply_transaction_to_balance()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF NEW.type = 'income' THEN
            UPDATE accounts SET current_balance = current_balance + NEW.amount WHERE id = NEW.account_id;
        ELSIF NEW.type = 'expense' THEN
            UPDATE accounts SET current_balance = current_balance - NEW.amount WHERE id = NEW.account_id;
        ELSIF NEW.type = 'transfer' THEN
            UPDATE accounts SET current_balance = current_balance - NEW.amount WHERE id = NEW.account_id;
            UPDATE accounts SET current_balance = current_balance + NEW.amount WHERE id = NEW.transfer_account_id;
        END IF;
    ELSIF TG_OP = 'DELETE' THEN
        IF OLD.type = 'income' THEN
            UPDATE accounts SET current_balance = current_balance - OLD.amount WHERE id = OLD.account_id;
        ELSIF OLD.type = 'expense' THEN
            UPDATE accounts SET current_balance = current_balance + OLD.amount WHERE id = OLD.account_id;
        ELSIF OLD.type = 'transfer' THEN
            UPDATE accounts SET current_balance = current_balance + OLD.amount WHERE id = OLD.account_id;
            UPDATE accounts SET current_balance = current_balance - OLD.amount WHERE id = OLD.transfer_account_id;
        END IF;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_txn_balance_insert
    AFTER INSERT ON transactions FOR EACH ROW
    WHEN (NEW.deleted_at IS NULL)
    EXECUTE FUNCTION apply_transaction_to_balance();

CREATE TRIGGER trg_txn_balance_delete
    AFTER DELETE ON transactions FOR EACH ROW
    EXECUTE FUNCTION apply_transaction_to_balance();

-- Auto-update goal.current_amount on contribution
CREATE OR REPLACE FUNCTION apply_goal_contribution()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE goals SET current_amount = current_amount + NEW.amount, updated_at = now()
    WHERE id = NEW.goal_id;
    IF (SELECT current_amount >= target_amount FROM goals WHERE id = NEW.goal_id) THEN
        UPDATE goals SET status = 'completed' WHERE id = NEW.goal_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_goal_contribution AFTER INSERT ON goal_contributions
    FOR EACH ROW EXECUTE FUNCTION apply_goal_contribution();

-- Prevent negative outstanding liability
CREATE OR REPLACE FUNCTION apply_loan_payment()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE liabilities
    SET outstanding_amount = GREATEST(outstanding_amount - NEW.principal_component, 0)
    WHERE id = NEW.liability_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_loan_payment AFTER INSERT ON loan_payments
    FOR EACH ROW EXECUTE FUNCTION apply_loan_payment();
```

---

## 4. Row-Level Security (multi-tenant isolation)

```sql
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE liabilities ENABLE ROW LEVEL SECURITY;
ALTER TABLE goals ENABLE ROW LEVEL SECURITY;
-- (repeat for all user-owned tables)

CREATE POLICY user_isolation_txn ON transactions
    USING (user_id = current_setting('app.current_user_id')::uuid);

CREATE POLICY user_isolation_accounts ON accounts
    USING (user_id = current_setting('app.current_user_id')::uuid);
-- FastAPI sets `SET app.current_user_id = '<uuid>'` per request/connection (via SQLAlchemy event listener)
```

## 5. Indexing Strategy Summary
- All `user_id` foreign keys indexed (primary access pattern is "give me user X's data")
- Composite `(user_id, date DESC)` indexes on time-series tables (transactions, valuations, loan_payments) for dashboard range queries
- Partial indexes with `WHERE is_active = TRUE` / `WHERE deleted_at IS NULL` to keep indexes small and fast
- `pg_trgm` GIN index on transaction notes for fuzzy natural-language search support
- `UNIQUE` constraints double as indexes (e.g., email, budget period, asset valuation per day)

## 6. Data Integrity Constraints Summary
- `CHECK` constraints on all enumerated string fields (type, status, frequency) — safer than free text, faster than a lookup join for small fixed sets
- `CHECK (amount > 0)` on transactions/splits — sign is carried by `type`, not the amount
- Soft delete (`deleted_at`) on `users` and `transactions` to preserve audit trail and support "recently deleted" recovery
- Cascading deletes only on strictly child-owned rows (e.g., transaction_splits, receipts); `SET NULL` used where the parent-child relationship is a soft link (e.g., recurring_id)
