# WealthOS — Security Design

## 1. Threat Model Summary
Primary assets to protect: user PII, account balances/transaction history, uploaded documents (identity/insurance/loan docs), and auth credentials. Primary threats: account takeover, cross-tenant data leakage, injection attacks, insecure file storage, and LLM prompt-injection/data-exfiltration via the AI Assistant.

## 2. Authentication
- **Password auth:** bcrypt (cost factor 12) hashing; never store plaintext. Passwords require min 10 chars, checked against a breached-password list (e.g., HaveIBeenPwned k-anonymity API) at signup.
- **JWT strategy:** short-lived **access token** (15 min, signed RS256) + long-lived **refresh token** (30 days, rotated on every use, stored **hashed** in `sessions` table so a DB leak doesn't yield usable tokens). Refresh reuse detection: if a used/rotated refresh token is presented again, all sessions for that user are revoked (token-theft signal).
- **Google OAuth:** server-side authorization-code exchange (not implicit flow); verify `id_token` signature and audience server-side before issuing WealthOS JWTs.
- **Password reset:** single-use, hashed, 15-minute-expiry token emailed via signed link; invalidates all active sessions on successful reset.
- **2FA (TOTP):** RFC 6238 TOTP, secret encrypted at rest (AES-256-GCM via app-level encryption, key from Azure Key Vault), backup codes hashed like passwords. Enforceable per-user or org-wide (future Team tier).

## 3. Authorization
- **RBAC:** `roles` table with JSON permission maps (`owner`, `admin`, `member`, `viewer` — relevant once shared/family accounts ship). Every endpoint declares required permission via a FastAPI dependency (`require_permission("transactions:write")`).
- **Row Level Security (Postgres):** enabled on every user-owned table (see doc 02 §4) as defense-in-depth beneath the application layer — protects against ORM bugs, ad-hoc queries, and future microservice mistakes.
- **Object-level checks:** every service method re-verifies `resource.user_id == current_user.id` even though RLS would also block it — belt-and-suspenders.

## 4. Data Protection
- **Encryption in transit:** TLS 1.3 everywhere (enforced at Azure Front Door + App Service); HSTS enabled.
- **Encryption at rest:** Azure PostgreSQL Flexible Server transparent data encryption; Azure Blob Storage encryption with Microsoft-managed or customer-managed keys (CMK via Key Vault for enterprise tier).
- **Field-level encryption:** highly sensitive fields (2FA secret, bank account last-4 already masked, any future full account numbers) encrypted at the application layer with AES-256-GCM before storage; keys rotated via Azure Key Vault.
- **Document Vault:** files stored in a private Blob container, never public; access via short-lived (5 min) SAS tokens generated per-request after an authorization check.
- **PII minimization for AI:** the AI Gateway only receives aggregated/category-level JSON (e.g., `{"category":"Food","month":"2026-05","total":18420}`), never raw account numbers, names, or free-text notes containing PII, and prompts are constructed server-side (not user-controlled) to prevent prompt injection from altering system instructions.
- **Backups:** automated daily encrypted backups (Azure PostgreSQL, 35-day retention), point-in-time restore enabled.

## 5. Application Security (OWASP-aligned)
| Risk | Mitigation |
|---|---|
| SQL Injection | SQLAlchemy parameterized queries only; no raw string interpolation, especially in AI-generated query paths |
| Broken Access Control | RBAC + RLS + per-request object ownership checks |
| XSS | React auto-escaping; strict CSP headers; sanitize any rendered markdown from AI responses |
| CSRF | JWT in `Authorization` header (not cookies) for API calls; if cookies used for web session, `SameSite=Strict` + CSRF token |
| SSRF | Outbound requests (e.g., future bank aggregator calls) restricted via allow-list egress proxy |
| Insecure File Upload | File type/size validation, virus scan (Azure Defender/ClamAV) before storage, stored outside web root with randomized keys |
| Rate limiting / brute force | Redis-backed rate limiting on auth (10/min/IP) and AI endpoints (20/min/user); exponential backoff + account lockout after repeated failed logins |
| Sensitive data exposure in logs | Structured logging with PII redaction middleware (masks email, amounts optional, tokens always) |
| Dependency vulnerabilities | Automated `pip-audit`/`npm audit` + Dependabot in CI, blocking on critical CVEs |

## 6. Session Management
- Refresh tokens bound to device fingerprint (user-agent + IP subnet) with anomaly flag (new-location login triggers email alert).
- `sessions` table lists all active devices in Settings → Security; user can revoke any/all remotely.
- Idle session timeout: access token expiry (15 min) forces silent refresh; refresh token expires after 30 days of inactivity.

## 7. Audit Logging
- Every state-changing action (auth events, CRUD on financial data, document access, settings changes) written to `audit_logs` with actor, IP, user-agent, entity, and a JSON diff/metadata.
- Audit logs are append-only (no UPDATE/DELETE grants for the application DB role); retained ≥1 year for compliance.
- Admin/compliance export endpoint (future) for SOC 2 evidence collection.

## 8. Compliance Roadmap
- **GDPR:** right to access (`GET /users/me/export`), right to erasure (soft delete + scheduled hard purge after retention window), data processing agreement with sub-processors (Azure, LLM provider).
- **India DPDP Act:** consent capture at signup, data localization option (Azure India region), grievance officer contact in Settings.
- **SOC 2 Type II track:** access reviews, change management via CI/CD approvals, vendor risk assessment for Azure OpenAI/Anthropic API, incident response runbook (see below).

## 9. Incident Response (summary runbook)
1. **Detect** — alerting on anomalous auth patterns, RLS policy violations (should be zero), error-rate spikes.
2. **Contain** — ability to globally revoke sessions for an affected user or force password reset org-wide.
3. **Eradicate/Recover** — rotate compromised keys/secrets via Key Vault, patch, restore from point-in-time backup if data integrity affected.
4. **Notify** — breach notification workflow within regulatory timelines (72h GDPR).
5. **Post-mortem** — blameless review, audit log reconstruction of the incident timeline.

## 10. Secrets Management
- No secrets in source control; `.env` files git-ignored, secrets injected via Azure App Service Configuration + Azure Key Vault references.
- Separate secrets per environment (dev/staging/prod); prod secrets accessible only to CI/CD service principal and break-glass admin accounts.
