# WealthOS — UI/UX Design System & Wireframes

## 1. Design Principles
- **Clarity over density** — financial data is anxiety-inducing by default; generous whitespace, clear hierarchy, calm color use.
- **Glassmorphism, used sparingly** — frosted-glass cards for key summary widgets (Net Worth, Health Score) on a soft gradient backdrop; flat surfaces elsewhere for readability of dense tables.
- **Mobile-first** — every screen designed at 375px width first, then expanded to tablet/desktop breakpoints.
- **Trust signals** — lock icons on sensitive actions, subtle "last synced" timestamps, visible encryption badge in Settings.

## 2. Design Tokens

```
Color (Light)
  --bg-base:        #F7F8FA
  --surface:         rgba(255,255,255,0.65)   /* glass card */
  --surface-solid:    #FFFFFF
  --border:            rgba(15,23,42,0.08)
  --text-primary:      #0F172A
  --text-secondary:    #64748B
  --accent-primary:    #4F46E5   /* indigo — primary actions */
  --accent-success:    #059669   /* income / positive */
  --accent-danger:      #DC2626   /* expense / negative */
  --accent-warning:      #D97706   /* bills due / alerts */

Color (Dark)
  --bg-base:          #0B0F19
  --surface:           rgba(30,41,59,0.55)
  --surface-solid:      #111827
  --border:              rgba(255,255,255,0.08)
  --text-primary:        #F1F5F9
  --text-secondary:      #94A3B8
  --accent-primary:      #818CF8
  --accent-success:      #34D399
  --accent-danger:        #F87171

Typography: Inter (UI text), Cal Sans / Satoshi (headings/numbers)
  H1 32/40 700   H2 24/32 600   H3 18/26 600
  Body 14/20 400  Caption 12/16 400  Number-display (net worth) 40/44 700 tabular-nums

Radius: sm 8px · md 12px · lg 20px (glass cards) · full (pills/avatars)
Shadow (glass card): 0 8px 32px rgba(0,0,0,0.08), inset border 1px rgba(255,255,255,0.4)
Spacing scale: 4 / 8 / 12 / 16 / 24 / 32 / 48 / 64
Motion: 150ms ease-out (micro), 300ms ease-in-out (panel/page transitions), respects prefers-reduced-motion
```

## 3. Navigation Structure

**Desktop:** Fixed left sidebar (icons + labels, collapsible) + top bar (global search, notifications bell, AI Assistant quick-launch, avatar/theme toggle).
**Mobile:** Bottom tab bar — Dashboard · Transactions · Add (center FAB) · Assistant · More (drawer with remaining modules).

```
Sidebar groups:
  Overview      → Dashboard, Analytics, Calendar
  Money         → Income, Expenses, Accounts, Budget, Bills, Subscriptions
  Wealth        → Assets, Liabilities, Goals, Insurance
  Planning      → Tax Planner, Reports, Document Vault
  Assistant     → AI Assistant
  System        → Notifications, Settings, Profile
```

## 4. Key Screen Wireframes (ASCII layout)

### 4.1 Dashboard (Desktop, 1440px)
```
┌─ Sidebar ─┬────────────────────────────────────────────────────────────┐
│ Logo      │  Good evening, Aditi        🔍 Search   🔔  🤖 Ask AI  🌙 ⚙ │
│           ├────────────────────────────────────────────────────────────┤
│ Overview  │ ┌─ Net Worth (glass) ──────┐ ┌─ Health Score (glass) ─────┐ │
│ Money     │ │  ₹42,18,500   ▲ 3.2%     │ │   78 / 100  ●●●●○          │ │
│ Wealth    │ │  [sparkline 12mo]         │ │  Savings•Debt•Emergency    │ │
│ Planning  │ └───────────────────────────┘ └────────────────────────────┘ │
│ Assistant │ ┌─ Cash Flow this month ──────────────┐ ┌─ Goals ─────────┐ │
│ Settings  │ │ Income ₹1,85,000  Expense ₹1,12,400  │ │ Emergency 62%   │ │
│           │ │ [bar chart income vs expense]         │ │ House      31%  │ │
│           │ └────────────────────────────────────────┘ └──────────────┘ │
│           │ ┌─ Investment Value ──────┐ ┌─ Upcoming Bills ─────────────┐ │
│           │ │ ₹28,40,200  [alloc pie] │ │ Electricity  ₹2,100  Jul 14  │ │
│           │ └──────────────────────────┘ │ Netflix       ₹649  Jul 18  │ │
│           │ ┌─ Recent Transactions ────────────────────────────────────┐│
│           │ │ Blue Tokai   -₹450   Food        Today                  ││
│           │ │ Salary Credit +₹1,85,000  Income  Jul 1                 ││
│           │ └───────────────────────────────────────────────────────────┘│
└───────────┴────────────────────────────────────────────────────────────┘
```

### 4.2 Dashboard (Mobile, 375px)
```
┌──────────────────────────┐
│ Good evening, Aditi   🔔 │
├──────────────────────────┤
│ ┌─ Net Worth (glass) ───┐│
│ │ ₹42,18,500  ▲3.2%     ││
│ │ [sparkline]            ││
│ └─────────────────────────┘│
│ ┌─ Health Score ─────────┐│
│ │ 78/100 ●●●●○            ││
│ └─────────────────────────┘│
│ [Income vs Expense card]  │
│ [Goal progress cards →]   │
│ [Recent transactions]     │
├──────────────────────────┤
│ 🏠  📊  ➕  🤖  ☰          │
└──────────────────────────┘
```

### 4.3 Add Transaction (Bottom Sheet, Mobile)
```
┌──────────────────────────┐
│  ▾  Add Transaction       │
│  [Expense] [Income] [Transfer]
│  Amount:  ₹ ____________  │
│  Account: HDFC Savings ▾  │
│  Category: Food & Dining ▾│
│  Date: Today ▾             │
│  Tags: + add tag           │
│  📎 Attach receipt         │
│  Notes: ________________  │
│  ☐ Recurring                │
│  [ Save Transaction ]       │
└──────────────────────────┘
```

### 4.4 AI Assistant Panel
```
┌───────────────────────────────────────────┐
│  🤖 AI Assistant                            │
│  ┌───────────────────────────────────────┐ │
│  │ You: How much did I spend on food in   │ │
│  │      May?                               │ │
│  │ AI:  You spent ₹18,420 on Food &        │ │
│  │      Dining in May — 12% higher than    │ │
│  │      April. [see chart] [view txns]     │ │
│  │      [bar chart: Apr vs May food spend] │ │
│  └───────────────────────────────────────┘ │
│  Suggested: "Show my investment growth"     │
│             "What are my highest expenses?" │
│  [ Type a question...              ➤ ]     │
└───────────────────────────────────────────┘
```

### 4.5 Assets Module (Allocation view)
```
┌───────────────────────────────────────────────────┐
│  Assets                     [+ Add Asset]           │
│  ┌─ Allocation (donut) ─┐  Total: ₹28,40,200         │
│  │  MF 45% Stocks 20%    │                            │
│  │  Gold 10% FD 15% ...  │                            │
│  └───────────────────────┘                            │
│  ┌ Mutual Funds ───────────────────────────────────┐ │
│  │ Parag Parikh Flexi Cap   ₹3,12,500   ▲25%  [›]   │ │
│  │ Axis Bluechip            ₹1,85,000   ▲12%  [›]   │ │
│  └───────────────────────────────────────────────────┘│
│  [ Stocks ]  [ Gold ]  [ FD ]  [ PPF ]  [ EPF ] ...    │
└───────────────────────────────────────────────────────┘
```

## 5. Component Inventory
- `GlassCard`, `StatTile`, `Sparkline`, `DonutChart`, `BarComparisonChart`, `TrendLine`
- `TransactionRow`, `TransactionForm(BottomSheet/Modal)`, `SplitEditor`, `ReceiptUploader`
- `GoalProgressCard`, `BudgetProgressBar` (green→amber→red at 80%/100%)
- `AIChatBubble`, `AISuggestionChip`, `InsightCard`
- `CalendarMonthGrid`, `NotificationDrawer`, `ThemeToggle`, `EmptyState`, `Skeleton loaders` for every async widget

## 6. Responsive Breakpoints
| Breakpoint | Width | Layout |
|---|---|---|
| `xs` | <640px | Single column, bottom nav, bottom-sheet forms |
| `sm/md` | 640–1024px | 2-column dashboard grid, collapsible sidebar |
| `lg/xl` | >1024px | Full sidebar + 3-column dashboard grid |

## 7. Accessibility
- Minimum contrast 4.5:1 for body text, 3:1 for large numbers
- All interactive elements keyboard-navigable, visible focus ring
- Charts include an accessible data-table fallback (`aria-describedby`)
- Color is never the sole indicator (icons/labels accompany red/green amounts)
