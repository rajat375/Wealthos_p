# WealthOS — Product Requirements & System Architecture

## 1. Product Requirements Document (PRD)

### 1.1 Vision
WealthOS is an AI-powered personal finance and wealth management SaaS that lets a user track every financial asset, liability, income stream, and expense from a single dashboard, with AI-generated insights that make the numbers actionable. V1 is manual-entry-first; the architecture is bank-integration-ready (Plaid/Setu/Account Aggregator) for V2.

### 1.2 Target Users
- Salaried professionals tracking multi-asset portfolios (India + global assets)
- Freelancers/self-employed with irregular income
- Couples/families managing shared budgets and goals
- Power users migrating from spreadsheets who want automation + AI

### 1.3 Competitive Positioning
| Competitor | Strength | WealthOS Differentiator |
|---|---|---|
| INDmoney | Bank/broker aggregation | Deeper manual asset coverage (gold, PPF, EPF, NPS, real estate) + AI coach |
| ET Money | Mutual fund investing | Full net-worth + liabilities + goals in one place |
| Monarch Money | Clean UX, budgeting | AI natural-language search, financial health score |
| YNAB | Zero-based budgeting discipline | Combines budgeting with investment/net-worth tracking |

### 1.4 Success Metrics (North Star + supporting)
- North Star: **Weekly Active Net-Worth Updates** (users who add/verify a transaction or asset weekly)
- Activation: % of new users who add ≥3 accounts/assets within 7 days
- Retention: D30 / D90 retention
- Engagement: AI Assistant queries per active user/week
- Monetization: Free → Premium conversion rate

### 1.5 Functional Requirements Summary
See the **MODULES** and **AI FEATURES** sections below; each maps to epics in the Feature Roadmap (doc 07).

### 1.6 Non-Functional Requirements
- **Availability:** 99.9% uptime SLA (production)
- **Performance:** p95 API latency < 300ms for reads, < 800ms for writes; dashboard first paint < 2s
- **Scalability:** Horizontally scalable stateless API; supports 100K+ MAU on target infra without redesign
- **Security:** OWASP ASVS L2 baseline, encryption at rest & in transit, RBAC, audit trail
- **Accessibility:** WCAG 2.1 AA
- **Data residency:** Configurable region (default: user's country) — important for financial data compliance
- **Compliance readiness:** GDPR, DPDP Act (India), SOC 2 Type II track

### 1.7 Out of Scope (V1)
- Live bank/broker API sync (manual entry only; schema is sync-ready)
- Payment initiation / money movement
- Tax filing submission (planning/estimation only)
- Multi-currency real-time FX conversion (single base currency per user in V1)

---

## 2. System Architecture

### 2.1 High-Level Architecture

```
┌────────────────────────────────────────────────────────────────────┐
│                             CLIENTS                                  │
│   Next.js Web App (SSR/ISR)     Mobile-web (responsive PWA)          │
└───────────────────────────────┬──────────────────────────────────────┘
                                 │ HTTPS (TLS 1.3)
                                 ▼
                     ┌───────────────────────┐
                     │   Azure Front Door /   │  ← WAF, DDoS, CDN, rate limiting
                     │   Application Gateway  │
                     └──────────┬─────────────┘
                                 ▼
                     ┌───────────────────────┐
                     │  FastAPI App Service   │  ← Stateless, auto-scaled
                     │  (Uvicorn/Gunicorn)    │
                     │  ┌─────────────────┐   │
                     │  │ Auth Service    │   │
                     │  │ Core API (REST) │   │
                     │  │ AI Service      │───┼──► Azure OpenAI / LLM API
                     │  │ Notification Svc│───┼──► Email/Push (SendGrid, FCM)
                     │  │ Reports Engine  │   │
                     │  └─────────────────┘   │
                     └──────┬─────────┬────────┘
                             │         │
             ┌───────────────┘         └───────────────┐
             ▼                                          ▼
  ┌─────────────────────┐                   ┌───────────────────────┐
  │ Azure PostgreSQL     │                   │ Redis (Azure Cache)   │
  │ Flexible Server      │                   │ - session/rate limit  │
  │ (primary + replica)  │                   │ - AI response cache   │
  └─────────────────────┘                   └───────────────────────┘
             │
             ▼
  ┌─────────────────────┐        ┌───────────────────────┐
  │ Azure Blob Storage   │        │ Background Jobs        │
  │ (receipts, docs)     │        │ (Celery + Redis broker)│
  │ Encrypted at rest    │        │ - recurring txns        │
  └─────────────────────┘        │ - bill reminders         │
                                   │ - AI monthly summary     │
                                   │ - health-score recompute │
                                   └───────────────────────┘
```

### 2.2 Architecture Style
- **Backend:** Modular monolith (FastAPI) organized by domain modules, designed so any module (e.g., AI Service, Reports) can be extracted into a microservice later without rewrites. Avoids premature microservice overhead for V1 scale.
- **API:** REST (OpenAPI 3.1 auto-generated by FastAPI) + versioned (`/api/v1`). GraphQL not used in V1 to keep caching/security simpler.
- **Async processing:** Celery + Redis for recurring transactions, notifications, AI summary generation, and report exports — keeps request/response cycle fast.
- **Multi-tenancy model:** Single database, row-level isolation via `user_id` + PostgreSQL Row Level Security (RLS) policies. Enterprise/Team tier (future) can move to schema-per-tenant if needed.

### 2.3 Key Design Decisions
| Decision | Rationale |
|---|---|
| PostgreSQL over NoSQL | Financial data is highly relational (accounts↔transactions↔categories↔goals); need ACID transactions and constraints |
| SQLAlchemy 2.0 (async) + Alembic | Type-safe ORM, migration versioning, works natively with FastAPI async |
| JWT (access + refresh) over server sessions | Stateless scaling across App Service instances; refresh tokens stored hashed in DB for revocation |
| Row Level Security in Postgres | Defense-in-depth — even a buggy query can't leak cross-user data |
| Modular monolith | Faster V1 delivery; clean module boundaries allow later extraction |
| Bank-sync-ready schema | `account.source` enum (`manual`/`aggregator`) + `external_account_id` nullable column from day one |

### 2.4 AI Architecture
- **AI Gateway layer** inside the AI Service abstracts the LLM provider (Azure OpenAI / Anthropic API) behind an internal interface — enables provider swap without touching business logic.
- **Natural Language Search:** user query → intent classification → structured query builder (parameterized SQL via SQLAlchemy, never raw string interpolation) → results → LLM formats a natural-language answer citing the numbers.
- **Insights pipeline:** nightly Celery job aggregates spending/income deltas → feeds a structured JSON summary (not raw PII dump) to the LLM → generates coach tips, overspending alerts, saving suggestions → cached in `ai_insight` table.
- **Guardrails:** LLM never receives raw account numbers/PII identifiers; only anonymized aggregates and category-level data.

---

## 3. Folder Structure

```
wealthos/
├── apps/
│   ├── web/                          # Next.js frontend
│   │   ├── src/
│   │   │   ├── app/                  # App Router
│   │   │   │   ├── (auth)/login/
│   │   │   │   ├── (auth)/register/
│   │   │   │   ├── (dashboard)/dashboard/
│   │   │   │   ├── (dashboard)/income/
│   │   │   │   ├── (dashboard)/expenses/
│   │   │   │   ├── (dashboard)/accounts/
│   │   │   │   ├── (dashboard)/assets/
│   │   │   │   ├── (dashboard)/liabilities/
│   │   │   │   ├── (dashboard)/goals/
│   │   │   │   ├── (dashboard)/budget/
│   │   │   │   ├── (dashboard)/bills/
│   │   │   │   ├── (dashboard)/subscriptions/
│   │   │   │   ├── (dashboard)/insurance/
│   │   │   │   ├── (dashboard)/tax/
│   │   │   │   ├── (dashboard)/vault/
│   │   │   │   ├── (dashboard)/reports/
│   │   │   │   ├── (dashboard)/analytics/
│   │   │   │   ├── (dashboard)/calendar/
│   │   │   │   ├── (dashboard)/assistant/
│   │   │   │   ├── (dashboard)/settings/
│   │   │   │   └── layout.tsx
│   │   │   ├── components/
│   │   │   │   ├── ui/               # shadcn-style primitives
│   │   │   │   ├── charts/           # Recharts wrappers
│   │   │   │   ├── forms/
│   │   │   │   └── layout/
│   │   │   ├── lib/
│   │   │   │   ├── api-client.ts
│   │   │   │   ├── auth.ts
│   │   │   │   └── utils.ts
│   │   │   ├── hooks/
│   │   │   ├── store/                # Zustand/RTK
│   │   │   ├── types/
│   │   │   └── styles/
│   │   ├── public/
│   │   ├── tailwind.config.ts
│   │   ├── next.config.js
│   │   └── package.json
│   │
│   └── api/                          # FastAPI backend
│       ├── app/
│       │   ├── main.py
│       │   ├── core/
│       │   │   ├── config.py
│       │   │   ├── security.py       # JWT, hashing, RLS session var
│       │   │   ├── database.py
│       │   │   ├── redis.py
│       │   │   └── logging.py
│       │   ├── api/
│       │   │   └── v1/
│       │   │       ├── router.py
│       │   │       ├── auth/
│       │   │       ├── users/
│       │   │       ├── accounts/
│       │   │       ├── income/
│       │   │       ├── expenses/
│       │   │       ├── assets/
│       │   │       ├── liabilities/
│       │   │       ├── goals/
│       │   │       ├── budgets/
│       │   │       ├── bills/
│       │   │       ├── subscriptions/
│       │   │       ├── insurance/
│       │   │       ├── tax/
│       │   │       ├── documents/
│       │   │       ├── reports/
│       │   │       ├── analytics/
│       │   │       ├── notifications/
│       │   │       └── ai/
│       │   ├── models/               # SQLAlchemy ORM models
│       │   ├── schemas/              # Pydantic schemas
│       │   ├── services/             # business logic
│       │   ├── repositories/         # DB access layer
│       │   ├── tasks/                # Celery tasks
│       │   ├── ai/
│       │   │   ├── gateway.py
│       │   │   ├── nl_search.py
│       │   │   ├── insights.py
│       │   │   └── health_score.py
│       │   └── utils/
│       ├── alembic/
│       │   └── versions/
│       ├── tests/
│       │   ├── unit/
│       │   ├── integration/
│       │   └── e2e/
│       ├── requirements.txt
│       └── Dockerfile
│
├── infra/
│   ├── docker-compose.yml
│   ├── docker-compose.prod.yml
│   ├── terraform/                    # optional IaC for Azure
│   └── azure/
│       ├── app-service.bicep
│       └── postgres.bicep
│
├── .github/
│   └── workflows/
│       ├── ci.yml
│       └── cd.yml
│
├── docs/                             # this deliverable set
└── README.md
```

---

## 4. Primary User Flows

### 4.1 Onboarding Flow
1. Sign up (Email or Google OAuth) → email verification
2. Currency & country selection (drives default categories, tax rules)
3. Guided setup wizard: Add first bank account → Add first asset → Set first goal
4. Land on Dashboard (empty states with CTAs if skipped)

### 4.2 Add Transaction Flow
1. Tap "+" → choose Income/Expense/Transfer
2. Select account → amount → category/subcategory → tags (optional) → attach receipt (optional) → notes
3. Toggle "Recurring?" → set frequency if yes
4. Save → dashboard widgets (cash flow, budget progress, net worth) recompute async

### 4.3 Goal Creation Flow
1. Choose goal type (Emergency Fund, House, Car, Vacation, Retirement, Child Education, Custom)
2. Set target amount, target date, linked account(s)
3. AI suggests monthly contribution based on income/expense history
4. Track progress on Dashboard + Goals module

### 4.4 AI Assistant Flow
1. User types/asks a natural-language question in AI Assistant or global search bar
2. Query → intent classifier → parameterized data query → LLM composes answer with numbers/chart suggestion
3. Response rendered with inline chart + "view full report" link

### 4.5 Monthly Financial Summary Flow (automated)
1. Celery beat triggers on 1st of month
2. Aggregates prior month income/expense/investments/net-worth delta
3. LLM generates narrative summary + 3 actionable tips
4. Push notification + email + in-app card
