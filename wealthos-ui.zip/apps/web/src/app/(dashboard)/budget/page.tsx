"use client";

import { Calculator } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Skeleton } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { BudgetProgressBar } from "@/components/dashboard/BudgetProgressBar";
import { useBudget } from "@/hooks/useBudget";

export default function BudgetPage() {
  const { status, isLoading, error } = useBudget();

  if (isLoading) return <Skeleton className="h-64 w-full" />;

  if (error) {
    return (
      <Card>
        <p className="text-sm text-danger">Couldn&apos;t load your budget: {error}</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Budget</h1>
          <p className="text-sm text-text-secondary">Planned vs. actual spend this month</p>
        </div>
        <Button>{status ? "Edit Budget" : "Create Budget"}</Button>
      </div>

      <Card>
        {!status || status.items.length === 0 ? (
          <div className="flex flex-col items-center py-10 text-center">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Calculator size={20} />
            </div>
            <p className="text-sm text-text-secondary">
              No budget set for this month yet. Create one to track spending by category.
            </p>
          </div>
        ) : (
          <div className="space-y-5">
            {status.items.map((item) => (
              <BudgetProgressBar key={item.category_id} item={item} />
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
