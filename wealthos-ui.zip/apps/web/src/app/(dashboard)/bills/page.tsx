"use client";

import { motion } from "framer-motion";
import { CalendarCheck, Zap } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Skeleton } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/primitives";
import { useBills } from "@/hooks/useBills";
import { cn } from "@/lib/utils";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

function daysUntil(dateStr: string): number {
  const due = new Date(dateStr);
  const today = new Date();
  return Math.ceil((due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

export default function BillsPage() {
  const { bills, isLoading, error } = useBills();

  if (isLoading) return <Skeleton className="h-64 w-full" />;

  if (error) {
    return (
      <Card>
        <p className="text-sm text-danger">Couldn&apos;t load your bills: {error}</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Upcoming Bills</h1>
          <p className="text-sm text-text-secondary">Next 30 days</p>
        </div>
        <Button>+ Add Bill</Button>
      </div>

      <Card className="p-0">
        {bills.length === 0 ? (
          <div className="flex flex-col items-center py-14 text-center">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-success/10 text-success">
              <CalendarCheck size={20} />
            </div>
            <p className="text-sm text-text-secondary">No bills due in the next 30 days.</p>
          </div>
        ) : (
          <ul className="divide-y divide-border/10">
            {bills.map((b, i) => {
              const days = daysUntil(b.due_date);
              const urgent = days <= 3;
              return (
                <motion.li
                  key={b.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.04 }}
                  className={cn(
                    "flex items-center justify-between px-5 py-3.5",
                    urgent && "bg-warning/5"
                  )}
                >
                  <div>
                    <p className="text-sm font-medium text-text-primary">{b.name}</p>
                    <div className="mt-0.5 flex items-center gap-1.5">
                      <p className={cn("text-xs", urgent ? "font-medium text-warning" : "text-text-tertiary")}>
                        Due {b.due_date} {urgent && `· in ${days}d`}
                      </p>
                      {b.is_autopay && (
                        <Badge variant="primary">
                          <Zap size={10} className="mr-0.5 inline" />
                          Autopay
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-semibold tabular-nums text-text-primary">
                      {currency.format(b.amount)}
                    </span>
                    <button className="rounded-md border border-border/15 px-3 py-1.5 text-xs font-medium text-text-primary hover:bg-surface-elevated">
                      Mark Paid
                    </button>
                  </div>
                </motion.li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}
