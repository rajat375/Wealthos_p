"use client";

import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Sparkles } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Skeleton } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { AllocationDonut } from "@/components/charts/AllocationDonut";
import { useAssets } from "@/hooks/useAssets";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export default function AssetsPage() {
  const { assets, summary, isLoading, error } = useAssets();

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Skeleton className="h-72 w-full lg:col-span-1" />
        <Skeleton className="h-72 w-full lg:col-span-2" />
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <p className="text-sm text-danger">Couldn&apos;t load your assets: {error}</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Assets</h1>
          <p className="text-sm text-text-secondary">
            {summary ? currency.format(summary.total_value) : "—"} across{" "}
            {summary?.allocation.length ?? 0} categories
          </p>
        </div>
        <Button>+ Add Asset</Button>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card>
          <h2 className="mb-2 text-sm font-semibold text-text-primary">Allocation</h2>
          <AllocationDonut data={summary?.allocation ?? []} />
        </Card>

        <Card className="p-0 lg:col-span-2">
          <h2 className="p-5 pb-2 text-sm font-semibold text-text-primary">All Assets</h2>
          {assets.length === 0 ? (
            <div className="flex flex-col items-center py-14 text-center">
              <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                <Sparkles size={20} />
              </div>
              <p className="text-sm text-text-secondary">
                No assets yet. Add your first mutual fund, stock, gold holding, or FD.
              </p>
            </div>
          ) : (
            <ul className="divide-y divide-border/10">
              {assets.map((a, i) => {
                const gain = a.purchase_value ? a.current_value - a.purchase_value : null;
                const gainPct = gain && a.purchase_value ? (gain / a.purchase_value) * 100 : null;
                const isPositive = (gain ?? 0) >= 0;
                return (
                  <motion.li
                    key={a.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.04 }}
                    className="flex items-center justify-between px-5 py-3.5 transition hover:bg-surface-elevated/50"
                  >
                    <div>
                      <p className="text-sm font-medium text-text-primary">{a.name}</p>
                      {a.institution && (
                        <p className="text-xs text-text-tertiary">{a.institution}</p>
                      )}
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold tabular-nums text-text-primary">
                        {currency.format(a.current_value)}
                      </p>
                      {gainPct !== null && (
                        <p
                          className={`flex items-center justify-end gap-1 text-xs font-medium ${
                            isPositive ? "text-success" : "text-danger"
                          }`}
                        >
                          {isPositive ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
                          {Math.abs(gainPct).toFixed(1)}%
                        </p>
                      )}
                    </div>
                  </motion.li>
                );
              })}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
