"use client";

import { motion } from "framer-motion";
import { Repeat } from "lucide-react";
import { Card, StatCard } from "@/components/ui/Card";
import { Skeleton } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { useSubscriptions } from "@/hooks/useSubscriptions";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export default function SubscriptionsPage() {
  const { subscriptions, summary, isLoading, error } = useSubscriptions();

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-28 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <p className="text-sm text-danger">Couldn&apos;t load your subscriptions: {error}</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Subscriptions</h1>
          <p className="text-sm text-text-secondary">{summary?.active_count ?? 0} active</p>
        </div>
        <Button>+ Add Subscription</Button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <StatCard label="Monthly Total" value={currency.format(summary?.monthly_total ?? 0)} accent="emerald" />
        <StatCard label="Yearly Total" value={currency.format(summary?.yearly_total ?? 0)} />
      </div>

      {subscriptions.length === 0 ? (
        <Card>
          <div className="flex flex-col items-center py-10 text-center">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Repeat size={20} />
            </div>
            <p className="text-sm text-text-secondary">
              No subscriptions tracked yet — add Netflix, Spotify, or any recurring service.
            </p>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {subscriptions.map((s, i) => (
            <motion.div
              key={s.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <Card hover className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-text-primary">{s.name}</p>
                  <p className="text-xs text-text-tertiary capitalize">
                    {s.billing_cycle}
                    {s.next_billing_date && ` · renews ${s.next_billing_date}`}
                  </p>
                </div>
                <span className="text-sm font-semibold tabular-nums text-text-primary">
                  {currency.format(s.amount)}
                </span>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
