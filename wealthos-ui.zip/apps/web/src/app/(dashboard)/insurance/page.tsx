"use client";

import { motion } from "framer-motion";
import { ShieldCheck, ShieldAlert } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Skeleton, Badge } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { useInsurance } from "@/hooks/useInsurance";
import { cn } from "@/lib/utils";
import type { PolicyType } from "@/types/finance";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

const POLICY_LABELS: Record<PolicyType, string> = {
  life: "Life",
  health: "Health",
  vehicle: "Vehicle",
  home: "Home",
  term: "Term",
  other: "Other",
};

function daysUntil(dateStr: string): number {
  return Math.ceil((new Date(dateStr).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
}

export default function InsurancePage() {
  const { policies, isLoading, error } = useInsurance();

  if (isLoading) return <Skeleton className="h-64 w-full" />;

  if (error) {
    return (
      <Card>
        <p className="text-sm text-danger">Couldn&apos;t load your insurance policies: {error}</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Insurance</h1>
          <p className="text-sm text-text-secondary">{policies.length} policies tracked</p>
        </div>
        <Button>+ Add Policy</Button>
      </div>

      {policies.length === 0 ? (
        <Card>
          <div className="flex flex-col items-center py-10 text-center">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <ShieldCheck size={20} />
            </div>
            <p className="text-sm text-text-secondary">
              No insurance policies yet — add life, health, vehicle, or home coverage.
            </p>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {policies.map((p, i) => {
            const dueSoon = p.renewal_date ? daysUntil(p.renewal_date) <= 30 : false;
            return (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Card hover>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className={cn("flex h-9 w-9 items-center justify-center rounded-md", dueSoon ? "bg-warning/10 text-warning" : "bg-primary/10 text-primary")}>
                        {dueSoon ? <ShieldAlert size={18} /> : <ShieldCheck size={18} />}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-text-primary">
                          {POLICY_LABELS[p.policy_type]} {p.provider ? `· ${p.provider}` : ""}
                        </p>
                        <p className="text-xs text-text-tertiary">
                          {p.renewal_date ? `Renews ${p.renewal_date}` : "No renewal date set"}
                        </p>
                      </div>
                    </div>
                    {dueSoon && <Badge variant="warning">Renewing soon</Badge>}
                  </div>
                  <div className="mt-3 flex items-center justify-between border-t border-border/10 pt-3">
                    {p.sum_assured && (
                      <span className="text-xs text-text-secondary">
                        Sum assured {currency.format(p.sum_assured)}
                      </span>
                    )}
                    {p.premium_amount && (
                      <span className="text-sm font-semibold tabular-nums text-text-primary">
                        {currency.format(p.premium_amount)}
                        <span className="text-xs font-normal text-text-tertiary">/{p.premium_frequency}</span>
                      </span>
                    )}
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
