"use client";

import { useState, FormEvent, useEffect } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { User, Palette, ShieldCheck, LogOut, Crown } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Input, Label, Skeleton, Badge } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { ThemeToggle } from "@/components/ui/ThemeToggle";
import { useProfile } from "@/hooks/useProfile";
import { useAuthStore } from "@/lib/auth-store";
import { describeApiError } from "@/lib/api-client";
import { cn } from "@/lib/utils";

const TABS = [
  { key: "profile", label: "Profile", icon: User },
  { key: "preferences", label: "Preferences", icon: Palette },
  { key: "security", label: "Security", icon: ShieldCheck },
] as const;

const CURRENCIES = ["INR", "USD", "EUR", "GBP", "AED"];

export default function SettingsPage() {
  const router = useRouter();
  const { profile, isLoading, error, updateProfile } = useProfile();
  const logout = useAuthStore((s) => s.logout);
  const [tab, setTab] = useState<(typeof TABS)[number]["key"]>("profile");

  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [currency, setCurrency] = useState("INR");
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name);
      setPhone(profile.phone ?? "");
      setCurrency(profile.base_currency);
    }
  }, [profile]);

  async function handleSaveProfile(e: FormEvent) {
    e.preventDefault();
    setSaveError(null);
    setSaved(false);
    setSaving(true);
    try {
      await updateProfile({ full_name: fullName, phone: phone || undefined });
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (err) {
      setSaveError(describeApiError(err));
    } finally {
      setSaving(false);
    }
  }

  async function handleSaveCurrency(next: string) {
    setCurrency(next);
    try {
      await updateProfile({ base_currency: next });
    } catch {
      // Non-critical — revert silently isn't necessary since profile refetch
      // on next load will reconcile; the input itself gives feedback via the
      // dropdown value already changing.
    }
  }

  async function handleLogout() {
    await logout();
    router.push("/login");
  }

  if (isLoading) {
    return (
      <div className="mx-auto max-w-3xl space-y-4">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <p className="text-sm text-danger">Couldn&apos;t load your profile: {error}</p>
      </Card>
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text-primary">Settings</h1>
        <p className="text-sm text-text-secondary">Manage your account and preferences</p>
      </div>

      <div className="flex gap-2 border-b border-border/10">
        {TABS.map((t) => {
          const Icon = t.icon;
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                "relative flex items-center gap-1.5 px-3 py-2.5 text-sm font-medium transition-colors",
                active ? "text-text-primary" : "text-text-secondary hover:text-text-primary"
              )}
            >
              <Icon size={15} />
              {t.label}
              {active && (
                <motion.div layoutId="settings-tab" className="absolute inset-x-0 -bottom-px h-0.5 bg-gradient-primary" />
              )}
            </button>
          );
        })}
      </div>

      {tab === "profile" && (
        <Card>
          <div className="mb-5 flex items-center gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-primary text-xl font-bold text-white">
              {profile?.full_name?.[0]?.toUpperCase() ?? "U"}
            </div>
            <div>
              <p className="text-sm font-semibold text-text-primary">{profile?.full_name}</p>
              <p className="text-xs text-text-tertiary">{profile?.email}</p>
              <Badge variant={profile?.plan_tier === "free" ? "default" : "primary"}>
                {profile?.plan_tier === "free" ? "Free plan" : profile?.plan_tier}
              </Badge>
            </div>
          </div>

          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div>
              <Label>Full name</Label>
              <Input value={fullName} onChange={(e) => setFullName(e.target.value)} />
            </div>
            <div>
              <Label>Phone (optional)</Label>
              <Input value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
            <div>
              <Label>Email</Label>
              <Input value={profile?.email ?? ""} disabled className="opacity-60" />
            </div>

            {saveError && <p className="text-sm text-danger">{saveError}</p>}
            {saved && <p className="text-sm text-success">Saved.</p>}

            <Button type="submit" disabled={saving}>
              {saving ? "Saving…" : "Save changes"}
            </Button>
          </form>
        </Card>
      )}

      {tab === "preferences" && (
        <div className="space-y-4">
          <Card>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text-primary">Theme</p>
                <p className="text-xs text-text-tertiary">Switch between dark and light mode</p>
              </div>
              <ThemeToggle />
            </div>
          </Card>
          <Card>
            <Label>Base currency</Label>
            <select
              value={currency}
              onChange={(e) => handleSaveCurrency(e.target.value)}
              className="mt-1 w-full rounded-md border border-border/15 bg-surface-elevated px-3.5 py-2.5 text-sm text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/25"
            >
              {CURRENCIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </Card>
          <Card className="border-primary/20 bg-primary/5">
            <div className="flex items-center gap-3">
              <Crown size={20} className="text-primary" />
              <div className="flex-1">
                <p className="text-sm font-medium text-text-primary">Upgrade to Premium</p>
                <p className="text-xs text-text-tertiary">
                  Unlock AI insights, unlimited accounts, and priority support.
                </p>
              </div>
              <Button size="sm">Upgrade</Button>
            </div>
          </Card>
        </div>
      )}

      {tab === "security" && (
        <div className="space-y-4">
          <Card>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text-primary">Two-factor authentication</p>
                <p className="text-xs text-text-tertiary">
                  {profile?.two_factor_enabled ? "Enabled" : "Not enabled yet"}
                </p>
              </div>
              <Badge variant={profile?.two_factor_enabled ? "success" : "default"}>
                {profile?.two_factor_enabled ? "On" : "Off"}
              </Badge>
            </div>
          </Card>
          <Card>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text-primary">Sign in method</p>
                <p className="text-xs text-text-tertiary capitalize">{profile?.auth_provider}</p>
              </div>
            </div>
          </Card>
          <Card>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text-primary">Sign out</p>
                <p className="text-xs text-text-tertiary">End your session on this device</p>
              </div>
              <Button variant="danger" size="sm" onClick={handleLogout}>
                <LogOut size={14} />
                Sign out
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
