"use client";

import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";
import { Card, StatCard } from "@/components/ui/Card";
import { Skeleton } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { useLiabilities } from "@/hooks/useLiabilities";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export default function LiabilitiesPage() {
  const { liabilities, totalOutstanding, isLoading, error } = useLiabilities();

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-28 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <p className="text-sm text-danger">Couldn&apos;t load your liabilities: {error}</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Liabilities</h1>
          <p className="text-sm text-text-secondary">Loans and debts you&apos;re tracking</p>
        </div>
        <Button>+ Add Liability</Button>
      </div>

      <StatCard label="Total Outstanding" value={currency.format(totalOutstanding)} />

      {liabilities.length === 0 ? (
        <Card>
          <div className="flex flex-col items-center py-10 text-center">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-success/10 text-success">
              <CheckCircle2 size={20} />
            </div>
            <p className="text-sm text-text-secondary">
              No liabilities tracked yet — add a home loan, personal loan, or credit card debt.
            </p>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {liabilities.map((l, i) => {
            // Progress toward payoff (only meaningful when principal is known via API extension;
            // approximate using outstanding vs. a nominal full-principal baseline isn't available
            // here, so we show outstanding prominently with EMI/APR context instead).
            return (
              <motion.div
                key={l.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Card hover>
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm font-medium text-text-primary">{l.name}</p>
                      <p className="text-xs text-text-tertiary">{l.lender ?? "—"}</p>
                    </div>
                    <span className="text-lg font-bold tabular-nums text-danger">
                      {currency.format(l.outstanding_amount)}
                    </span>
                  </div>
                  <div className="mt-4 flex gap-4 text-xs text-text-secondary">
                    {l.interest_rate && <span>{l.interest_rate}% APR</span>}
                    {l.emi_amount && <span>EMI {currency.format(l.emi_amount)}</span>}
                    {l.end_date && <span>Until {l.end_date}</span>}
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
