import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";

export interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  phone: string | null;
  base_currency: string;
  country_code: string;
  timezone: string;
  plan_tier: string;
  two_factor_enabled: boolean;
  auth_provider: string;
}

interface ProfileUpdateInput {
  full_name?: string;
  phone?: string;
  base_currency?: string;
  timezone?: string;
}

export function useProfile() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiRequest<UserProfile>("/users/me")
      .then(setProfile)
      .catch((err) => setError(err instanceof Error ? err.message : "Failed to load profile"))
      .finally(() => setIsLoading(false));
  }, []);

  async function updateProfile(input: ProfileUpdateInput) {
    const updated = await apiRequest<UserProfile>("/users/me", { method: "PATCH", body: input });
    setProfile(updated);
    return updated;
  }

  return { profile, isLoading, error, updateProfile };
}
