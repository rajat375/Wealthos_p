"""
Mail service abstraction for transactional email (password reset,
email verification, bill reminders). Everything else in the app calls
`send_email()` below — never a provider SDK directly — so swapping
providers only touches this file.

This scaffold ships a console-log implementation so password reset and
similar flows are fully testable in local/dev without any email provider
credentials. Wire in SendGrid or Azure Communication Services here for
production (see docs/06-DevOps-Deployment-Testing.md's Azure resource list).
"""
import logging

logger = logging.getLogger("wealthos.mail")


async def send_email(to: str, subject: str, body: str) -> None:
    # No email provider is wired into this scaffold yet — log the email
    # instead of sending it. This keeps password reset and similar flows
    # fully testable in local/dev without any external credentials. Add an
    # EMAIL_PROVIDER_API_KEY setting to app/core/config.py and a real
    # SendGrid/ACS call here when ready for production.
    logger.info("=== EMAIL (dev stub — not actually sent) ===")
    logger.info("To: %s", to)
    logger.info("Subject: %s", subject)
    logger.info("Body:\n%s", body)
    logger.info("=== END EMAIL ===")
