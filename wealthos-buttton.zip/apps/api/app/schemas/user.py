import uuid

from pydantic import BaseModel


class UserProfileOut(BaseModel):
    id: uuid.UUID
    email: str
    full_name: str
    phone: str | None
    base_currency: str
    country_code: str
    timezone: str
    plan_tier: str
    two_factor_enabled: bool
    auth_provider: str

    model_config = {"from_attributes": True}


class UserProfileUpdate(BaseModel):
    full_name: str | None = None
    phone: str | None = None
    base_currency: str | None = None
    timezone: str | None = None
