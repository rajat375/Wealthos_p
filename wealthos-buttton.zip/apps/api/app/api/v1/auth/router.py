from datetime import datetime, timedelta, timezone

import httpx
import pyotp
from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_user
from app.core.config import settings
from app.core.database import get_db
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    generate_secure_token,
    hash_password,
    hash_token,
    verify_password,
)
from app.models.user import PasswordReset, Role, Session, User
from app.schemas.auth import (
    ForgotPasswordRequest,
    GoogleLoginRequest,
    LoginRequest,
    RefreshRequest,
    RegisterRequest,
    ResetPasswordRequest,
    TokenResponse,
    TwoFactorEnableResponse,
    TwoFactorVerifyRequest,
    UserPublic,
)
from app.services.mail import send_email

router = APIRouter(prefix="/auth", tags=["auth"])


async def _issue_tokens(db: AsyncSession, user: User, request: Request) -> TokenResponse:
    access = create_access_token(str(user.id))
    refresh = create_refresh_token(str(user.id))

    db.add(
        Session(
            user_id=user.id,
            refresh_token_hash=hash_token(refresh),
            user_agent=request.headers.get("user-agent"),
            ip_address=request.client.host if request.client else None,
            expires_at=datetime.now(timezone.utc)
            + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
        )
    )
    await db.flush()

    return TokenResponse(
        access_token=access,
        refresh_token=refresh,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        user=UserPublic.model_validate(user),
    )


async def _get_default_role(db: AsyncSession) -> Role:
    result = await db.execute(select(Role).where(Role.name == "owner"))
    role = result.scalar_one_or_none()
    if not role:
        raise HTTPException(status.HTTP_500_INTERNAL_SERVER_ERROR, "Default role not seeded")
    return role


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(payload: RegisterRequest, request: Request, db: AsyncSession = Depends(get_db)):
    existing = await db.execute(select(User).where(User.email == payload.email))
    if existing.scalar_one_or_none():
        raise HTTPException(status.HTTP_409_CONFLICT, "An account with this email already exists")

    default_role = await _get_default_role(db)

    user = User(
        email=payload.email,
        password_hash=hash_password(payload.password),
        full_name=payload.full_name,
        role_id=default_role.id,
        auth_provider="email",
    )
    db.add(user)
    await db.flush()

    return await _issue_tokens(db, user, request)


@router.post("/google", response_model=TokenResponse)
async def google_login(payload: GoogleLoginRequest, request: Request, db: AsyncSession = Depends(get_db)):
    """
    Verifies a Google ID token (obtained client-side via Google Identity
    Services — see apps/web/src/components/auth/GoogleSignInButton.tsx) and
    finds-or-creates the corresponding WealthOS user.

    Verification uses Google's tokeninfo endpoint for simplicity in this
    scaffold. For production, prefer verifying the JWT signature locally
    against Google's published JWKS (e.g. via the `google-auth` library) to
    avoid a network round-trip and hard dependency on tokeninfo's uptime —
    see docs/05-Security-Design.md §2.
    """
    if not settings.GOOGLE_CLIENT_ID:
        raise HTTPException(status.HTTP_501_NOT_IMPLEMENTED, "Google sign-in is not configured on this server")

    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.get(
            "https://oauth2.googleapis.com/tokeninfo", params={"id_token": payload.id_token}
        )

    if resp.status_code != 200:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid Google token")

    token_info = resp.json()

    if token_info.get("aud") != settings.GOOGLE_CLIENT_ID:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Google token was not issued for this application")

    email = token_info.get("email")
    google_id = token_info.get("sub")
    if not email or not google_id or token_info.get("email_verified") not in ("true", True):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Google account email is missing or unverified")

    result = await db.execute(select(User).where(User.email == email, User.deleted_at.is_(None)))
    user = result.scalar_one_or_none()

    if user:
        # Existing email-registered user signing in with Google for the first time:
        # link the account rather than creating a duplicate.
        if not user.google_id:
            user.google_id = google_id
        if not user.is_active:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Account is disabled")
    else:
        default_role = await _get_default_role(db)
        user = User(
            email=email,
            full_name=token_info.get("name", email.split("@")[0]),
            role_id=default_role.id,
            auth_provider="google",
            google_id=google_id,
            is_verified=True,  # Google already verified this email
        )
        db.add(user)
        await db.flush()

    user.last_login_at = datetime.now(timezone.utc)
    return await _issue_tokens(db, user, request)


@router.post("/login", response_model=TokenResponse)
async def login(payload: LoginRequest, request: Request, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(User).where(User.email == payload.email, User.deleted_at.is_(None))
    )
    user = result.scalar_one_or_none()

    # Constant-shape error to avoid user-enumeration timing/response differences.
    if not user or not user.password_hash or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid email or password")

    if not user.is_active:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Account is disabled")

    user.last_login_at = datetime.now(timezone.utc)
    return await _issue_tokens(db, user, request)


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(payload: RefreshRequest, request: Request, db: AsyncSession = Depends(get_db)):
    decoded = decode_token(payload.refresh_token)
    if not decoded or decoded.get("type") != "refresh":
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid refresh token")

    token_hash = hash_token(payload.refresh_token)
    result = await db.execute(select(Session).where(Session.refresh_token_hash == token_hash))
    session_row = result.scalar_one_or_none()

    if not session_row or session_row.is_revoked or session_row.expires_at < datetime.now(timezone.utc):
        # Reuse-detection: a stale/revoked token being replayed revokes the whole family.
        if session_row and not session_row.is_revoked:
            session_row.is_revoked = True
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Refresh token expired or revoked")

    session_row.is_revoked = True  # rotate: old token can never be reused

    user = await db.get(User, session_row.user_id)
    if not user or not user.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "User not found or inactive")

    return await _issue_tokens(db, user, request)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(payload: RefreshRequest, db: AsyncSession = Depends(get_db)):
    token_hash = hash_token(payload.refresh_token)
    result = await db.execute(select(Session).where(Session.refresh_token_hash == token_hash))
    session_row = result.scalar_one_or_none()
    if session_row:
        session_row.is_revoked = True


@router.post("/password/forgot", status_code=status.HTTP_202_ACCEPTED)
async def forgot_password(payload: ForgotPasswordRequest, db: AsyncSession = Depends(get_db)):
    # Always return 202 regardless of whether the email exists (no enumeration).
    result = await db.execute(select(User).where(User.email == payload.email, User.deleted_at.is_(None)))
    user = result.scalar_one_or_none()
    if user:
        reset_token = generate_secure_token()
        db.add(
            PasswordReset(
                user_id=user.id,
                token_hash=hash_token(reset_token),
                expires_at=datetime.now(timezone.utc) + timedelta(minutes=15),
            )
        )
        await db.flush()

        reset_url = f"{settings.CORS_ORIGINS[0]}/reset-password?token={reset_token}"
        await send_email(
            to=user.email,
            subject="Reset your WealthOS password",
            body=(
                f"Hi {user.full_name},\n\n"
                f"Click the link below to reset your password. This link expires in 15 minutes:\n"
                f"{reset_url}\n\n"
                f"If you didn't request this, you can safely ignore this email."
            ),
        )
    return {"message": "If that email exists, a reset link has been sent."}


@router.post("/password/reset", status_code=status.HTTP_204_NO_CONTENT)
async def reset_password(payload: ResetPasswordRequest, db: AsyncSession = Depends(get_db)):
    token_hash = hash_token(payload.token)
    result = await db.execute(
        select(PasswordReset).where(PasswordReset.token_hash == token_hash)
    )
    reset_row = result.scalar_one_or_none()

    if (
        not reset_row
        or reset_row.used_at is not None
        or reset_row.expires_at < datetime.now(timezone.utc)
    ):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Reset link is invalid or has expired")

    user = await db.get(User, reset_row.user_id)
    if not user or not user.is_active:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Reset link is invalid or has expired")

    user.password_hash = hash_password(payload.new_password)
    reset_row.used_at = datetime.now(timezone.utc)

    # Revoke every existing session — a password reset should force
    # re-authentication everywhere, not just on the device that reset it.
    sessions_result = await db.execute(
        select(Session).where(Session.user_id == user.id, Session.is_revoked.is_(False))
    )
    for session_row in sessions_result.scalars().all():
        session_row.is_revoked = True


@router.post("/2fa/enable", response_model=TwoFactorEnableResponse)
async def enable_two_factor(
    db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    """
    Generates a new TOTP secret and returns it plus a provisioning URI the
    frontend renders as a QR code (see components/settings/TwoFactorSetup.tsx).
    The secret is NOT activated yet — two_factor_enabled stays false until
    the user proves possession of it via /2fa/verify, so a half-finished
    setup can never lock a user out or silently enable 2FA without their
    confirmation.
    """
    secret = pyotp.random_base32()
    user.two_factor_secret = secret  # stored, but inert until verified
    await db.flush()

    provisioning_uri = pyotp.totp.TOTP(secret).provisioning_uri(name=user.email, issuer_name="WealthOS")
    return TwoFactorEnableResponse(secret=secret, provisioning_uri=provisioning_uri)


@router.post("/2fa/verify", status_code=status.HTTP_204_NO_CONTENT)
async def verify_two_factor(
    payload: TwoFactorVerifyRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if not user.two_factor_secret:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Call /2fa/enable first to generate a secret")

    totp = pyotp.totp.TOTP(user.two_factor_secret)
    if not totp.verify(payload.code, valid_window=1):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Invalid or expired code")

    user.two_factor_enabled = True
    await db.flush()
    # NOTE: production should also generate and return one-time backup codes
    # here (hashed like passwords before storage) — see
    # docs/05-Security-Design.md §2. Omitted in this scaffold for brevity.
