"use client";

import { motion } from "framer-motion";
import { Sparkles, TrendingUp, ShieldCheck } from "lucide-react";
import type { ReactNode } from "react";

const FLOATING_STATS = [
  { label: "Net Worth", value: "₹42,18,500", delta: "+3.2%", icon: TrendingUp, top: "12%", left: "8%" },
  { label: "Health Score", value: "78", delta: "Good", icon: ShieldCheck, top: "58%", left: "4%" },
];

export function AuthShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen bg-base">
      {/* Brand panel */}
      <div className="relative hidden w-1/2 overflow-hidden bg-gradient-primary lg:flex lg:flex-col lg:justify-between lg:p-12">
        <div className="pointer-events-none absolute inset-0 bg-gradient-mesh opacity-60" />
        <div className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-white/10 blur-3xl" />

        <div className="relative flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-md bg-white/15 backdrop-blur-sm">
            <Sparkles size={18} className="text-white" />
          </div>
          <span className="text-lg font-bold text-white">WealthOS</span>
        </div>

        <div className="relative">
          <motion.h2
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-md text-3xl font-bold leading-snug text-white"
          >
            Every asset. Every liability. One dashboard.
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="mt-3 max-w-sm text-sm text-white/70"
          >
            AI-powered insights, real financial health scoring, and complete control over your money — in one place.
          </motion.p>

          {FLOATING_STATS.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 + i * 0.15 }}
                className="mt-6 inline-flex items-center gap-3 rounded-md bg-white/10 px-4 py-3 backdrop-blur-md"
              >
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/15">
                  <Icon size={14} className="text-white" />
                </div>
                <div>
                  <p className="text-[11px] text-white/60">{stat.label}</p>
                  <p className="text-sm font-semibold text-white">
                    {stat.value} <span className="text-emerald-200">{stat.delta}</span>
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>

        <p className="relative text-xs text-white/50">© 2026 WealthOS. Your money, understood.</p>
      </div>

      {/* Form panel */}
      <div className="flex flex-1 items-center justify-center px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-sm"
        >
          {children}
        </motion.div>
      </div>
    </div>
  );
}
