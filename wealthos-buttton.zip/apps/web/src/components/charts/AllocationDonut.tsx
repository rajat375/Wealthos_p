"use client";

import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import type { AssetAllocationItem } from "@/types/finance";

const COLORS = ["#6366F1", "#10B981", "#F59E0B", "#EF4444", "#0EA5E9", "#A855F7", "#EC4899"];

export function AllocationDonut({ data }: { data: AssetAllocationItem[] }) {
  if (data.length === 0) {
    return (
      <p className="py-8 text-center text-sm text-text-secondary">
        Add an asset to see your allocation.
      </p>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={220}>
      <PieChart>
        <Pie
          data={data}
          dataKey="percentage"
          nameKey="asset_type"
          innerRadius={58}
          outerRadius={86}
          paddingAngle={3}
          cornerRadius={6}
        >
          {data.map((_, i) => (
            <Cell key={i} fill={COLORS[i % COLORS.length]} stroke="none" />
          ))}
        </Pie>
        <Tooltip
          formatter={(value: number, name: string) => [`${value}%`, name]}
          contentStyle={{
            background: "rgb(var(--surface-elevated))",
            border: "1px solid rgb(var(--border) / 0.1)",
            borderRadius: 12,
            fontSize: 13,
          }}
        />
      </PieChart>
    </ResponsiveContainer>
  );
}
