"use client";

import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";

export function CashFlowChart({ income, expense }: { income: number; expense: number }) {
  // Single-month snapshot rendered as a mini two-point trend so the area
  // fill still reads visually rather than a bare bar pair. Full historical
  // cash flow lives on /reports (see ReportsCashFlowChart).
  const data = [
    { name: "", Income: 0, Expense: 0 },
    { name: "This month", Income: income, Expense: expense },
  ];

  return (
    <ResponsiveContainer width="100%" height={220}>
      <AreaChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
        <defs>
          <linearGradient id="incomeGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#10B981" stopOpacity={0.35} />
            <stop offset="100%" stopColor="#10B981" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="expenseGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#EF4444" stopOpacity={0.3} />
            <stop offset="100%" stopColor="#EF4444" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="rgb(var(--border) / 0.08)" vertical={false} />
        <XAxis dataKey="name" stroke="rgb(var(--text-tertiary))" fontSize={12} tickLine={false} axisLine={false} />
        <YAxis stroke="rgb(var(--text-tertiary))" fontSize={12} tickLine={false} axisLine={false} width={48} />
        <Tooltip
          contentStyle={{
            background: "rgb(var(--surface-elevated))",
            border: "1px solid rgb(var(--border) / 0.1)",
            borderRadius: 12,
            fontSize: 13,
          }}
        />
        <Area type="monotone" dataKey="Income" stroke="#10B981" strokeWidth={2.5} fill="url(#incomeGradient)" />
        <Area type="monotone" dataKey="Expense" stroke="#EF4444" strokeWidth={2.5} fill="url(#expenseGradient)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}
