"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ShieldCheck, Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/primitives";
import { apiRequest, describeApiError } from "@/lib/api-client";

interface EnableResponse {
  secret: string;
  provisioning_uri: string;
}

export function TwoFactorSetup({ onEnabled }: { onEnabled: () => void }) {
  const [step, setStep] = useState<"idle" | "setup" | "verifying">("idle");
  const [secret, setSecret] = useState("");
  const [qrUrl, setQrUrl] = useState("");
  const [code, setCode] = useState("");
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function startSetup() {
    setError(null);
    setLoading(true);
    try {
      const res = await apiRequest<EnableResponse>("/auth/2fa/enable", { method: "POST" });
      setSecret(res.secret);
      // Rendered via a public QR-image API purely for convenience in this
      // scaffold — the manual entry key below works identically and doesn't
      // depend on any external service, so 2FA setup still works offline.
      setQrUrl(`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(res.provisioning_uri)}`);
      setStep("setup");
    } catch (err) {
      setError(describeApiError(err));
    } finally {
      setLoading(false);
    }
  }

  async function verify() {
    setError(null);
    setLoading(true);
    try {
      await apiRequest("/auth/2fa/verify", { method: "POST", body: { code } });
      onEnabled();
      setStep("idle");
    } catch (err) {
      setError(describeApiError(err));
    } finally {
      setLoading(false);
    }
  }

  function copySecret() {
    navigator.clipboard.writeText(secret);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  if (step === "idle") {
    return (
      <Button size="sm" variant="secondary" onClick={startSetup} disabled={loading}>
        <ShieldCheck size={14} />
        {loading ? "Starting…" : "Enable 2FA"}
      </Button>
    );
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{ opacity: 1, height: "auto" }}
        exit={{ opacity: 0, height: 0 }}
        className="mt-4 space-y-4 overflow-hidden border-t border-border/10 pt-4"
      >
        <div className="flex flex-col items-center gap-3 sm:flex-row sm:items-start">
          {qrUrl && (
            /* eslint-disable-next-line @next/next/no-img-element */
            <img src={qrUrl} alt="2FA QR code" className="h-36 w-36 rounded-md border border-border/10" />
          )}
          <div className="flex-1 space-y-2">
            <p className="text-xs text-text-secondary">
              Scan with Google Authenticator, Authy, or any TOTP app. Or enter this key manually:
            </p>
            <button
              onClick={copySecret}
              className="flex w-full items-center justify-between rounded-md border border-border/15 bg-surface-elevated px-3 py-2 font-mono text-xs text-text-primary"
            >
              {secret}
              {copied ? <Check size={14} className="text-success" /> : <Copy size={14} className="text-text-tertiary" />}
            </button>
          </div>
        </div>

        <div>
          <p className="mb-1.5 text-sm font-medium text-text-primary">Enter the 6-digit code</p>
          <div className="flex gap-2">
            <Input
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
              placeholder="000000"
              className="font-mono tracking-widest"
              maxLength={6}
            />
            <Button onClick={verify} disabled={loading || code.length !== 6}>
              Verify
            </Button>
          </div>
        </div>

        {error && <p className="text-sm text-danger">{error}</p>}
      </motion.div>
    </AnimatePresence>
  );
}
