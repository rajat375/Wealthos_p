"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { BudgetItemStatus } from "@/types/finance";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export function BudgetProgressBar({ item }: { item: BudgetItemStatus }) {
  const pct = Math.min(item.percentage_used, 100);
  const barColor =
    item.percentage_used >= 100 ? "bg-danger" : item.percentage_used >= 80 ? "bg-warning" : "bg-gradient-primary";

  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between text-sm">
        <span className="font-medium text-text-primary">{item.category_name}</span>
        <span className="text-text-secondary">
          {currency.format(item.actual_amount)} / {currency.format(item.planned_amount)}
        </span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-surface-elevated">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className={cn("h-full rounded-full", barColor)}
        />
      </div>
      {item.percentage_used >= 100 && (
        <p className="mt-1 text-xs font-medium text-danger">Over budget by {(item.percentage_used - 100).toFixed(0)}%</p>
      )}
    </div>
  );
}
