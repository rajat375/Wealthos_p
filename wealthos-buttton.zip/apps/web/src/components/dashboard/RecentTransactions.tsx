"use client";

import { motion } from "framer-motion";
import { ArrowDownLeft, ArrowUpRight } from "lucide-react";
import { cn } from "@/lib/utils";
import type { DashboardSummary } from "@/types/finance";

const formatter = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export function RecentTransactions({
  items,
}: {
  items: DashboardSummary["recent_transactions"];
}) {
  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center py-10 text-center">
        <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-surface-elevated">
          <ArrowUpRight size={20} className="text-text-tertiary" />
        </div>
        <p className="text-sm text-text-secondary">
          No transactions yet — add your first one to see it here.
        </p>
      </div>
    );
  }

  return (
    <ul className="divide-y divide-border/10">
      {items.map((t, i) => {
        const isIncome = t.type === "income";
        return (
          <motion.li
            key={t.id}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
            className="flex items-center gap-3 py-3"
          >
            <div
              className={cn(
                "flex h-9 w-9 shrink-0 items-center justify-center rounded-full",
                isIncome ? "bg-success/10 text-success" : "bg-danger/10 text-danger"
              )}
            >
              {isIncome ? <ArrowDownLeft size={16} /> : <ArrowUpRight size={16} />}
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-text-primary">
                {t.merchant ?? (isIncome ? "Income" : "Expense")}
              </p>
              <p className="text-xs text-text-tertiary">{t.date}</p>
            </div>
            <span
              className={cn(
                "text-sm font-semibold tabular-nums",
                isIncome ? "text-success" : "text-text-primary"
              )}
            >
              {isIncome ? "+" : "-"}
              {formatter.format(t.amount)}
            </span>
          </motion.li>
        );
      })}
    </ul>
  );
}
