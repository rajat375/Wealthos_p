"use client";

import { motion } from "framer-motion";
import { Home, Car, Plane, PiggyBank, GraduationCap, Umbrella, Target, PartyPopper } from "lucide-react";
import { Card } from "@/components/ui/Card";
import type { Goal, GoalType } from "@/types/finance";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

const GOAL_ICONS: Record<GoalType, typeof Home> = {
  emergency_fund: Umbrella,
  house: Home,
  car: Car,
  vacation: Plane,
  retirement: PiggyBank,
  child_education: GraduationCap,
  custom: Target,
};

export function GoalProgressCard({ goal, delay = 0 }: { goal: Goal; delay?: number }) {
  const Icon = GOAL_ICONS[goal.goal_type] ?? Target;
  const pct = Math.min(goal.progress_pct, 100);
  const completed = goal.status === "completed";

  return (
    <Card hover delay={delay} className="relative overflow-hidden">
      {completed && (
        <div className="absolute right-3 top-3 flex h-7 w-7 items-center justify-center rounded-full bg-success/15 text-success">
          <PartyPopper size={14} />
        </div>
      )}
      <div className="mb-3 flex items-center gap-2.5">
        <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 text-primary">
          <Icon size={18} />
        </div>
        <p className="text-sm font-medium text-text-primary">{goal.name}</p>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-surface-elevated">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="h-full rounded-full bg-gradient-primary"
        />
      </div>
      <div className="mt-2.5 flex items-center justify-between text-xs">
        <span className="text-text-secondary">
          {currency.format(goal.current_amount)} of {currency.format(goal.target_amount)}
        </span>
        <span className="font-semibold text-text-primary">{pct}%</span>
      </div>
    </Card>
  );
}
