"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { HealthScore } from "@/types/finance";

function bandFor(score: number): { label: string; color: string; stroke: string } {
  if (score >= 80) return { label: "Excellent", color: "text-success", stroke: "#22C55E" };
  if (score >= 60) return { label: "Good", color: "text-primary", stroke: "#6366F1" };
  if (score >= 40) return { label: "Fair", color: "text-warning", stroke: "#F59E0B" };
  return { label: "Needs attention", color: "text-danger", stroke: "#EF4444" };
}

export function HealthScoreGauge({ healthScore }: { healthScore: HealthScore }) {
  const { label, color, stroke } = bandFor(healthScore.score);
  const circumference = 2 * Math.PI * 54;
  const offset = circumference * (1 - healthScore.score / 100);
  const gradientId = "healthScoreGradient";

  return (
    <div className="flex items-center gap-6">
      <div className="relative h-32 w-32 shrink-0">
        <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90">
          <defs>
            <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={stroke} stopOpacity={0.6} />
              <stop offset="100%" stopColor={stroke} stopOpacity={1} />
            </linearGradient>
          </defs>
          <circle cx="60" cy="60" r="54" fill="none" strokeWidth="10" className="stroke-surface-elevated" />
          <motion.circle
            cx="60"
            cy="60"
            r="54"
            fill="none"
            strokeWidth="10"
            strokeLinecap="round"
            stroke={`url(#${gradientId})`}
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: offset }}
            transition={{ duration: 1, ease: "easeOut" }}
            style={{ filter: `drop-shadow(0 0 6px ${stroke}66)` }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.span
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="text-3xl font-bold text-text-primary"
          >
            {healthScore.score}
          </motion.span>
          <span className="text-xs text-text-tertiary">/ 100</span>
        </div>
      </div>
      <div className="space-y-2">
        <p className={cn("text-sm font-semibold", color)}>{label}</p>
        <ul className="space-y-1 text-xs text-text-secondary">
          <li>Savings rate: {healthScore.components.savings_rate.value_pct}%</li>
          <li>Debt-to-income: {healthScore.components.debt_to_income.value_pct}%</li>
          <li>Emergency fund: {healthScore.components.emergency_fund.months_covered} months</li>
        </ul>
      </div>
    </div>
  );
}
