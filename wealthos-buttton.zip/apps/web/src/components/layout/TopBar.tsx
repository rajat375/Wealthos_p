"use client";

import Link from "next/link";
import { Bot, Search } from "lucide-react";
import { NotificationBell } from "@/components/layout/NotificationBell";
import { ThemeToggle } from "@/components/ui/ThemeToggle";

export function TopBar() {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-border/10 bg-base/80 px-4 py-3 backdrop-blur-glass sm:px-8">
      <div className="hidden max-w-sm flex-1 items-center gap-2 rounded-md border border-border/10 bg-surface-elevated px-3 py-2 text-text-tertiary sm:flex">
        <Search size={16} />
        <span className="text-sm">Search transactions, accounts…</span>
      </div>

      <div className="flex items-center gap-2">
        <Link
          href="/assistant"
          className="flex items-center gap-1.5 rounded-full bg-gradient-primary px-3.5 py-1.5 text-sm font-medium text-white shadow-[0_2px_12px_rgba(99,102,241,0.35)] hover:shadow-[0_2px_20px_rgba(99,102,241,0.5)]"
        >
          <Bot size={16} />
          Ask AI
        </Link>
        <ThemeToggle />
        <NotificationBell />
      </div>
    </header>
  );
}
