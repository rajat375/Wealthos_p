"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, ArrowDownLeft, ArrowUpRight, ArrowLeftRight } from "lucide-react";
import { AddTransactionModal } from "@/components/modals/AddTransactionModal";

const QUICK_ACTIONS = [
  { label: "Add Expense", icon: ArrowUpRight, color: "bg-danger" },
  { label: "Add Income", icon: ArrowDownLeft, color: "bg-success" },
  { label: "Transfer", icon: ArrowLeftRight, color: "bg-primary" },
];

export function FloatingActionButton() {
  const [expanded, setExpanded] = useState(false);
  const [showModal, setShowModal] = useState(false);

  return (
    <>
      <div className="fixed bottom-20 right-4 z-40 flex flex-col items-end gap-3 lg:bottom-6">
        <AnimatePresence>
          {expanded &&
            QUICK_ACTIONS.map((action, i) => {
              const Icon = action.icon;
              return (
                <motion.button
                  key={action.label}
                  initial={{ opacity: 0, y: 12, scale: 0.8 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 12, scale: 0.8 }}
                  transition={{ delay: i * 0.04 }}
                  onClick={() => {
                    setExpanded(false);
                    setShowModal(true);
                  }}
                  className="flex items-center gap-2 rounded-full bg-surface-elevated py-2 pl-3 pr-4 text-sm font-medium text-text-primary shadow-glass"
                >
                  <span className={`flex h-7 w-7 items-center justify-center rounded-full ${action.color}`}>
                    <Icon size={14} className="text-white" />
                  </span>
                  {action.label}
                </motion.button>
              );
            })}
        </AnimatePresence>

        <motion.button
          onClick={() => setExpanded((e) => !e)}
          whileTap={{ scale: 0.92 }}
          animate={{ rotate: expanded ? 45 : 0 }}
          className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-primary text-white shadow-glow"
          aria-label="Quick add"
        >
          <Plus size={26} />
        </motion.button>
      </div>

      {showModal && <AddTransactionModal onClose={() => setShowModal(false)} />}
    </>
  );
}
