"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Wallet,
  Landmark,
  PiggyBank,
  Target,
  Calculator,
  Bot,
  CreditCard,
  Receipt,
  Repeat,
  ShieldCheck,
  FileSpreadsheet,
  FolderLock,
  BarChart3,
  CalendarDays,
  ChevronsLeft,
  ChevronsRight,
  Sparkles,
  ChevronDown,
} from "lucide-react";
import { useAuthStore } from "@/lib/auth-store";

const NAV_GROUPS = [
  {
    label: "Overview",
    items: [
      { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
      { href: "/analytics", label: "Analytics", icon: BarChart3 },
      { href: "/calendar", label: "Calendar", icon: CalendarDays },
    ],
  },
  {
    label: "Money",
    items: [
      { href: "/accounts", label: "Accounts", icon: Landmark },
      { href: "/transactions", label: "Transactions", icon: Wallet },
      { href: "/budget", label: "Budget", icon: Calculator },
      { href: "/bills", label: "Bills", icon: Receipt },
    ],
  },
  {
    label: "Wealth",
    items: [
      { href: "/assets", label: "Assets", icon: PiggyBank },
      { href: "/liabilities", label: "Liabilities", icon: CreditCard },
      { href: "/goals", label: "Goals", icon: Target },
      { href: "/subscriptions", label: "Subscriptions", icon: Repeat },
      { href: "/insurance", label: "Insurance", icon: ShieldCheck },
    ],
  },
  {
    label: "Planning",
    items: [
      { href: "/tax", label: "Tax Planner", icon: FileSpreadsheet },
      { href: "/vault", label: "Document Vault", icon: FolderLock },
    ],
  },
  {
    label: "Assistant",
    items: [{ href: "/assistant", label: "AI Assistant", icon: Bot }],
  },
];

export function Sidebar() {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const user = useAuthStore((s) => s.user);

  return (
    <motion.aside
      animate={{ width: collapsed ? 76 : 248 }}
      transition={{ duration: 0.25, ease: "easeInOut" }}
      className="relative hidden shrink-0 border-r border-border/10 bg-surface/40 backdrop-blur-glass lg:flex lg:flex-col"
    >
      <div className="flex h-16 items-center gap-2 border-b border-border/10 px-4">
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-gradient-primary shadow-glow">
          <Sparkles size={16} className="text-white" />
        </div>
        <AnimatePresence>
          {!collapsed && (
            <motion.div
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: "auto" }}
              exit={{ opacity: 0, width: 0 }}
              className="flex flex-1 items-center justify-between overflow-hidden"
            >
              <span className="whitespace-nowrap text-sm font-bold text-text-primary">WealthOS</span>
              <ChevronDown size={14} className="text-text-tertiary" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <nav className="flex-1 space-y-6 overflow-y-auto px-3 py-5">
        {NAV_GROUPS.map((group) => (
          <div key={group.label}>
            {!collapsed && (
              <p className="mb-2 px-2 text-[11px] font-semibold uppercase tracking-wider text-text-tertiary">
                {group.label}
              </p>
            )}
            <ul className="space-y-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const active = pathname === item.href;
                return (
                  <li key={item.href} className="relative">
                    <Link
                      href={item.href}
                      title={collapsed ? item.label : undefined}
                      className={cn(
                        "relative flex items-center gap-3 rounded-md px-2.5 py-2 text-sm font-medium transition-colors",
                        active
                          ? "text-text-primary"
                          : "text-text-secondary hover:bg-surface-elevated hover:text-text-primary"
                      )}
                    >
                      {active && (
                        <motion.div
                          layoutId="sidebar-active"
                          className="absolute inset-0 rounded-md bg-gradient-primary/15"
                          transition={{ type: "spring", stiffness: 400, damping: 32 }}
                        />
                      )}
                      <Icon size={18} className={cn("relative shrink-0", active && "text-primary")} />
                      {!collapsed && <span className="relative">{item.label}</span>}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      {!collapsed && (
        <div className="mx-3 mb-3 rounded-md bg-gradient-primary p-4">
          <p className="text-sm font-semibold text-white">Go Premium</p>
          <p className="mt-1 text-xs text-white/80">
            Unlock AI insights, unlimited accounts, and priority support.
          </p>
          <button className="mt-3 w-full rounded-md bg-white/15 py-1.5 text-xs font-semibold text-white backdrop-blur-sm hover:bg-white/25">
            Upgrade
          </button>
        </div>
      )}

      <div className="flex items-center gap-2 border-t border-border/10 p-3">
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-primary text-xs font-semibold text-white">
          {user?.full_name?.[0]?.toUpperCase() ?? "U"}
        </div>
        {!collapsed && (
          <div className="flex-1 overflow-hidden">
            <p className="truncate text-xs font-medium text-text-primary">
              {user?.full_name ?? "Account"}
            </p>
            <Link href="/settings" className="text-[11px] text-text-tertiary hover:text-text-secondary">
              Settings
            </Link>
          </div>
        )}
        <button
          onClick={() => setCollapsed((c) => !c)}
          className="rounded-md p-1.5 text-text-tertiary hover:bg-surface-elevated hover:text-text-primary"
        >
          {collapsed ? <ChevronsRight size={16} /> : <ChevronsLeft size={16} />}
        </button>
      </div>
    </motion.aside>
  );
}
