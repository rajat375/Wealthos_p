"use client";

import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  Landmark,
  Target,
  Calculator,
  Receipt,
  CreditCard,
  Repeat,
  ShieldCheck,
  FileSpreadsheet,
  FolderLock,
  BarChart3,
  CalendarDays,
  Settings,
  X,
} from "lucide-react";

const MORE_ITEMS = [
  { href: "/accounts", label: "Accounts", icon: Landmark },
  { href: "/budget", label: "Budget", icon: Calculator },
  { href: "/bills", label: "Bills", icon: Receipt },
  { href: "/liabilities", label: "Liabilities", icon: CreditCard },
  { href: "/goals", label: "Goals", icon: Target },
  { href: "/subscriptions", label: "Subscriptions", icon: Repeat },
  { href: "/insurance", label: "Insurance", icon: ShieldCheck },
  { href: "/tax", label: "Tax Planner", icon: FileSpreadsheet },
  { href: "/vault", label: "Document Vault", icon: FolderLock },
  { href: "/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/calendar", label: "Calendar", icon: CalendarDays },
  { href: "/settings", label: "Settings", icon: Settings },
];

export function MobileMoreSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-40 bg-black/50 lg:hidden"
            aria-label="Close menu"
          />
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 32, stiffness: 300 }}
            className="fixed inset-x-0 bottom-0 z-50 rounded-t-xl border-t border-border/10 bg-surface p-5 pb-[calc(1.5rem+env(safe-area-inset-bottom))] lg:hidden"
          >
            <div className="mb-4 flex items-center justify-between">
              <p className="text-sm font-semibold text-text-primary">More</p>
              <button onClick={onClose} className="text-text-secondary">
                <X size={20} />
              </button>
            </div>
            <div className="grid grid-cols-4 gap-4">
              {MORE_ITEMS.map((item) => {
                const Icon = item.icon;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={onClose}
                    className="flex flex-col items-center gap-2 text-center"
                  >
                    <div className="flex h-12 w-12 items-center justify-center rounded-md bg-surface-elevated text-text-secondary">
                      <Icon size={20} />
                    </div>
                    <span className="text-[11px] text-text-secondary">{item.label}</span>
                  </Link>
                );
              })}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
