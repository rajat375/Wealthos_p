"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { LayoutDashboard, Wallet, PiggyBank, Bot, Menu } from "lucide-react";
import { cn } from "@/lib/utils";

const TABS = [
  { href: "/dashboard", label: "Home", icon: LayoutDashboard },
  { href: "/transactions", label: "Activity", icon: Wallet },
  { href: "/assets", label: "Wealth", icon: PiggyBank },
  { href: "/assistant", label: "AI", icon: Bot },
];

export function MobileBottomNav({ onMoreClick }: { onMoreClick: () => void }) {
  const pathname = usePathname();

  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border/10 bg-surface/80 backdrop-blur-glass lg:hidden">
      <div className="mx-auto flex max-w-md items-center justify-around px-2 py-2 pb-[calc(0.5rem+env(safe-area-inset-bottom))]">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const active = pathname === tab.href;
          return (
            <Link
              key={tab.href}
              href={tab.href}
              className="relative flex flex-col items-center gap-1 rounded-md px-3 py-1.5"
            >
              {active && (
                <motion.div
                  layoutId="mobile-nav-active"
                  className="absolute inset-0 rounded-md bg-primary/10"
                  transition={{ type: "spring", stiffness: 400, damping: 32 }}
                />
              )}
              <Icon size={20} className={cn("relative", active ? "text-primary" : "text-text-tertiary")} />
              <span
                className={cn(
                  "relative text-[10px] font-medium",
                  active ? "text-primary" : "text-text-tertiary"
                )}
              >
                {tab.label}
              </span>
            </Link>
          );
        })}
        <button
          onClick={onMoreClick}
          className="flex flex-col items-center gap-1 rounded-md px-3 py-1.5 text-text-tertiary"
        >
          <Menu size={20} />
          <span className="text-[10px] font-medium">More</span>
        </button>
      </div>
    </nav>
  );
}
