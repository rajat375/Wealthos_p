/**
 * Compatibility layer: every existing page imports GlassCard/StatTile from
 * here. Rather than touching 20+ page files individually, this file now
 * re-exports the new premium Card/StatCard design system components under
 * their old names — every page picks up the redesign automatically. New
 * code should import { Card, StatCard } from "@/components/ui/Card"
 * directly; this file exists only so nothing broke during the redesign.
 */
export { Card as GlassCard, StatCard as StatTile } from "@/components/ui/Card";
