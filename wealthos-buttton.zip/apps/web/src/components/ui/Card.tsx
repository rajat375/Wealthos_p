"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface CardProps {
  children: ReactNode;
  className?: string;
  variant?: "glass" | "gradient" | "solid" | "outline";
  hover?: boolean;
  delay?: number;
}

export function Card({ children, className, variant = "glass", hover = false, delay = 0 }: CardProps) {
  const variantClass = {
    glass: "glass-card",
    gradient:
      "gradient-border bg-surface/80 backdrop-blur-glass shadow-glass",
    solid: "bg-surface border border-border/10 rounded-lg",
    outline: "border border-border/15 rounded-lg bg-transparent",
  }[variant];

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay, ease: "easeOut" }}
      whileHover={hover ? { y: -3, transition: { duration: 0.2 } } : undefined}
      className={cn(variantClass, "p-5 sm:p-6", className)}
    >
      {children}
    </motion.div>
  );
}

export function StatCard({
  label,
  value,
  delta,
  deltaLabel,
  icon,
  accent = "primary",
  delay = 0,
}: {
  label: string;
  value: string;
  delta?: number;
  deltaLabel?: string;
  icon?: ReactNode;
  accent?: "primary" | "emerald";
  delay?: number;
}) {
  const isPositive = (delta ?? 0) >= 0;
  return (
    <Card hover delay={delay} className="relative overflow-hidden">
      <div
        className={cn(
          "pointer-events-none absolute -right-8 -top-8 h-28 w-28 rounded-full blur-3xl opacity-20",
          accent === "emerald" ? "bg-accent" : "bg-primary"
        )}
      />
      <div className="relative flex items-start justify-between">
        <div>
          <p className="text-sm text-text-secondary">{label}</p>
          <p className="mt-2 text-3xl font-bold tabular-nums text-text-primary sm:text-4xl">
            {value}
          </p>
          {delta !== undefined && (
            <p
              className={cn(
                "mt-2 inline-flex items-center gap-1 text-sm font-medium",
                isPositive ? "text-success" : "text-danger"
              )}
            >
              {isPositive ? "▲" : "▼"} {Math.abs(delta)}% {deltaLabel}
            </p>
          )}
        </div>
        {icon && (
          <div
            className={cn(
              "flex h-11 w-11 items-center justify-center rounded-md",
              accent === "emerald" ? "bg-accent/10 text-accent" : "bg-primary/10 text-primary"
            )}
          >
            {icon}
          </div>
        )}
      </div>
    </Card>
  );
}
