"use client";

import { useState, FormEvent } from "react";
import { Plus, Trash2 } from "lucide-react";
import { Modal } from "@/components/modals/Modal";
import { Input, Label } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { useBudget, currentPeriodBounds } from "@/hooks/useBudget";
import { useCategories } from "@/hooks/useCategories";
import { describeApiError } from "@/lib/api-client";

interface Row {
  categoryId: string;
  amount: string;
}

export function AddBudgetModal({ onClose }: { onClose: () => void }) {
  const { createBudget } = useBudget();
  const { categories } = useCategories("expense");
  const [rows, setRows] = useState<Row[]>([{ categoryId: "", amount: "" }]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function updateRow(index: number, field: keyof Row, value: string) {
    setRows((prev) => prev.map((r, i) => (i === index ? { ...r, [field]: value } : r)));
  }

  function addRow() {
    setRows((prev) => [...prev, { categoryId: "", amount: "" }]);
  }

  function removeRow(index: number) {
    setRows((prev) => prev.filter((_, i) => i !== index));
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    const validRows = rows.filter((r) => r.categoryId && r.amount);
    if (validRows.length === 0) {
      setError("Add at least one category with a planned amount.");
      return;
    }

    setSubmitting(true);
    try {
      const { start, end } = currentPeriodBounds();
      await createBudget({
        period_start: start,
        period_end: end,
        items: validRows.map((r) => ({ category_id: r.categoryId, planned_amount: parseFloat(r.amount) || 0 })),
      });
      onClose();
    } catch (err) {
      setError(describeApiError(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="Create Budget" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <p className="text-xs text-text-tertiary">
          Set a planned spend per category for this month. You can add more later.
        </p>

        <div className="space-y-3">
          {rows.map((row, i) => (
            <div key={i} className="flex items-end gap-2">
              <div className="flex-1">
                {i === 0 && <Label>Category</Label>}
                <select
                  value={row.categoryId}
                  onChange={(e) => updateRow(i, "categoryId", e.target.value)}
                  className="w-full rounded-md border border-border/15 bg-surface-elevated px-3 py-2.5 text-sm text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/25"
                >
                  <option value="">Select…</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="w-28">
                {i === 0 && <Label>Amount</Label>}
                <Input
                  type="number"
                  step="0.01"
                  value={row.amount}
                  onChange={(e) => updateRow(i, "amount", e.target.value)}
                />
              </div>
              {rows.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeRow(i)}
                  className="mb-0.5 flex h-9 w-9 items-center justify-center rounded-md text-text-tertiary hover:bg-surface-elevated hover:text-danger"
                >
                  <Trash2 size={15} />
                </button>
              )}
            </div>
          ))}
        </div>

        <button
          type="button"
          onClick={addRow}
          className="flex items-center gap-1.5 text-xs font-medium text-primary hover:underline"
        >
          <Plus size={14} />
          Add another category
        </button>

        {error && <p className="text-sm text-danger">{error}</p>}

        <Button type="submit" disabled={submitting} className="w-full">
          {submitting ? "Creating…" : "Create Budget"}
        </Button>
      </form>
    </Modal>
  );
}
