"use client";

import { useState, FormEvent } from "react";
import { Modal } from "@/components/modals/Modal";
import { useAccounts } from "@/hooks/useAccounts";
import { describeApiError } from "@/lib/api-client";
import type { AccountType } from "@/types/finance";

const ACCOUNT_TYPES: { value: AccountType; label: string }[] = [
  { value: "bank_savings", label: "Bank Savings" },
  { value: "bank_current", label: "Bank Current" },
  { value: "cash_wallet", label: "Cash Wallet" },
  { value: "credit_card", label: "Credit Card" },
];

export function AddAccountModal({ onClose }: { onClose: () => void }) {
  const { createAccount } = useAccounts();
  const [accountType, setAccountType] = useState<AccountType>("bank_savings");
  const [name, setName] = useState("");
  const [institution, setInstitution] = useState("");
  const [balance, setBalance] = useState("0");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await createAccount({
        account_type: accountType,
        name,
        institution_name: institution || undefined,
        current_balance: parseFloat(balance) || 0,
      });
      onClose();
    } catch (err) {
      setError(describeApiError(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="Add Account" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="text-sm font-medium text-text-primary">Account type</label>
          <select
            value={accountType}
            onChange={(e) => setAccountType(e.target.value as AccountType)}
            className="mt-1 w-full rounded-md border border-border/20 bg-surface px-3 py-2 text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
          >
            {ACCOUNT_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-sm font-medium text-text-primary">Name</label>
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. HDFC Salary Account"
            className="mt-1 w-full rounded-md border border-border/20 bg-surface px-3 py-2 text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-text-primary">Institution (optional)</label>
          <input
            value={institution}
            onChange={(e) => setInstitution(e.target.value)}
            placeholder="e.g. HDFC Bank"
            className="mt-1 w-full rounded-md border border-border/20 bg-surface px-3 py-2 text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-text-primary">Current balance</label>
          <input
            type="number"
            step="0.01"
            value={balance}
            onChange={(e) => setBalance(e.target.value)}
            className="mt-1 w-full rounded-md border border-border/20 bg-surface px-3 py-2 text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
          />
        </div>

        {error && <p className="text-sm text-danger">{error}</p>}

        <button
          type="submit"
          disabled={submitting || !name}
          className="w-full rounded-md bg-primary py-2 font-medium text-white hover:opacity-90 disabled:opacity-50"
        >
          {submitting ? "Adding…" : "Add Account"}
        </button>
      </form>
    </Modal>
  );
}
