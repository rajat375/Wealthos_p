"use client";

import { useState, FormEvent } from "react";
import { Modal } from "@/components/modals/Modal";
import { Input, Label } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { useLiabilities } from "@/hooks/useLiabilities";
import { describeApiError } from "@/lib/api-client";

const LIABILITY_TYPES = [
  { value: "home_loan", label: "Home Loan" },
  { value: "personal_loan", label: "Personal Loan" },
  { value: "education_loan", label: "Education Loan" },
  { value: "car_loan", label: "Car Loan" },
  { value: "credit_card_debt", label: "Credit Card Debt" },
  { value: "other", label: "Other" },
];

export function AddLiabilityModal({ onClose }: { onClose: () => void }) {
  const { createLiability } = useLiabilities();
  const [liabilityType, setLiabilityType] = useState("personal_loan");
  const [name, setName] = useState("");
  const [lender, setLender] = useState("");
  const [principal, setPrincipal] = useState("");
  const [outstanding, setOutstanding] = useState("");
  const [interestRate, setInterestRate] = useState("");
  const [emi, setEmi] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await createLiability({
        liability_type: liabilityType,
        name,
        lender: lender || undefined,
        principal_amount: parseFloat(principal) || 0,
        outstanding_amount: parseFloat(outstanding) || 0,
        interest_rate: interestRate ? parseFloat(interestRate) : undefined,
        emi_amount: emi ? parseFloat(emi) : undefined,
      });
      onClose();
    } catch (err) {
      setError(describeApiError(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="Add Liability" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label>Type</Label>
          <select
            value={liabilityType}
            onChange={(e) => setLiabilityType(e.target.value)}
            className="mt-1 w-full rounded-md border border-border/15 bg-surface-elevated px-3.5 py-2.5 text-sm text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/25"
          >
            {LIABILITY_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </div>
        <div>
          <Label>Name</Label>
          <Input required value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Home Loan - HDFC" />
        </div>
        <div>
          <Label>Lender (optional)</Label>
          <Input value={lender} onChange={(e) => setLender(e.target.value)} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Principal amount</Label>
            <Input type="number" step="0.01" required value={principal} onChange={(e) => setPrincipal(e.target.value)} />
          </div>
          <div>
            <Label>Outstanding amount</Label>
            <Input type="number" step="0.01" required value={outstanding} onChange={(e) => setOutstanding(e.target.value)} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Interest rate % (optional)</Label>
            <Input type="number" step="0.01" value={interestRate} onChange={(e) => setInterestRate(e.target.value)} />
          </div>
          <div>
            <Label>EMI amount (optional)</Label>
            <Input type="number" step="0.01" value={emi} onChange={(e) => setEmi(e.target.value)} />
          </div>
        </div>

        {error && <p className="text-sm text-danger">{error}</p>}

        <Button type="submit" disabled={submitting || !name || !outstanding} className="w-full">
          {submitting ? "Adding…" : "Add Liability"}
        </Button>
      </form>
    </Modal>
  );
}
