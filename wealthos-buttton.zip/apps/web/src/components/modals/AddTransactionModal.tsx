"use client";

import { useState, FormEvent } from "react";
import { Modal } from "@/components/modals/Modal";
import { useAccounts } from "@/hooks/useAccounts";
import { useCategories } from "@/hooks/useCategories";
import { apiRequest, describeApiError } from "@/lib/api-client";
import type { TransactionType } from "@/types/finance";

export function AddTransactionModal({ onClose }: { onClose: () => void }) {
  const [type, setType] = useState<TransactionType>("expense");
  const { accounts, isLoading: accountsLoading } = useAccounts();
  const { categories } = useCategories(type === "transfer" ? undefined : type);

  const [accountId, setAccountId] = useState("");
  const [transferAccountId, setTransferAccountId] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [merchant, setMerchant] = useState("");
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedAccount = accountId || accounts[0]?.id || "";

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (!selectedAccount) {
      setError("Add an account first — you need one to log a transaction against.");
      return;
    }

    setSubmitting(true);
    try {
      await apiRequest("/transactions", {
        method: "POST",
        body: {
          account_id: selectedAccount,
          type,
          amount: parseFloat(amount),
          category_id: type !== "transfer" ? categoryId || undefined : undefined,
          transaction_date: date,
          merchant: merchant || undefined,
          notes: notes || undefined,
          transfer_account_id: type === "transfer" ? transferAccountId || undefined : undefined,
        },
      });
      onClose();
    } catch (err) {
      setError(describeApiError(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="Add Transaction" onClose={onClose}>
      {accountsLoading ? (
        <p className="text-sm text-text-secondary">Loading accounts…</p>
      ) : accounts.length === 0 ? (
        <p className="text-sm text-text-secondary">
          You need at least one account before adding a transaction. Close this and add one from
          the Accounts page first.
        </p>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex gap-2">
            {(["expense", "income", "transfer"] as TransactionType[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setType(t)}
                className={`flex-1 rounded-md py-2 text-sm font-medium capitalize ${
                  type === t ? "bg-primary text-white" : "bg-surface text-text-secondary"
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          <div>
            <label className="text-sm font-medium text-text-primary">Amount</label>
            <input
              type="number"
              step="0.01"
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="mt-1 w-full rounded-md border border-border/20 bg-surface px-3 py-2 text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-text-primary">
              {type === "transfer" ? "From account" : "Account"}
            </label>
            <select
              value={selectedAccount}
              onChange={(e) => setAccountId(e.target.value)}
              className="mt-1 w-full rounded-md border border-border/20 bg-surface px-3 py-2 text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
            >
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
            </select>
          </div>

          {type === "transfer" && (
            <div>
              <label className="text-sm font-medium text-text-primary">To account</label>
              <select
                required
                value={transferAccountId}
                onChange={(e) => setTransferAccountId(e.target.value)}
                className="mt-1 w-full rounded-md border border-border/20 bg-surface px-3 py-2 text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
              >
                <option value="">Select account…</option>
                {accounts
                  .filter((a) => a.id !== selectedAccount)
                  .map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name}
                    </option>
                  ))}
              </select>
            </div>
          )}

          {type !== "transfer" && (
            <div>
              <label className="text-sm font-medium text-text-primary">Category</label>
              <select
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="mt-1 w-full rounded-md border border-border/20 bg-surface px-3 py-2 text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
              >
                <option value="">Uncategorized</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="text-sm font-medium text-text-primary">Date</label>
            <input
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="mt-1 w-full rounded-md border border-border/20 bg-surface px-3 py-2 text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
            />
          </div>

          {type !== "transfer" && (
            <div>
              <label className="text-sm font-medium text-text-primary">Merchant (optional)</label>
              <input
                value={merchant}
                onChange={(e) => setMerchant(e.target.value)}
                className="mt-1 w-full rounded-md border border-border/20 bg-surface px-3 py-2 text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
            </div>
          )}

          <div>
            <label className="text-sm font-medium text-text-primary">Notes (optional)</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              className="mt-1 w-full rounded-md border border-border/20 bg-surface px-3 py-2 text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
            />
          </div>

          {error && <p className="text-sm text-danger">{error}</p>}

          <button
            type="submit"
            disabled={submitting || !amount}
            className="w-full rounded-md bg-primary py-2 font-medium text-white hover:opacity-90 disabled:opacity-50"
          >
            {submitting ? "Saving…" : "Save Transaction"}
          </button>
        </form>
      )}
    </Modal>
  );
}
