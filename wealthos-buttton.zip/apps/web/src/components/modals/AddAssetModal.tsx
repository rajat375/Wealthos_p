"use client";

import { useState, FormEvent } from "react";
import { Modal } from "@/components/modals/Modal";
import { Input, Label } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { useAssets } from "@/hooks/useAssets";
import { describeApiError } from "@/lib/api-client";

const ASSET_TYPES = [
  { value: "mutual_fund", label: "Mutual Fund" },
  { value: "stock", label: "Stock" },
  { value: "gold", label: "Gold" },
  { value: "silver", label: "Silver" },
  { value: "fd", label: "Fixed Deposit" },
  { value: "ppf", label: "PPF" },
  { value: "epf", label: "EPF" },
  { value: "nps", label: "NPS" },
  { value: "real_estate", label: "Real Estate" },
  { value: "crypto", label: "Crypto" },
  { value: "bond", label: "Bond" },
  { value: "vehicle", label: "Vehicle" },
  { value: "other", label: "Other" },
];

export function AddAssetModal({ onClose }: { onClose: () => void }) {
  const { createAsset } = useAssets();
  const [assetType, setAssetType] = useState("mutual_fund");
  const [name, setName] = useState("");
  const [currentValue, setCurrentValue] = useState("");
  const [purchaseValue, setPurchaseValue] = useState("");
  const [institution, setInstitution] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await createAsset({
        asset_type: assetType,
        name,
        current_value: parseFloat(currentValue) || 0,
        purchase_value: purchaseValue ? parseFloat(purchaseValue) : undefined,
        institution: institution || undefined,
      });
      onClose();
    } catch (err) {
      setError(describeApiError(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="Add Asset" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label>Asset type</Label>
          <select
            value={assetType}
            onChange={(e) => setAssetType(e.target.value)}
            className="mt-1 w-full rounded-md border border-border/15 bg-surface-elevated px-3.5 py-2.5 text-sm text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/25"
          >
            {ASSET_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </div>
        <div>
          <Label>Name</Label>
          <Input required value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Parag Parikh Flexi Cap" />
        </div>
        <div>
          <Label>Current value</Label>
          <Input type="number" step="0.01" required value={currentValue} onChange={(e) => setCurrentValue(e.target.value)} />
        </div>
        <div>
          <Label>Purchase value (optional)</Label>
          <Input type="number" step="0.01" value={purchaseValue} onChange={(e) => setPurchaseValue(e.target.value)} />
        </div>
        <div>
          <Label>Institution (optional)</Label>
          <Input value={institution} onChange={(e) => setInstitution(e.target.value)} />
        </div>

        {error && <p className="text-sm text-danger">{error}</p>}

        <Button type="submit" disabled={submitting || !name || !currentValue} className="w-full">
          {submitting ? "Adding…" : "Add Asset"}
        </Button>
      </form>
    </Modal>
  );
}
