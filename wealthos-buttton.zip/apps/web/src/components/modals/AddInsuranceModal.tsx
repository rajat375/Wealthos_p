"use client";

import { useState, FormEvent } from "react";
import { Modal } from "@/components/modals/Modal";
import { Input, Label } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { useInsurance } from "@/hooks/useInsurance";
import { describeApiError } from "@/lib/api-client";

const POLICY_TYPES = [
  { value: "life", label: "Life" },
  { value: "health", label: "Health" },
  { value: "vehicle", label: "Vehicle" },
  { value: "home", label: "Home" },
  { value: "term", label: "Term" },
  { value: "other", label: "Other" },
];

export function AddInsuranceModal({ onClose }: { onClose: () => void }) {
  const { createPolicy } = useInsurance();
  const [policyType, setPolicyType] = useState("health");
  const [provider, setProvider] = useState("");
  const [sumAssured, setSumAssured] = useState("");
  const [premiumAmount, setPremiumAmount] = useState("");
  const [renewalDate, setRenewalDate] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await createPolicy({
        policy_type: policyType,
        provider: provider || undefined,
        sum_assured: sumAssured ? parseFloat(sumAssured) : undefined,
        premium_amount: premiumAmount ? parseFloat(premiumAmount) : undefined,
        renewal_date: renewalDate || undefined,
      });
      onClose();
    } catch (err) {
      setError(describeApiError(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="Add Insurance Policy" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label>Policy type</Label>
          <select
            value={policyType}
            onChange={(e) => setPolicyType(e.target.value)}
            className="mt-1 w-full rounded-md border border-border/15 bg-surface-elevated px-3.5 py-2.5 text-sm text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/25"
          >
            {POLICY_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </div>
        <div>
          <Label>Provider (optional)</Label>
          <Input value={provider} onChange={(e) => setProvider(e.target.value)} placeholder="e.g. HDFC Ergo" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Sum assured (optional)</Label>
            <Input type="number" step="0.01" value={sumAssured} onChange={(e) => setSumAssured(e.target.value)} />
          </div>
          <div>
            <Label>Premium amount (optional)</Label>
            <Input type="number" step="0.01" value={premiumAmount} onChange={(e) => setPremiumAmount(e.target.value)} />
          </div>
        </div>
        <div>
          <Label>Renewal date (optional)</Label>
          <Input type="date" value={renewalDate} onChange={(e) => setRenewalDate(e.target.value)} />
        </div>

        {error && <p className="text-sm text-danger">{error}</p>}

        <Button type="submit" disabled={submitting} className="w-full">
          {submitting ? "Adding…" : "Add Policy"}
        </Button>
      </form>
    </Modal>
  );
}
