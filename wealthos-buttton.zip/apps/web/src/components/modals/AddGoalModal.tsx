"use client";

import { useState, FormEvent } from "react";
import { Modal } from "@/components/modals/Modal";
import { Input, Label } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { useGoals } from "@/hooks/useGoals";
import { describeApiError } from "@/lib/api-client";

const GOAL_TYPES = [
  { value: "emergency_fund", label: "Emergency Fund" },
  { value: "house", label: "House" },
  { value: "car", label: "Car" },
  { value: "vacation", label: "Vacation" },
  { value: "retirement", label: "Retirement" },
  { value: "child_education", label: "Child Education" },
  { value: "custom", label: "Custom" },
];

export function AddGoalModal({ onClose }: { onClose: () => void }) {
  const { createGoal } = useGoals();
  const [goalType, setGoalType] = useState("emergency_fund");
  const [name, setName] = useState("");
  const [targetAmount, setTargetAmount] = useState("");
  const [targetDate, setTargetDate] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await createGoal({
        goal_type: goalType,
        name,
        target_amount: parseFloat(targetAmount) || 0,
        target_date: targetDate || undefined,
      });
      onClose();
    } catch (err) {
      setError(describeApiError(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="New Goal" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label>Goal type</Label>
          <select
            value={goalType}
            onChange={(e) => setGoalType(e.target.value)}
            className="mt-1 w-full rounded-md border border-border/15 bg-surface-elevated px-3.5 py-2.5 text-sm text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/25"
          >
            {GOAL_TYPES.map((t) => (
              <option key={t.value} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </div>
        <div>
          <Label>Name</Label>
          <Input required value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. 6-month Emergency Fund" />
        </div>
        <div>
          <Label>Target amount</Label>
          <Input type="number" step="0.01" required value={targetAmount} onChange={(e) => setTargetAmount(e.target.value)} />
        </div>
        <div>
          <Label>Target date (optional)</Label>
          <Input type="date" value={targetDate} onChange={(e) => setTargetDate(e.target.value)} />
        </div>

        {error && <p className="text-sm text-danger">{error}</p>}

        <Button type="submit" disabled={submitting || !name || !targetAmount} className="w-full">
          {submitting ? "Creating…" : "Create Goal"}
        </Button>
      </form>
    </Modal>
  );
}
