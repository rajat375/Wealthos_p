"use client";

import { useState, FormEvent } from "react";
import { Modal } from "@/components/modals/Modal";
import { Input, Label } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { useTaxPlanner } from "@/hooks/useTaxPlanner";
import { describeApiError } from "@/lib/api-client";

export function SetIncomeModal({ onClose }: { onClose: () => void }) {
  const { updateIncome } = useTaxPlanner();
  const [income, setIncome] = useState("");
  const [regime, setRegime] = useState<"old" | "new">("new");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await updateIncome(parseFloat(income) || 0, regime);
      onClose();
    } catch (err) {
      setError(describeApiError(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="Set Income" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label>Tax regime</Label>
          <div className="flex gap-2">
            {(["new", "old"] as const).map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setRegime(r)}
                className={`flex-1 rounded-md py-2 text-sm font-medium capitalize ${
                  regime === r ? "bg-primary text-white" : "bg-surface-elevated text-text-secondary"
                }`}
              >
                {r} regime
              </button>
            ))}
          </div>
        </div>
        <div>
          <Label>Gross annual income</Label>
          <Input type="number" step="0.01" required value={income} onChange={(e) => setIncome(e.target.value)} />
        </div>

        {error && <p className="text-sm text-danger">{error}</p>}

        <Button type="submit" disabled={submitting || !income} className="w-full">
          {submitting ? "Saving…" : "Save"}
        </Button>
      </form>
    </Modal>
  );
}
