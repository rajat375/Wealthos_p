"use client";

import { useState, FormEvent } from "react";
import { Modal } from "@/components/modals/Modal";
import { Input, Label } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { useSubscriptions } from "@/hooks/useSubscriptions";
import { describeApiError } from "@/lib/api-client";

const CYCLES = ["weekly", "monthly", "yearly"];

export function AddSubscriptionModal({ onClose }: { onClose: () => void }) {
  const { createSubscription } = useSubscriptions();
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [billingCycle, setBillingCycle] = useState("monthly");
  const [nextBillingDate, setNextBillingDate] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await createSubscription({
        name,
        amount: parseFloat(amount) || 0,
        billing_cycle: billingCycle,
        next_billing_date: nextBillingDate || undefined,
      });
      onClose();
    } catch (err) {
      setError(describeApiError(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="Add Subscription" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label>Name</Label>
          <Input required value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Netflix" />
        </div>
        <div>
          <Label>Amount</Label>
          <Input type="number" step="0.01" required value={amount} onChange={(e) => setAmount(e.target.value)} />
        </div>
        <div>
          <Label>Billing cycle</Label>
          <select
            value={billingCycle}
            onChange={(e) => setBillingCycle(e.target.value)}
            className="mt-1 w-full rounded-md border border-border/15 bg-surface-elevated px-3.5 py-2.5 text-sm text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/25"
          >
            {CYCLES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
        <div>
          <Label>Next billing date (optional)</Label>
          <Input type="date" value={nextBillingDate} onChange={(e) => setNextBillingDate(e.target.value)} />
        </div>

        {error && <p className="text-sm text-danger">{error}</p>}

        <Button type="submit" disabled={submitting || !name || !amount} className="w-full">
          {submitting ? "Adding…" : "Add Subscription"}
        </Button>
      </form>
    </Modal>
  );
}
