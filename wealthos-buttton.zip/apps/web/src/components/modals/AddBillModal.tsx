"use client";

import { useState, FormEvent } from "react";
import { Modal } from "@/components/modals/Modal";
import { Input, Label } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { useBills } from "@/hooks/useBills";
import { describeApiError } from "@/lib/api-client";

const FREQUENCIES = ["weekly", "monthly", "quarterly", "yearly"];

export function AddBillModal({ onClose }: { onClose: () => void }) {
  const { createBill } = useBills();
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [dueDate, setDueDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [frequency, setFrequency] = useState("monthly");
  const [autopay, setAutopay] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await createBill({
        name,
        amount: parseFloat(amount) || 0,
        due_date: dueDate,
        frequency,
        is_autopay: autopay,
      });
      onClose();
    } catch (err) {
      setError(describeApiError(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title="Add Bill" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label>Name</Label>
          <Input required value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Electricity" />
        </div>
        <div>
          <Label>Amount</Label>
          <Input type="number" step="0.01" required value={amount} onChange={(e) => setAmount(e.target.value)} />
        </div>
        <div>
          <Label>Due date</Label>
          <Input type="date" required value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
        </div>
        <div>
          <Label>Frequency</Label>
          <select
            value={frequency}
            onChange={(e) => setFrequency(e.target.value)}
            className="mt-1 w-full rounded-md border border-border/15 bg-surface-elevated px-3.5 py-2.5 text-sm text-text-primary focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/25"
          >
            {FREQUENCIES.map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </select>
        </div>
        <label className="flex items-center gap-2 text-sm text-text-primary">
          <input type="checkbox" checked={autopay} onChange={(e) => setAutopay(e.target.checked)} />
          This bill is on autopay
        </label>

        {error && <p className="text-sm text-danger">{error}</p>}

        <Button type="submit" disabled={submitting || !name || !amount} className="w-full">
          {submitting ? "Adding…" : "Add Bill"}
        </Button>
      </form>
    </Modal>
  );
}
