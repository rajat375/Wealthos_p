import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { DeductionSuggestion, TaxEstimate, TaxProfile } from "@/types/finance";

function currentFinancialYear(): string {
  // India-style FY: Apr–Mar. Adjust here if/when multi-country tax years land.
  const now = new Date();
  const startYear = now.getMonth() >= 3 ? now.getFullYear() : now.getFullYear() - 1;
  return `${startYear}-${startYear + 1}`;
}

export function useTaxPlanner() {
  const [profile, setProfile] = useState<TaxProfile | null>(null);
  const [estimate, setEstimate] = useState<TaxEstimate | null>(null);
  const [suggestions, setSuggestions] = useState<DeductionSuggestion[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fy = currentFinancialYear();

  async function refresh() {
    try {
      const p = await apiRequest<TaxProfile>(`/tax/profile?fy=${fy}`);
      setProfile(p);

      if (p.gross_income) {
        const [est, sugg] = await Promise.all([
          apiRequest<TaxEstimate>(`/tax/estimate?fy=${fy}`),
          apiRequest<DeductionSuggestion[]>(`/tax/deduction-suggestions?fy=${fy}`),
        ]);
        setEstimate(est);
        setSuggestions(sugg);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load tax profile");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function updateIncome(grossIncome: number, regime: "old" | "new" = "new") {
    await apiRequest(`/tax/profile?fy=${fy}`, {
      method: "PATCH",
      body: { regime, gross_income: grossIncome, deductions: {} },
    });
    await refresh();
  }

  return { fy, profile, estimate, suggestions, isLoading, error, refresh, updateIncome };
}
