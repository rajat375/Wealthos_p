import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { Account, AccountType } from "@/types/finance";

interface AccountCreateInput {
  account_type: AccountType;
  name: string;
  institution_name?: string;
  current_balance: number;
  currency?: string;
}

export function useAccounts() {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    try {
      const res = await apiRequest<Account[]>("/accounts");
      setAccounts(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load accounts");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function createAccount(input: AccountCreateInput) {
    await apiRequest<Account>("/accounts", { method: "POST", body: input });
    await refresh();
  }

  return { accounts, isLoading, error, createAccount, refresh };
}
