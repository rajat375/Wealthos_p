import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { Bill } from "@/types/finance";

interface BillCreateInput {
  name: string;
  amount: number;
  due_date: string;
  frequency: string;
  is_autopay?: boolean;
}

export function useBills() {
  const [bills, setBills] = useState<Bill[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    try {
      const res = await apiRequest<Bill[]>("/bills?upcoming_only=true");
      setBills(res);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load bills");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function createBill(input: BillCreateInput) {
    await apiRequest("/bills", { method: "POST", body: input });
    await refresh();
  }

  async function markPaid(billId: string) {
    await apiRequest(`/bills/${billId}/pay`, { method: "POST", body: {} });
    await refresh();
  }

  return { bills, isLoading, error, createBill, markPaid, refresh };
}
