import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { Asset, AssetSummary } from "@/types/finance";

interface AssetCreateInput {
  asset_type: string;
  name: string;
  quantity?: number;
  purchase_value?: number;
  current_value: number;
  purchase_date?: string;
  institution?: string;
}

export function useAssets() {
  const [assets, setAssets] = useState<Asset[]>([]);
  const [summary, setSummary] = useState<AssetSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    try {
      const [assetList, assetSummary] = await Promise.all([
        apiRequest<Asset[]>("/assets"),
        apiRequest<AssetSummary>("/assets/summary"),
      ]);
      setAssets(assetList);
      setSummary(assetSummary);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load assets");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function createAsset(input: AssetCreateInput) {
    await apiRequest("/assets", { method: "POST", body: input });
    await refresh();
  }

  return { assets, summary, isLoading, error, createAsset, refresh };
}
