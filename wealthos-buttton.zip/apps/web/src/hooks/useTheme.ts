"use client";

import { useEffect, useState } from "react";

export function useTheme() {
  const [theme, setThemeState] = useState<"dark" | "light">("dark");

  useEffect(() => {
    const stored = window.localStorage.getItem("wealthos_theme");
    const initial = stored === "light" ? "light" : "dark";
    setThemeState(initial);
    document.documentElement.classList.toggle("light", initial === "light");
  }, []);

  function setTheme(next: "dark" | "light") {
    setThemeState(next);
    document.documentElement.classList.toggle("light", next === "light");
    window.localStorage.setItem("wealthos_theme", next);
  }

  return { theme, toggleTheme: () => setTheme(theme === "dark" ? "light" : "dark"), setTheme };
}
