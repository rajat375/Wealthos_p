import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { Subscription, SubscriptionSummary } from "@/types/finance";

interface SubscriptionCreateInput {
  name: string;
  amount: number;
  billing_cycle: string;
  next_billing_date?: string;
}

export function useSubscriptions() {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [summary, setSummary] = useState<SubscriptionSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    try {
      const [subs, summ] = await Promise.all([
        apiRequest<Subscription[]>("/subscriptions"),
        apiRequest<SubscriptionSummary>("/subscriptions/summary"),
      ]);
      setSubscriptions(subs);
      setSummary(summ);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load subscriptions");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function createSubscription(input: SubscriptionCreateInput) {
    await apiRequest("/subscriptions", { method: "POST", body: input });
    await refresh();
  }

  return { subscriptions, summary, isLoading, error, createSubscription, refresh };
}
