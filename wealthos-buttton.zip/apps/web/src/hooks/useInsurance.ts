import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { InsurancePolicy } from "@/types/finance";

interface InsurancePolicyCreateInput {
  policy_type: string;
  provider?: string;
  sum_assured?: number;
  premium_amount?: number;
  premium_frequency?: string;
  renewal_date?: string;
}

export function useInsurance() {
  const [policies, setPolicies] = useState<InsurancePolicy[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    try {
      const res = await apiRequest<InsurancePolicy[]>("/insurance");
      setPolicies(res);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load insurance policies");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function createPolicy(input: InsurancePolicyCreateInput) {
    await apiRequest("/insurance", { method: "POST", body: input });
    await refresh();
  }

  return { policies, isLoading, error, createPolicy, refresh };
}
