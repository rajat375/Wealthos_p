import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { BudgetStatus } from "@/types/finance";

interface BudgetSummary {
  id: string;
  period_start: string;
  period_end: string;
  total_planned: number | null;
}

interface BudgetCreateInput {
  period_start: string;
  period_end: string;
  items: { category_id: string; planned_amount: number }[];
}

function currentPeriod(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

export function currentPeriodBounds(): { start: string; end: string } {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), 1);
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  return { start: start.toISOString().slice(0, 10), end: end.toISOString().slice(0, 10) };
}

export function useBudget() {
  const [status, setStatus] = useState<BudgetStatus | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    setIsLoading(true);
    try {
      const budget = await apiRequest<BudgetSummary | null>(`/budgets?period=${currentPeriod()}`);
      if (!budget) {
        setStatus(null);
        return;
      }
      const budgetStatus = await apiRequest<BudgetStatus>(`/budgets/${budget.id}/status`);
      setStatus(budgetStatus);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load budget");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function createBudget(input: BudgetCreateInput) {
    await apiRequest("/budgets", { method: "POST", body: input });
    await refresh();
  }

  return { status, isLoading, error, createBudget, refresh };
}
