import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { Liability } from "@/types/finance";

interface LiabilityCreateInput {
  liability_type: string;
  name: string;
  lender?: string;
  principal_amount: number;
  outstanding_amount: number;
  interest_rate?: number;
  emi_amount?: number;
}

export function useLiabilities() {
  const [liabilities, setLiabilities] = useState<Liability[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    try {
      const res = await apiRequest<Liability[]>("/liabilities");
      setLiabilities(res);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load liabilities");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function createLiability(input: LiabilityCreateInput) {
    await apiRequest("/liabilities", { method: "POST", body: input });
    await refresh();
  }

  const totalOutstanding = liabilities.reduce((sum, l) => sum + l.outstanding_amount, 0);

  return { liabilities, totalOutstanding, isLoading, error, createLiability, refresh };
}
