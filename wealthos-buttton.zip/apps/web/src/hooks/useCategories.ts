import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";

export interface Category {
  id: string;
  name: string;
  type: "income" | "expense";
  parent_id: string | null;
  icon: string | null;
  color: string | null;
  is_system_default: boolean;
}

export function useCategories(type?: "income" | "expense") {
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    const params = type ? `?type=${type}` : "";
    apiRequest<Category[]>(`/categories${params}`)
      .then((res) => {
        if (!cancelled) setCategories(res);
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [type]);

  return { categories, isLoading };
}
