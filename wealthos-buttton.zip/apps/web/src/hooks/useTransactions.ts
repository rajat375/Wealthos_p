import { useEffect, useState, useCallback } from "react";
import { apiRequest } from "@/lib/api-client";
import type { Transaction } from "@/types/finance";

interface PaginatedTransactions {
  data: Transaction[];
  meta: { page: number; limit: number; total: number };
}

export function useTransactions(filters: { type?: string } = {}) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [total, setTotal] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(() => {
    setIsLoading(true);
    const params = new URLSearchParams();
    if (filters.type) params.set("type", filters.type);

    return apiRequest<PaginatedTransactions>(`/transactions?${params.toString()}`)
      .then((res) => {
        setTransactions(res.data);
        setTotal(res.meta.total);
        setError(null);
      })
      .catch((err) => {
        setError(err instanceof Error ? err.message : "Failed to load transactions");
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, [filters.type]);

  useEffect(() => {
    let cancelled = false;
    refresh().then(() => {
      if (cancelled) return;
    });
    return () => {
      cancelled = true;
    };
  }, [refresh]);

  return { transactions, total, isLoading, error, refresh };
}
