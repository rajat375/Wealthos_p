import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/api-client";
import type { Goal } from "@/types/finance";

interface GoalCreateInput {
  goal_type: string;
  name: string;
  target_amount: number;
  target_date?: string;
}

export function useGoals() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    try {
      const res = await apiRequest<Goal[]>("/goals");
      setGoals(res);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load goals");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function createGoal(input: GoalCreateInput) {
    await apiRequest("/goals", { method: "POST", body: input });
    await refresh();
  }

  return { goals, isLoading, error, createGoal, refresh };
}
