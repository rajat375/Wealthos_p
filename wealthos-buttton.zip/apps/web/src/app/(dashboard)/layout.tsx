"use client";

import { useState } from "react";
import { Sidebar } from "@/components/layout/Sidebar";
import { TopBar } from "@/components/layout/TopBar";
import { MobileBottomNav } from "@/components/layout/MobileBottomNav";
import { MobileMoreSheet } from "@/components/layout/MobileMoreSheet";
import { FloatingActionButton } from "@/components/layout/FloatingActionButton";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [moreOpen, setMoreOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-base">
      <Sidebar />
      <div className="flex-1">
        <TopBar />
        <main className="px-4 py-6 pb-24 sm:px-8 lg:pb-6">{children}</main>
      </div>

      <MobileBottomNav onMoreClick={() => setMoreOpen(true)} />
      <MobileMoreSheet open={moreOpen} onClose={() => setMoreOpen(false)} />
      <FloatingActionButton />
    </div>
  );
}
