"use client";

import { motion } from "framer-motion";
import { CalendarClock, CreditCard, Repeat, Target } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Skeleton } from "@/components/ui/primitives";
import { useCalendar } from "@/hooks/useCalendar";
import { cn } from "@/lib/utils";
import type { CalendarEntry } from "@/types/finance";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

const TYPE_META: Record<CalendarEntry["type"], { icon: typeof CreditCard; color: string }> = {
  bill: { icon: CreditCard, color: "bg-danger/10 text-danger" },
  subscription: { icon: Repeat, color: "bg-primary/10 text-primary" },
  goal_milestone: { icon: Target, color: "bg-success/10 text-success" },
};

function groupByDate(entries: CalendarEntry[]) {
  const groups: Record<string, CalendarEntry[]> = {};
  for (const e of entries) {
    groups[e.date] = groups[e.date] ? [...groups[e.date], e] : [e];
  }
  return Object.entries(groups).sort(([a], [b]) => a.localeCompare(b));
}

export default function CalendarPage() {
  const { entries, isLoading, error } = useCalendar();

  if (isLoading) return <Skeleton className="h-64 w-full" />;

  if (error) {
    return (
      <Card>
        <p className="text-sm text-danger">Couldn&apos;t load your calendar: {error}</p>
      </Card>
    );
  }

  const grouped = groupByDate(entries);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text-primary">Calendar</h1>
        <p className="text-sm text-text-secondary">Bills, subscriptions, and goal dates this month</p>
      </div>

      {entries.length === 0 ? (
        <Card>
          <div className="flex flex-col items-center py-14 text-center">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <CalendarClock size={20} />
            </div>
            <p className="text-sm text-text-secondary">Nothing scheduled this month.</p>
          </div>
        </Card>
      ) : (
        <div className="space-y-5">
          {grouped.map(([date, dayEntries], groupIdx) => (
            <motion.div
              key={date}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: groupIdx * 0.05 }}
              className="flex gap-4"
            >
              <div className="w-16 shrink-0 pt-1 text-right">
                <p className="text-xs font-medium text-text-tertiary">{date}</p>
              </div>
              <Card className="flex-1 p-0">
                <ul className="divide-y divide-border/10">
                  {dayEntries.map((entry, i) => {
                    const { icon: Icon, color } = TYPE_META[entry.type];
                    return (
                      <li key={i} className="flex items-center gap-3 px-4 py-3">
                        <div className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-full", color)}>
                          <Icon size={14} />
                        </div>
                        <span className="flex-1 text-sm font-medium text-text-primary">{entry.title}</span>
                        {entry.amount !== null && (
                          <span className="text-sm font-semibold tabular-nums text-text-primary">
                            {currency.format(entry.amount)}
                          </span>
                        )}
                      </li>
                    );
                  })}
                </ul>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
