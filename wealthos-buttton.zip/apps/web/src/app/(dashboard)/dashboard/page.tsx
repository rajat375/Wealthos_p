"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Wallet2, TrendingUp, ArrowDownLeft, ArrowUpRight, AlertTriangle, Plus, ArrowLeftRight, PiggyBank } from "lucide-react";
import { Card, StatCard } from "@/components/ui/Card";
import { Skeleton } from "@/components/ui/primitives";
import { AnimatedNumber } from "@/components/ui/AnimatedNumber";
import { CashFlowChart } from "@/components/charts/CashFlowChart";
import { RecentTransactions } from "@/components/dashboard/RecentTransactions";
import { HealthScoreGauge } from "@/components/dashboard/HealthScoreGauge";
import { useDashboardSummary } from "@/hooks/useDashboardSummary";
import { useAnalytics } from "@/hooks/useAnalytics";
import { useAuthStore } from "@/lib/auth-store";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

const QUICK_ACTIONS = [
  { label: "Add Expense", icon: ArrowUpRight, href: "/transactions" },
  { label: "Add Income", icon: ArrowDownLeft, href: "/transactions" },
  { label: "Transfer", icon: ArrowLeftRight, href: "/accounts" },
  { label: "Invest", icon: PiggyBank, href: "/assets" },
];

function greeting(): string {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <Skeleton className="h-24 w-full" />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-32 w-full" />
        ))}
      </div>
      <Skeleton className="h-64 w-full" />
    </div>
  );
}

export default function DashboardPage() {
  const { data, isLoading, error } = useDashboardSummary();
  const { healthScore, alerts } = useAnalytics();
  const user = useAuthStore((s) => s.user);

  if (isLoading) return <DashboardSkeleton />;

  if (error) {
    return (
      <Card>
        <p className="text-sm text-danger">Couldn&apos;t load your dashboard: {error}</p>
      </Card>
    );
  }

  if (!data) return null;

  return (
    <div className="space-y-6">
      {/* Hero */}
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <motion.h1
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-2xl font-bold text-text-primary sm:text-3xl"
          >
            {greeting()}, {user?.full_name?.split(" ")[0] ?? "there"} 👋
          </motion.h1>
          <p className="mt-1 text-sm text-text-secondary">Here&apos;s where your money stands today.</p>
        </div>

        {/* Quick actions */}
        <div className="flex gap-2 overflow-x-auto">
          {QUICK_ACTIONS.map((action) => {
            const Icon = action.icon;
            return (
              <Link
                key={action.label}
                href={action.href}
                className="flex shrink-0 items-center gap-2 rounded-full border border-border/10 bg-surface-elevated px-3.5 py-2 text-xs font-medium text-text-secondary transition hover:border-primary/30 hover:text-text-primary"
              >
                <Icon size={14} />
                {action.label}
              </Link>
            );
          })}
        </div>
      </div>

      {/* Net worth hero + health score */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card variant="gradient" className="relative overflow-hidden lg:col-span-2" hover>
          <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-primary/20 blur-3xl" />
          <div className="relative flex items-center gap-2 text-sm text-text-secondary">
            <Wallet2 size={16} />
            Net Worth
          </div>
          <p className="relative mt-2 text-4xl font-bold tabular-nums text-text-primary sm:text-5xl">
            <AnimatedNumber value={data.net_worth} formatter={(n) => currency.format(n)} />
          </p>
          <div className="relative mt-4 flex items-center gap-1.5 text-sm font-medium text-success">
            <TrendingUp size={14} />
            Tracking across all connected accounts
          </div>
        </Card>

        <Card hover className="flex items-center justify-center">
          {healthScore ? (
            <HealthScoreGauge healthScore={healthScore} />
          ) : (
            <p className="text-sm text-text-secondary">Health score unavailable</p>
          )}
        </Card>
      </div>

      {/* Stat grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard
          label="Savings Rate"
          value={`${data.savings_rate_pct}%`}
          delta={data.savings_rate_pct}
          deltaLabel="of income saved"
          icon={<TrendingUp size={20} />}
          accent="emerald"
          delay={0.05}
        />
        <StatCard
          label="Income this month"
          value={currency.format(data.month_income)}
          icon={<ArrowDownLeft size={20} />}
          accent="emerald"
          delay={0.1}
        />
        <StatCard
          label="Expenses this month"
          value={currency.format(data.month_expense)}
          icon={<ArrowUpRight size={20} />}
          delay={0.15}
        />
      </div>

      {/* AI insight preview */}
      {alerts.length > 0 && (
        <Card className="border-warning/20 bg-warning/5">
          <div className="flex items-start gap-3">
            <AlertTriangle size={18} className="mt-0.5 shrink-0 text-warning" />
            <div className="flex-1">
              <p className="text-sm font-medium text-text-primary">{alerts[0].narrative}</p>
              <Link href="/analytics" className="mt-1 inline-block text-xs font-medium text-primary hover:underline">
                View all insights →
              </Link>
            </div>
          </div>
        </Card>
      )}

      {/* Charts + recent transactions */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <h2 className="mb-2 text-sm font-semibold text-text-primary">Income vs Expense</h2>
          <CashFlowChart income={data.month_income} expense={data.month_expense} />
        </Card>

        <Card>
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-text-primary">Recent Transactions</h2>
            <Link href="/transactions" className="text-xs font-medium text-primary hover:underline">
              View all
            </Link>
          </div>
          <RecentTransactions items={data.recent_transactions} />
        </Card>
      </div>
    </div>
  );
}
