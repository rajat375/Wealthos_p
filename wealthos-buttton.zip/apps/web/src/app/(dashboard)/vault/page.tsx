"use client";

import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { FileText, Upload, Lock, FileImage } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Skeleton } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { useDocuments } from "@/hooks/useDocuments";
import { ApiError } from "@/lib/api-client";

function formatSize(kb: number | null): string {
  if (!kb) return "";
  return kb > 1024 ? `${(kb / 1024).toFixed(1)} MB` : `${kb} KB`;
}

export default function DocumentVaultPage() {
  const { documents, isLoading, error, uploading, upload } = useDocuments();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);

  async function handleFileSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadError(null);
    try {
      await upload(file, file.name);
    } catch (err) {
      setUploadError(err instanceof ApiError ? err.message : "Upload failed. Please try again.");
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  if (isLoading) return <Skeleton className="h-64 w-full" />;

  if (error) {
    return (
      <Card>
        <p className="text-sm text-danger">Couldn&apos;t load your document vault: {error}</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Document Vault</h1>
          <div className="mt-1 flex items-center gap-1.5 text-sm text-text-secondary">
            <Lock size={12} />
            {documents.length} documents, stored encrypted
          </div>
        </div>
        <div>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/pdf,image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={handleFileSelected}
          />
          <Button onClick={() => fileInputRef.current?.click()} disabled={uploading}>
            <Upload size={16} />
            {uploading ? "Uploading…" : "Upload Document"}
          </Button>
        </div>
      </div>

      {uploadError && <p className="text-sm text-danger">{uploadError}</p>}

      {documents.length === 0 ? (
        <Card>
          <div className="flex flex-col items-center py-14 text-center">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <FileText size={20} />
            </div>
            <p className="text-sm text-text-secondary">
              No documents yet. Upload insurance policies, loan papers, or tax forms — PDF, JPEG, PNG, or WebP, up to 10MB.
            </p>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {documents.map((d, i) => {
            const isImage = d.doc_type !== "identity" && false; // file type not exposed in list response; icon kept generic
            const Icon = isImage ? FileImage : FileText;
            return (
              <motion.div
                key={d.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.04 }}
              >
                <Card hover className="flex flex-col items-center p-4 text-center">
                  <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-md bg-primary/10 text-primary">
                    <Icon size={24} />
                  </div>
                  <p className="line-clamp-1 text-xs font-medium text-text-primary">{d.title}</p>
                  <p className="mt-0.5 text-[11px] text-text-tertiary">
                    {d.doc_type ?? "other"} · {formatSize(d.file_size_kb)}
                  </p>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
