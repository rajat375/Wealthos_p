"use client";

import { useState } from "react";
import { FileSpreadsheet } from "lucide-react";
import { Card, StatCard } from "@/components/ui/Card";
import { Skeleton, Badge } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { SetIncomeModal } from "@/components/modals/SetIncomeModal";
import { useTaxPlanner } from "@/hooks/useTaxPlanner";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export default function TaxPlannerPage() {
  const { fy, profile, estimate, suggestions, isLoading, error, refresh } = useTaxPlanner();
  const [showIncomeModal, setShowIncomeModal] = useState(false);

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <p className="text-sm text-danger">Couldn&apos;t load your tax planner: {error}</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Tax Planner</h1>
          <p className="text-sm text-text-secondary">FY {fy}</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="primary">{profile?.regime ?? "new"} regime</Badge>
          {profile?.gross_income && (
            <Button size="sm" variant="secondary" onClick={() => setShowIncomeModal(true)}>
              Edit Income
            </Button>
          )}
        </div>
      </div>

      {!profile?.gross_income ? (
        <Card>
          <div className="flex flex-col items-center py-8 text-center">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <FileSpreadsheet size={20} />
            </div>
            <p className="mb-4 text-sm text-text-secondary">
              Set your gross income to see an estimated tax liability and deduction suggestions.
            </p>
            <Button onClick={() => setShowIncomeModal(true)}>Set Income</Button>
          </div>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <StatCard label="Taxable Income" value={currency.format(estimate?.taxable_income ?? 0)} />
            <StatCard label="Estimated Tax" value={currency.format(estimate?.estimated_tax ?? 0)} />
            <StatCard label="Effective Rate" value={`${estimate?.effective_rate_pct ?? 0}%`} accent="emerald" />
          </div>

          {suggestions.length > 0 && (
            <Card>
              <h2 className="mb-3 text-sm font-semibold text-text-primary">Deduction Room Remaining</h2>
              <ul className="divide-y divide-border/10">
                {suggestions.map((s) => (
                  <li key={s.section} className="py-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-text-primary">Section {s.section}</span>
                      <span className="text-sm font-semibold text-success">
                        {currency.format(s.remaining_room)} left
                      </span>
                    </div>
                    <p className="mt-0.5 text-xs text-text-tertiary">{s.description}</p>
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </>
      )}

      {showIncomeModal && (
        <SetIncomeModal
          onClose={() => {
            setShowIncomeModal(false);
            refresh();
          }}
        />
      )}
    </div>
  );
}
