"use client";

import { motion } from "framer-motion";
import { AlertTriangle, CheckCircle2 } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Skeleton } from "@/components/ui/primitives";
import { HealthScoreGauge } from "@/components/dashboard/HealthScoreGauge";
import { useAnalytics } from "@/hooks/useAnalytics";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export default function AnalyticsPage() {
  const { healthScore, alerts, isLoading, error } = useAnalytics();

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <p className="text-sm text-danger">Couldn&apos;t load your analytics: {error}</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-text-primary">Analytics</h1>
        <p className="text-sm text-text-secondary">Your financial health, at a glance</p>
      </div>

      {healthScore && (
        <Card>
          <h2 className="mb-4 text-sm font-semibold text-text-primary">Financial Health Score</h2>
          <HealthScoreGauge healthScore={healthScore} />
        </Card>
      )}

      <Card>
        <h2 className="mb-3 text-sm font-semibold text-text-primary">Spending Alerts</h2>
        {alerts.length === 0 ? (
          <div className="flex flex-col items-center py-8 text-center">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-success/10 text-success">
              <CheckCircle2 size={20} />
            </div>
            <p className="text-sm text-text-secondary">
              Nothing unusual this month — your spending is in line with your recent average.
            </p>
          </div>
        ) : (
          <ul className="space-y-3">
            {alerts.map((a, i) => (
              <motion.li
                key={a.category_id}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.06 }}
                className="flex items-start gap-3 rounded-md border border-warning/20 bg-warning/5 p-3.5"
              >
                <AlertTriangle size={18} className="mt-0.5 shrink-0 text-warning" />
                <div>
                  <p className="text-sm font-medium text-text-primary">{a.narrative}</p>
                  <p className="mt-0.5 text-xs text-text-tertiary">
                    {currency.format(a.current_month_total)} this month vs.{" "}
                    {currency.format(a.baseline_monthly_avg)} average
                  </p>
                </div>
              </motion.li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
