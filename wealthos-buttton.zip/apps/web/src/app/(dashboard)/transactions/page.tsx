"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowDownLeft, ArrowUpRight, ArrowLeftRight, Search, Inbox } from "lucide-react";
import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/Card";
import { Skeleton, Input } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { AddTransactionModal } from "@/components/modals/AddTransactionModal";
import { useTransactions } from "@/hooks/useTransactions";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

const FILTERS = [
  { label: "All", value: undefined },
  { label: "Income", value: "income" },
  { label: "Expense", value: "expense" },
  { label: "Transfers", value: "transfer" },
] as const;

const TYPE_ICON = { income: ArrowDownLeft, expense: ArrowUpRight, transfer: ArrowLeftRight };

export default function TransactionsPage() {
  const [type, setType] = useState<string | undefined>(undefined);
  const [search, setSearch] = useState("");
  const { transactions, total, isLoading, error, refresh } = useTransactions({ type });
  const [showAddModal, setShowAddModal] = useState(false);

  const filtered = search
    ? transactions.filter((t) => t.merchant?.toLowerCase().includes(search.toLowerCase()))
    : transactions;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Transactions</h1>
          <p className="text-sm text-text-secondary">{total} total</p>
        </div>
        <Button onClick={() => setShowAddModal(true)}>+ Add Transaction</Button>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex gap-2 overflow-x-auto">
          {FILTERS.map((f) => (
            <button
              key={f.label}
              onClick={() => setType(f.value)}
              className={cn(
                "relative shrink-0 rounded-full px-4 py-1.5 text-sm font-medium transition-colors",
                type === f.value ? "text-white" : "bg-surface-elevated text-text-secondary hover:text-text-primary"
              )}
            >
              {type === f.value && (
                <motion.div layoutId="txn-filter" className="absolute inset-0 rounded-full bg-gradient-primary" />
              )}
              <span className="relative">{f.label}</span>
            </button>
          ))}
        </div>
        <div className="relative w-full sm:w-56">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-text-tertiary" />
          <Input
            placeholder="Search merchant…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      <Card className="p-0">
        {isLoading ? (
          <div className="space-y-3 p-5">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : error ? (
          <p className="p-5 text-sm text-danger">{error}</p>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center py-14 text-center">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-surface-elevated">
              <Inbox size={20} className="text-text-tertiary" />
            </div>
            <p className="text-sm text-text-secondary">No transactions match this filter yet.</p>
          </div>
        ) : (
          <ul className="divide-y divide-border/10">
            <AnimatePresence>
              {filtered.map((t, i) => {
                const Icon = TYPE_ICON[t.type];
                const isIncome = t.type === "income";
                return (
                  <motion.li
                    key={t.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: Math.min(i * 0.03, 0.3) }}
                    className="flex items-center gap-3 px-5 py-3.5 transition hover:bg-surface-elevated/50"
                  >
                    <div
                      className={cn(
                        "flex h-9 w-9 shrink-0 items-center justify-center rounded-full",
                        isIncome ? "bg-success/10 text-success" : t.type === "transfer" ? "bg-primary/10 text-primary" : "bg-danger/10 text-danger"
                      )}
                    >
                      <Icon size={16} />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-text-primary">
                        {t.merchant ?? (isIncome ? "Income" : t.type === "transfer" ? "Transfer" : "Expense")}
                      </p>
                      <p className="text-xs text-text-tertiary">{t.transaction_date}</p>
                    </div>
                    <span
                      className={cn(
                        "text-sm font-semibold tabular-nums",
                        isIncome ? "text-success" : "text-text-primary"
                      )}
                    >
                      {isIncome ? "+" : t.type === "expense" ? "-" : ""}
                      {currency.format(t.amount)}
                    </span>
                  </motion.li>
                );
              })}
            </AnimatePresence>
          </ul>
        )}
      </Card>

      {showAddModal && (
        <AddTransactionModal
          onClose={() => {
            setShowAddModal(false);
            refresh();
          }}
        />
      )}
    </div>
  );
}
