"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Landmark, Wallet2, CreditCard as CreditCardIcon, Wifi } from "lucide-react";
import { Card, StatCard } from "@/components/ui/Card";
import { Skeleton } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { AddAccountModal } from "@/components/modals/AddAccountModal";
import { useAccounts } from "@/hooks/useAccounts";
import { cn } from "@/lib/utils";
import type { AccountType } from "@/types/finance";

const currency = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

const TYPE_ICON: Record<AccountType, typeof Landmark> = {
  bank_savings: Landmark,
  bank_current: Landmark,
  cash_wallet: Wallet2,
  credit_card: CreditCardIcon,
};

const TYPE_LABEL: Record<AccountType, string> = {
  bank_savings: "Bank Savings",
  bank_current: "Bank Current",
  cash_wallet: "Cash Wallet",
  credit_card: "Credit Card",
};

// CRED-style gradient treatment per account type — makes each account read
// like a physical card at a glance rather than a plain list row.
const TYPE_GRADIENT: Record<AccountType, string> = {
  bank_savings: "from-indigo-500 to-violet-600",
  bank_current: "from-blue-500 to-indigo-600",
  cash_wallet: "from-emerald-500 to-teal-600",
  credit_card: "from-zinc-700 to-zinc-900",
};

export default function AccountsPage() {
  const { accounts, isLoading, error, refresh } = useAccounts();
  const [showAddModal, setShowAddModal] = useState(false);

  const totalBalance = accounts
    .filter((a) => a.account_type !== "credit_card")
    .reduce((sum, a) => sum + a.current_balance, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Accounts</h1>
          <p className="text-sm text-text-secondary">{accounts.length} accounts</p>
        </div>
        <Button onClick={() => setShowAddModal(true)}>+ Add Account</Button>
      </div>

      {!isLoading && !error && (
        <StatCard label="Total Balance" value={currency.format(totalBalance)} icon={<Wallet2 size={20} />} />
      )}

      {isLoading ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-44 w-full rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <Card>
          <p className="text-sm text-danger">Couldn&apos;t load your accounts: {error}</p>
        </Card>
      ) : accounts.length === 0 ? (
        <Card>
          <p className="py-8 text-center text-sm text-text-secondary">
            No accounts yet. Add your bank account, cash wallet, or credit card to start logging
            transactions.
          </p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {accounts.map((a, i) => {
            const Icon = TYPE_ICON[a.account_type];
            return (
              <motion.div
                key={a.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06 }}
                whileHover={{ y: -4, rotate: -0.5 }}
                className={cn(
                  "relative h-44 overflow-hidden rounded-xl bg-gradient-to-br p-5 text-white shadow-glass",
                  TYPE_GRADIENT[a.account_type]
                )}
              >
                <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
                <div className="relative flex items-start justify-between">
                  <Icon size={26} className="opacity-90" />
                  <Wifi size={20} className="rotate-90 opacity-70" />
                </div>
                <p className="relative mt-8 text-2xl font-bold tabular-nums">
                  {currency.format(a.current_balance)}
                </p>
                <div className="relative mt-4 flex items-end justify-between">
                  <div>
                    <p className="text-sm font-medium">{a.name}</p>
                    <p className="text-xs text-white/70">
                      {TYPE_LABEL[a.account_type]}
                      {a.institution_name && ` · ${a.institution_name}`}
                    </p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {showAddModal && (
        <AddAccountModal
          onClose={() => {
            setShowAddModal(false);
            refresh();
          }}
        />
      )}
    </div>
  );
}
