import { redirect } from "next/navigation";

export default function ProfilePage() {
  // Consolidated into Settings → Profile tab (same pattern as Linear/Vercel)
  // rather than maintaining a near-duplicate page.
  redirect("/settings");
}
