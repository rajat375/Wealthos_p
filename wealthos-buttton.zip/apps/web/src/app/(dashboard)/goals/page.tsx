"use client";

import { useState } from "react";
import { Target } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Skeleton } from "@/components/ui/primitives";
import { Button } from "@/components/ui/Button";
import { GoalProgressCard } from "@/components/dashboard/GoalProgressCard";
import { AddGoalModal } from "@/components/modals/AddGoalModal";
import { useGoals } from "@/hooks/useGoals";

export default function GoalsPage() {
  const { goals, isLoading, error, refresh } = useGoals();
  const [showAddModal, setShowAddModal] = useState(false);

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-32 w-full" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <p className="text-sm text-danger">Couldn&apos;t load your goals: {error}</p>
      </Card>
    );
  }

  const activeGoals = goals.filter((g) => g.status === "active");
  const completedGoals = goals.filter((g) => g.status === "completed");

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">Goals</h1>
          <p className="text-sm text-text-secondary">
            {activeGoals.length} active · {completedGoals.length} completed
          </p>
        </div>
        <Button onClick={() => setShowAddModal(true)}>+ New Goal</Button>
      </div>

      {goals.length === 0 ? (
        <Card>
          <div className="flex flex-col items-center py-10 text-center">
            <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Target size={20} />
            </div>
            <p className="text-sm text-text-secondary">
              No goals yet. Start with an Emergency Fund — most people begin there.
            </p>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {goals.map((g, i) => (
            <GoalProgressCard key={g.id} goal={g} delay={i * 0.06} />
          ))}
        </div>
      )}

      {showAddModal && (
        <AddGoalModal
          onClose={() => {
            setShowAddModal(false);
            refresh();
          }}
        />
      )}
    </div>
  );
}
