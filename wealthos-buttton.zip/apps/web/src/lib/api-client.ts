const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000/api/v1";

interface ApiErrorBody {
  error: { code: string; message: string; details?: unknown };
}

export class ApiError extends Error {
  code: string;
  status: number;
  details?: unknown;

  constructor(status: number, body: ApiErrorBody) {
    super(body.error.message);
    this.code = body.error.code;
    this.status = status;
    this.details = body.error.details;
  }
}

/**
 * Turns any error thrown by apiRequest/apiUpload into a message safe to
 * show the user, distinguishing three cases that were previously all
 * displayed as the same vague "Something went wrong":
 *  1. A real API error (validation, conflict, etc.) -> its own message.
 *  2. A network/CORS failure (wrong NEXT_PUBLIC_API_URL, server down,
 *     backend CORS_ORIGINS missing this origin) -> fetch() rejects with a
 *     generic TypeError("Failed to fetch") with no server detail at all,
 *     so we say so explicitly rather than implying the server rejected the
 *     request.
 *  3. Anything else -> a safe fallback.
 */
export function describeApiError(err: unknown): string {
  if (err instanceof ApiError) return err.message;
  if (err instanceof TypeError) {
    return `Couldn't reach the server at ${API_URL}. Check that the API is running and that NEXT_PUBLIC_API_URL / CORS_ORIGINS are set correctly for this environment.`;
  }
  return "Something went wrong. Please try again.";
}

function getAccessToken(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem("wealthos_access_token");
}

export function getRefreshToken(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem("wealthos_refresh_token");
}

export function setTokens(accessToken: string, refreshToken: string) {
  window.localStorage.setItem("wealthos_access_token", accessToken);
  window.localStorage.setItem("wealthos_refresh_token", refreshToken);
}

export function clearTokens() {
  window.localStorage.removeItem("wealthos_access_token");
  window.localStorage.removeItem("wealthos_refresh_token");
}

async function refreshAccessToken(): Promise<string | null> {
  const refreshToken = getRefreshToken();
  if (!refreshToken) return null;

  const res = await fetch(`${API_URL}/auth/refresh`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: refreshToken }),
  });
  if (!res.ok) {
    clearTokens();
    return null;
  }
  const data = await res.json();
  setTokens(data.access_token, data.refresh_token);
  return data.access_token as string;
}

interface RequestOptions {
  method?: "GET" | "POST" | "PATCH" | "DELETE";
  body?: unknown;
  auth?: boolean;
}

export async function apiUpload<T>(path: string, formData: FormData): Promise<T> {
  const doFetch = async (token: string | null) => {
    const headers: Record<string, string> = {};
    if (token) headers.Authorization = `Bearer ${token}`;
    // Deliberately no Content-Type here — the browser sets the multipart
    // boundary automatically when the body is a FormData instance.
    return fetch(`${API_URL}${path}`, { method: "POST", headers, body: formData });
  };

  let res = await doFetch(getAccessToken());

  if (res.status === 401) {
    const newToken = await refreshAccessToken();
    if (newToken) res = await doFetch(newToken);
  }

  if (!res.ok) {
    const body: ApiErrorBody = await res
      .json()
      .catch(() => ({ error: { code: "UNKNOWN", message: res.statusText } }));
    throw new ApiError(res.status, body);
  }

  return res.json() as Promise<T>;
}

export async function apiRequest<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { method = "GET", body, auth = true } = options;

  const doFetch = async (token: string | null) => {
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (auth && token) headers.Authorization = `Bearer ${token}`;

    return fetch(`${API_URL}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
  };

  let res = await doFetch(getAccessToken());

  // Transparent silent-refresh on a single 401 to keep the calling code simple.
  if (res.status === 401 && auth) {
    const newToken = await refreshAccessToken();
    if (newToken) {
      res = await doFetch(newToken);
    }
  }

  if (!res.ok) {
    const body: ApiErrorBody = await res
      .json()
      .catch(() => ({ error: { code: "UNKNOWN", message: res.statusText } }));
    throw new ApiError(res.status, body);
  }

  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}
