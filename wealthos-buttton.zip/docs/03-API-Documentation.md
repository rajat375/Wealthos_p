# WealthOS — API Documentation

> **Implementation status:** this document is the full API contract for the
> product as specified. For what's actually live in the current codebase
> versus still stubbed, see the status table in the root `README.md` —
> that table is the source of truth for "does this endpoint exist yet,"
> updated as modules are built. As of the latest pass, every module through
> Document Vault is fully implemented, including 2FA and password reset
> email (dev-mode: logs the email instead of sending it — see
> `app/services/mail.py`). Reports/Notifications/Calendar are implemented
> with the caveats noted in the README (e.g., net worth trend is a current
> snapshot, not true historical reconstruction, until a balance-snapshot
> table is added).

Base URL: `https://api.wealthos.app/api/v1`
Auth: `Authorization: Bearer <JWT access token>` unless noted public.
Content-Type: `application/json`
All list endpoints support `?page=&limit=&sort=&order=` and return:
```json
{ "data": [...], "meta": { "page": 1, "limit": 20, "total": 143 } }
```
All error responses follow:
```json
{ "error": { "code": "VALIDATION_ERROR", "message": "...", "details": [...] } }
```

---

## 1. Authentication

| Method | Endpoint | Description | Auth |
|---|---|---|---|
| POST | `/auth/register` | Email/password signup | Public |
| POST | `/auth/login` | Email/password login → access + refresh token | Public |
| POST | `/auth/google` | Google OAuth login (id_token exchange) | Public |
| POST | `/auth/refresh` | Exchange refresh token for new access token | Public (refresh token) |
| POST | `/auth/logout` | Revoke current session | Bearer |
| POST | `/auth/logout-all` | Revoke all sessions | Bearer |
| POST | `/auth/password/forgot` | Send reset email | Public |
| POST | `/auth/password/reset` | Reset with token | Public |
| POST | `/auth/2fa/enable` | Generate TOTP secret + QR | Bearer |
| POST | `/auth/2fa/verify` | Verify TOTP code, activate 2FA | Bearer |
| POST | `/auth/verify-email` | Verify email via token | Public |

**POST `/auth/login`**
```json
// Request
{ "email": "user@example.com", "password": "••••••••" }
// Response 200
{ "access_token": "eyJ...", "refresh_token": "eyJ...", "expires_in": 900,
  "user": { "id": "uuid", "full_name": "...", "email": "...", "two_factor_required": false } }
```

---

## 2. Users & Settings

| Method | Endpoint | Description |
|---|---|---|
| GET | `/users/me` | Current user profile |
| PATCH | `/users/me` | Update profile (name, currency, timezone) |
| DELETE | `/users/me` | Soft-delete account (GDPR erasure flow) |
| GET | `/users/me/audit-logs` | Paginated audit log of own account |
| PATCH | `/users/me/preferences` | Theme (dark/light), notification prefs |

---

## 3. Accounts

| Method | Endpoint | Description |
|---|---|---|
| GET | `/accounts` | List all accounts (bank/cash/credit card) |
| POST | `/accounts` | Create account |
| GET | `/accounts/{id}` | Account detail |
| PATCH | `/accounts/{id}` | Update account |
| DELETE | `/accounts/{id}` | Deactivate account |
| GET | `/accounts/{id}/transactions` | Transactions for this account |

```json
// POST /accounts
{ "account_type": "bank_savings", "name": "HDFC Salary A/C",
  "institution_name": "HDFC Bank", "current_balance": 125000, "currency": "INR" }
```

---

## 4. Income & Expenses (Transactions)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/transactions` | List, filters: `type,category_id,account_id,tag,date_from,date_to,q` |
| POST | `/transactions` | Create income/expense/transfer |
| GET | `/transactions/{id}` | Detail |
| PATCH | `/transactions/{id}` | Update |
| DELETE | `/transactions/{id}` | Soft delete |
| POST | `/transactions/{id}/split` | Split into multiple categories |
| POST | `/transactions/{id}/receipt` | Upload receipt (multipart) |
| GET | `/transactions/search` | Full-text/fuzzy search on notes/merchant |
| GET | `/recurring-transactions` | List recurring templates |
| POST | `/recurring-transactions` | Create recurring template |
| PATCH | `/recurring-transactions/{id}` | Update/pause |

```json
// POST /transactions
{ "account_id": "uuid", "type": "expense", "amount": 1450.00,
  "category_id": "uuid", "transaction_date": "2026-07-05",
  "merchant": "Blue Tokai Coffee", "tags": ["work","coffee"],
  "notes": "Team meeting", "is_recurring": false }
```

---

## 5. Categories & Tags

| Method | Endpoint | Description |
|---|---|---|
| GET | `/categories` | List (system defaults + user custom, hierarchical) |
| POST | `/categories` | Create custom category/subcategory |
| PATCH | `/categories/{id}` | Rename/re-icon |
| DELETE | `/categories/{id}` | Delete (blocked if in use, or reassign) |
| GET | `/tags` | List tags |
| POST | `/tags` | Create tag |

---

## 6. Assets

| Method | Endpoint | Description |
|---|---|---|
| GET | `/assets` | List, filter by `asset_type` |
| POST | `/assets` | Add asset (mutual fund, stock, gold, FD, PPF, EPF, NPS, real estate, crypto, bond, vehicle, other) |
| GET | `/assets/{id}` | Detail incl. valuation history |
| PATCH | `/assets/{id}` | Update |
| DELETE | `/assets/{id}` | Remove |
| POST | `/assets/{id}/valuations` | Log a new valuation point |
| GET | `/assets/summary` | Aggregated by asset_type for allocation chart |

```json
// POST /assets
{ "asset_type": "mutual_fund", "name": "Parag Parikh Flexi Cap",
  "quantity": 1523.45, "purchase_value": 250000, "current_value": 312500,
  "purchase_date": "2023-01-15", "metadata": { "folio_no": "1234567" } }
```

---

## 7. Liabilities

| Method | Endpoint | Description |
|---|---|---|
| GET | `/liabilities` | List |
| POST | `/liabilities` | Add loan/debt |
| GET | `/liabilities/{id}` | Detail incl. payment history + amortization |
| PATCH | `/liabilities/{id}` | Update |
| DELETE | `/liabilities/{id}` | Close/remove |
| POST | `/liabilities/{id}/payments` | Log EMI/payment |
| GET | `/liabilities/{id}/amortization-schedule` | Computed schedule |

---

## 8. Goals

| Method | Endpoint | Description |
|---|---|---|
| GET | `/goals` | List with progress % |
| POST | `/goals` | Create goal |
| PATCH | `/goals/{id}` | Update target/date |
| DELETE | `/goals/{id}` | Cancel goal |
| POST | `/goals/{id}/contributions` | Manual contribution |
| GET | `/goals/{id}/recommendation` | AI-suggested monthly contribution |

---

## 9. Budget Planner

| Method | Endpoint | Description |
|---|---|---|
| GET | `/budgets?period=2026-07` | Get budget for period |
| POST | `/budgets` | Create budget for a period |
| PATCH | `/budgets/{id}/items/{category_id}` | Set/update planned amount |
| GET | `/budgets/{id}/status` | Planned vs actual per category |

---

## 10. Bills, Subscriptions, Insurance

| Method | Endpoint | Description |
|---|---|---|
| GET | `/bills` | Upcoming/all bills |
| POST | `/bills` | Create bill reminder |
| POST | `/bills/{id}/pay` | Mark paid (links transaction) |
| GET | `/subscriptions` | List active subscriptions + monthly total |
| POST | `/subscriptions` | Add subscription |
| DELETE | `/subscriptions/{id}` | Cancel tracking |
| GET | `/insurance` | List policies |
| POST | `/insurance` | Add policy |
| GET | `/insurance/{id}/renewal-reminder` | Renewal status |

---

## 11. Tax Planner

| Method | Endpoint | Description |
|---|---|---|
| GET | `/tax/profile?fy=2025-2026` | Get tax profile |
| PATCH | `/tax/profile` | Update income/deductions |
| GET | `/tax/estimate` | Computed tax liability + regime comparison |
| GET | `/tax/deduction-suggestions` | AI suggestions to maximize deductions |

---

## 12. Document Vault

| Method | Endpoint | Description |
|---|---|---|
| GET | `/documents` | List, filter by `doc_type`, `linked_entity_type` |
| POST | `/documents` | Upload (multipart → Azure Blob, returns signed URL) |
| GET | `/documents/{id}` | Get metadata + short-lived signed download URL |
| DELETE | `/documents/{id}` | Delete |

---

## 13. Reports & Analytics

| Method | Endpoint | Description |
|---|---|---|
| GET | `/reports/net-worth?range=1y` | Net worth trend |
| GET | `/reports/cash-flow?range=6m` | Income vs expense over time |
| GET | `/reports/category-breakdown?month=2026-06` | Spend by category |
| GET | `/reports/investment-performance` | Asset growth/XIRR |
| GET | `/reports/export?format=pdf|csv` | Export report |
| GET | `/analytics/health-score` | Current financial health score + components |
| GET | `/analytics/health-score/history` | Score trend |

---

## 14. Calendar & Notifications

| Method | Endpoint | Description |
|---|---|---|
| GET | `/calendar?month=2026-07` | Bills, EMIs, goal milestones, subscriptions on a calendar |
| GET | `/notifications` | List, filter `is_read` |
| PATCH | `/notifications/{id}/read` | Mark read |
| PATCH | `/notifications/read-all` | Mark all read |

---

## 15. AI Assistant

| Method | Endpoint | Description |
|---|---|---|
| POST | `/ai/query` | Natural language question → structured + narrative answer |
| GET | `/ai/insights` | List generated insights (overspend, saving tips, allocation) |
| POST | `/ai/insights/{id}/dismiss` | Dismiss an insight |
| GET | `/ai/monthly-summary?month=2026-06` | Get/generate monthly summary |
| GET | `/ai/coach/recommendations` | Personalized coaching tips |

```json
// POST /ai/query
{ "question": "How much did I spend on food in May?" }

// Response 200
{
  "answer": "You spent ₹18,420 on Food & Dining in May 2026, which is 12% higher than April.",
  "data": { "category": "Food & Dining", "month": "2026-05", "total": 18420, "delta_pct": 12 },
  "chart_suggestion": { "type": "bar", "series": "monthly_food_spend" }
}
```

---

## 16. Error Codes

| Code | HTTP | Meaning |
|---|---|---|
| `UNAUTHORIZED` | 401 | Missing/invalid/expired token |
| `FORBIDDEN` | 403 | Role/RLS denies access |
| `VALIDATION_ERROR` | 422 | Request body failed schema validation |
| `NOT_FOUND` | 404 | Resource doesn't exist or not owned by user |
| `CONFLICT` | 409 | Duplicate (e.g., email exists) |
| `RATE_LIMITED` | 429 | Too many requests |
| `INTERNAL_ERROR` | 500 | Unhandled server error (logged, generic message returned) |

## 17. Rate Limits
- Auth endpoints: 10 req/min/IP
- General API: 120 req/min/user
- AI endpoints: 20 req/min/user (LLM cost control)
- File upload: 20 req/min/user, max 10MB/file
