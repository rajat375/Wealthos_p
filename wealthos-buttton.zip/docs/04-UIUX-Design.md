# WealthOS — UI/UX Design System & Wireframes

> **v2 — supersedes the original light-first spec.** WealthOS shipped a
> full premium redesign (dark-first, gradient design system, Framer Motion,
> mobile bottom nav + FAB) that replaces everything below. This document
> reflects the actual shipped design, not the original aspirational v1.

## 1. Design Principles
- **Dark by default** — the app opens in dark mode (CRED/Linear/Arc-style);
  light mode is a toggle, not the default, per the product's premium-fintech
  positioning. Persisted per-user via `localStorage` + a `.light` class on
  `<html>` (see `hooks/useTheme.ts`).
- **Motion with purpose** — every state change (page load, list item
  appearing, progress bar filling, number counting up) animates via Framer
  Motion, but respects `prefers-reduced-motion`. Motion signals causality
  (this happened because of that), not just decoration.
- **Gradient as accent, not wallpaper** — the indigo→violet gradient marks
  primary actions, the active nav item, and hero moments (net worth, health
  score). It's never the default background of ordinary content — that
  would fight legibility of financial data.
- **Card-shaped financial objects** — accounts render as CRED-style gradient
  "physical card" tiles rather than list rows, because that's the mental
  model users already have for bank/credit accounts.
- **Trust signals** — lock icon on Document Vault, "stored encrypted"
  copy, visible 2FA status in Settings.

## 2. Design Tokens (as shipped)

```
Dark (default)
  --bg-base:            #09090B
  --surface:             #18181B
  --surface-elevated:     #1F1F23
  --border:                255 255 255   /* used at low alpha, e.g. border/10 */
  --text-primary:          #FAFAFA
  --text-secondary:        #A1A1AA
  --text-tertiary:         #71717A
  --primary:               #6366F1  → gradient partner #8B5CF6 (indigo → violet)
  --accent:                #10B981  (emerald)
  --success:               #22C55E
  --danger:                 #EF4444
  --warning:                 #F59E0B

Light (opt-in via .light class)
  --bg-base:            #FAFAFA   /* premium off-white, never stark #FFFFFF */
  --surface / elevated:  #FFFFFF
  --border:               15 23 42
  --text-primary:         #09090B
  --text-secondary:       #52525B

Gradients
  --gradient-primary:  linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)
  --gradient-emerald:  linear-gradient(135deg, #10B981 0%, #34D399 100%)
  --gradient-mesh:     radial gradient wash behind <body>, indigo/violet/emerald at low opacity

Typography: Inter only (no secondary display face — the original spec's
  Inter+Lexend pairing was simplified to a single family per the redesign
  brief). Headings use font-bold at the sans size scale; financial figures
  use tabular-nums throughout.

Radius: sm 10px · md 14px · lg 20px · xl 28px
Shadow: glass (dark), glass-light (light mode), glow (primary gradient glow
  behind hero elements), glow-emerald (positive/success moments)
Motion: Framer Motion spring (damping 28-32, stiffness 300-400) for
  entrances/active-state indicators; 0.15-0.4s ease-out for hover/tap
```

## 3. Design System Components (implemented)

All in `apps/web/src/components/ui/`:
- **Button** — variants: primary (gradient), secondary, ghost, outline,
  danger; sizes sm/md/lg/icon. Built on `class-variance-authority` +
  Framer Motion tap/hover scale.
- **Card / StatCard** — variants: glass, gradient (animated border), solid,
  outline. `StatCard` adds a label/value/delta/icon layout used for every
  dashboard metric. The legacy `GlassCard`/`StatTile` names still work as a
  compatibility re-export so no page had to be touched individually during
  the redesign.
- **Badge, Skeleton (shimmer), Input, Label** — `components/ui/primitives.tsx`.
- **AnimatedNumber** — spring-driven count-up for financial figures,
  triggers once when scrolled into view.
- **ThemeToggle** — animated sun/moon swap, persists choice.
- **Modal** — spring-entrance bottom-sheet-on-mobile / centered-on-desktop
  dialog, used by every "Add X" flow.

## 4. Navigation Structure (implemented)

**Desktop (`components/layout/Sidebar.tsx`):** collapsible (76px ↔ 248px,
animated), workspace switcher header, grouped nav with an animated
`layoutId`-based active-item pill, an upgrade-to-premium card, and a
profile footer with a collapse toggle.

```
Overview   → Dashboard, Analytics, Calendar
Money      → Accounts, Transactions, Budget, Bills
Wealth     → Assets, Liabilities, Goals, Subscriptions, Insurance
Planning   → Tax Planner, Document Vault
Assistant  → AI Assistant
(footer)   → Settings (via profile row)
```

**Mobile:** a fixed bottom tab bar (`MobileBottomNav.tsx`) with 4 primary
destinations (Home, Activity, Wealth, AI) plus a "More" button that opens a
bottom sheet (`MobileMoreSheet.tsx`) listing everything else in a 4-column
icon grid. A floating action button (`FloatingActionButton.tsx`) sits
above the tab bar and expands into three quick actions (Add Expense, Add
Income, Transfer), each opening the same `AddTransactionModal` used
elsewhere — one form, multiple entry points.

**Top bar (`TopBar.tsx`):** sticky, blurred-background search field (desktop
only), "Ask AI" gradient pill linking to the Assistant, theme toggle,
notification bell with unread-count badge and dropdown panel.

## 5. Key Screens (as shipped)

- **Auth** (`components/auth/AuthShell.tsx`): split-screen — animated
  gradient brand panel with floating stat cards on desktop, form-only on
  mobile. Shared by Login, Register (with a 4-bar password strength meter),
  Forgot Password, and Reset Password.
- **Dashboard**: animated net-worth hero card, gradient-ring Financial
  Health Score (SVG stroke-dashoffset animation), quick-action pill row, an
  AI overspending-alert preview card (only shown when alerts exist), a
  gradient area chart for income vs. expense, and an icon-badge recent
  transactions list.
- **Accounts**: CRED-style gradient card grid, one visual treatment per
  account type (indigo/violet for savings, blue/indigo for current,
  emerald/teal for cash, dark zinc for credit cards), with a faux contactless
  icon for texture.
- **Transactions**: sliding-pill filter tabs (`layoutId` shared-element
  animation), live search, animated list with type-colored icon badges.
- **Assets, Liabilities, Goals, Budget, Bills, Subscriptions, Insurance,
  Tax, Document Vault, Analytics, Calendar, Assistant**: each rebuilt on
  the same Card/Badge/Skeleton/motion vocabulary — gain/loss indicators on
  Assets, animated progress bars on Goals/Budget, urgency-highlighted rows
  on Bills, a grouped-by-day timeline on Calendar, animated typing-dots and
  gradient chat bubbles on the AI Assistant.
- **Settings** (new — didn't exist in v1): tabbed Profile / Preferences /
  Security, with a real TOTP 2FA setup flow (QR code + manual key entry +
  6-digit verification) and a working sign-out that revokes the session
  server-side.

## 6. Responsive Breakpoints
| Breakpoint | Width | Layout |
|---|---|---|
| `xs` | <1024px | Bottom nav + FAB, sidebar hidden, single/two-column grids |
| `lg` | ≥1024px | Full sidebar, bottom nav hidden, up to 3-column grids |

## 7. Accessibility
- Contrast maintained across both themes (verified against the token
  values above); financial figures never rely on color alone (icons +
  sign accompany red/green amounts).
- All interactive elements keyboard-navigable; Modal traps focus visually
  via a full-screen backdrop click-to-close.
- `prefers-reduced-motion` respected globally (see `globals.css`).
- Known gap: no automated axe-core pass has been run against the redesign
  yet — see the Production Checklist in `docs/07-Roadmap-Sprints-Future.md`.
