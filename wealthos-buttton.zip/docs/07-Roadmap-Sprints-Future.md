# WealthOS — Roadmap, Sprint Plan & Future Enhancements

## 1. Feature Roadmap (Phased)

### Phase 0 — Foundation (Sprints 1–2)
Auth, user/roles, base DB schema + RLS, design system, CI/CD skeleton, Docker/Azure environments.

### Phase 1 — Core Manual Finance (Sprints 3–6) — **MVP / Beta**
Accounts (bank/cash/credit card), Income & Expense tracking with categories/tags/splits/receipts, Dashboard v1 (net worth, cash flow, recent transactions), Budget Planner, Bill Reminders.

### Phase 2 — Wealth & Goals (Sprints 7–9)
Assets (all types), Liabilities, Goals with contributions, Net Worth trend reports, Subscriptions Tracker, Insurance Tracker.

### Phase 3 — AI Layer (Sprints 10–12)
Financial Health Score engine, AI Spending Insights, Monthly Summary, Overspending Detection, Natural Language Search/Assistant, Investment Allocation Suggestions.

### Phase 4 — Depth & Polish (Sprints 13–15)
Tax Planner, Document Vault, Calendar View, Analytics deep-dives, Notifications (push/email), Dark Mode polish, full responsive/a11y pass.

### Phase 5 — GA Hardening (Sprints 16–17)
Pentest remediation, load testing, SOC 2 evidence collection, onboarding polish, billing/subscription tiers (Free/Premium), public launch.

### Phase 6 — Post-Launch (V2+)
Bank/broker aggregator integration (Plaid/Setu/Account Aggregator framework), multi-currency real-time FX, family/shared accounts with granular RBAC, mobile native apps.

---

## 2. Sprint Planning (2-week sprints, indicative team of 5–6: 2 BE, 2 FE, 1 designer, 1 QA/DevOps floating)

> **Status column added retroactively** to reflect what's actually built as
> of the latest pass, vs. the original plan. ✅ Done · 🟡 Partial · ⬜ Not started.

| Sprint | Focus | Key Deliverables | Status |
|---|---|---|---|
| 1 | Foundation I | Repo scaffold, Docker Compose, Postgres schema v1 (users, roles, sessions, accounts), Auth API (register/login/JWT) | ✅ |
| 2 | Foundation II | Google OAuth, password reset, 2FA scaffold, audit_logs, RLS policies, CI pipeline green, design tokens + component library | 🟡 — Google OAuth/password reset/2FA/RLS/design system all done; `audit_logs` table exists but nothing writes to it yet; CI workflow exists but has never been run against real infra |
| 3 | Accounts & Categories | Accounts CRUD UI+API, Categories/Tags CRUD, seed system default categories | ✅ |
| 4 | Transactions I | Transaction CRUD, recurring transactions, balance-sync trigger, transaction list UI w/ filters | 🟡 — everything except recurring-transaction materialization, which is still a stub in `app/tasks/recurring.py` |
| 5 | Transactions II | Splits, receipts upload (Blob), search (pg_trgm), Dashboard v1 (net worth, cash flow, recent txns widgets) | 🟡 — Dashboard v1 done; splits, per-transaction receipt upload, and a dedicated search endpoint (the `pg_trgm` index exists in the DB but isn't queried by any route yet) are not built |
| 6 | Budget & Bills | Budget Planner CRUD + planned-vs-actual, Bill Reminders + notifications, **Beta cut** | ✅ |
| 7 | Assets I | Asset types, Assets CRUD (all categories), valuation history, allocation donut chart | ✅ |
| 8 | Liabilities & Goals | Liabilities CRUD + amortization schedule, Goals CRUD + contributions, goal progress trigger | ✅ |
| 9 | Subscriptions & Insurance | Subscriptions tracker, Insurance tracker, Net Worth trend report, Reports export (CSV/PDF) | 🟡 — Subscriptions/Insurance/Net Worth trend done (trend is a current-snapshot approximation, not true history); CSV/PDF export not built |
| 10 | AI Foundation | AI Gateway abstraction, Health Score engine v1, nightly aggregation Celery jobs | 🟡 — Gateway and Health Score done and computed on-demand; the Celery jobs that would pre-compute these nightly are still stubs in `app/tasks/ai_jobs.py` |
| 11 | AI Insights | Overspending detection, saving suggestions, allocation suggestions, insight cards UI | 🟡 — overspending detection and its UI are done; saving suggestions and investment allocation suggestions are not built |
| 12 | AI Assistant | NL query → structured query builder → LLM response, Assistant UI, monthly summary generation | 🟡 — Assistant UI and one NL-search intent (category spend by month) are done; other intents and the LLM-generated monthly summary are not built |
| 13 | Tax & Vault | Tax Planner (India regime v1), Document Vault + Blob SAS flow | 🟡 — both done, but Document Vault uses local-disk storage; the Azure Blob + SAS-token backend is documented but not implemented (see `app/services/blob_storage.py`) |
| 14 | Calendar & Analytics | Calendar view (bills/EMIs/goals), Analytics deep-dive dashboards, Notification center (push+email) | 🟡 — Calendar and Analytics done; Notifications support list/mark-read but nothing currently writes a notification (no push/email delivery) |
| 15 | Polish | Dark mode QA, full responsive/a11y pass, empty states, onboarding wizard, performance tuning | 🟡 — dark mode shipped as the *default* theme with a full premium redesign (exceeds original scope); empty states done throughout; no formal a11y audit, onboarding wizard, or performance pass yet |
| 16 | Hardening | Pentest fixes, load test (k6), WAF tuning, backup/restore drill, SOC2 evidence collection | ⬜ |
| 17 | Launch Prep | Billing/plan tiers, marketing site hookup, support tooling, production checklist sign-off, **GA launch** | ⬜ |

---

## 3. Development Task Breakdown (sample — Sprint 4: Transactions I)

**Backend**
- [ ] `transactions` SQLAlchemy model + Alembic migration
- [ ] Pydantic schemas: `TransactionCreate`, `TransactionUpdate`, `TransactionOut`
- [ ] Repository layer with RLS-aware session (`SET app.current_user_id`)
- [ ] Service layer: create/update/delete with balance-trigger validation
- [ ] `POST/GET/PATCH/DELETE /transactions` endpoints + pagination/filtering
- [ ] Recurring transaction model + Celery task to materialize due recurring transactions daily
- [ ] Unit tests (service) + integration tests (endpoint + trigger effect on account balance)

**Frontend**
- [ ] `TransactionForm` bottom-sheet/modal component (income/expense/transfer tabs)
- [ ] `TransactionList` with infinite scroll + filter bar (category, account, date range, search)
- [ ] Zustand store + API client hooks (`useTransactions`, `useCreateTransaction`)
- [ ] Optimistic UI update on create/delete
- [ ] Empty state + skeleton loaders

**QA**
- [ ] E2E: add income → add expense → verify account balance and dashboard cash-flow widget update
- [ ] Boundary tests: negative amount rejected, future-dated transaction allowed, cross-user access blocked (403)

---

## 4. Future Enhancements (Post-V1 Backlog)
- **Bank/Broker Aggregation:** Plaid (global), Setu/Account Aggregator framework (India), broker APIs (Zerodha Kite Connect, Interactive Brokers) — schema already supports via `accounts.source`/`external_account_id`.
- **Multi-currency:** real-time FX conversion for users holding assets across currencies; historical FX-adjusted net worth.
- **Family/Team plan:** shared budgets and goals with granular RBAC (`owner`/`admin`/`member`/`viewer`), per-member spending visibility controls.
- **Mobile native apps:** React Native or Flutter, reusing the same FastAPI backend and design tokens.
- **AI Voice Assistant:** voice-based query support layered on the existing NL query pipeline.
- **Investment recommendations engine:** deeper portfolio analysis (diversification score, overlap detection across mutual funds, rebalancing suggestions) — clearly labeled as educational, not regulated financial advice, with appropriate disclaimers.
- **Open Banking / UPI Autopay:** bill payment initiation (would require PCI/payment-license scoping — separate compliance track).
- **Marketplace integrations:** insurance comparison, loan refinancing offers (affiliate model) — must be clearly disclosed to users as sponsored.
- **Advanced tax optimization:** CA/advisor marketplace, e-filing integration.
- **White-label / B2B2C:** offer WealthOS as an embedded finance module for banks/fintechs.

## 5. Risk Register (top items)
| Risk | Impact | Mitigation |
|---|---|---|
| LLM cost overrun at scale | Margin erosion | Cache AI responses, cap free-tier AI queries/month, use smaller model for classification step |
| Cross-tenant data leak | Catastrophic trust loss | RLS + object-level checks + dedicated authz test suite (see Testing Strategy) |
| Regulatory classification as financial advisor | Legal/compliance | Disclaimers on all AI suggestions ("educational, not financial advice"), no execution of trades/payments in V1 |
| Manual-entry fatigue → churn | Low activation/retention | Prioritize bank aggregation early in V2, strong quick-add UX, recurring-transaction automation |
