# WealthOS

AI-powered personal finance & wealth management platform. Full product docs
(PRD, architecture, database design, API reference, UI/UX, security,
deployment, roadmap) live in [`/docs`](./docs).

## Quick Start (local development)

**Prerequisites:** Docker & Docker Compose, Node 20+, Python 3.12+ (only needed if running outside Docker).

```bash
# 1. Clone and set up environment files
cp apps/api/.env.example apps/api/.env
cp apps/web/.env.example apps/web/.env

# 2. Fill in apps/api/.env: at minimum set a real JWT_SECRET_KEY.
#
# To enable Google sign-in: create an OAuth 2.0 Client ID (Web application)
# in the Google Cloud Console, add http://localhost:3000 as an authorized
# JavaScript origin, then set GOOGLE_CLIENT_ID in apps/api/.env and
# NEXT_PUBLIC_GOOGLE_CLIENT_ID in apps/web/.env to the same value. Without
# it, the Google button on Login/Register renders disabled with an
# explanation, rather than failing silently.

# 3. Start everything (Postgres, Redis, API, worker, beat, web)
cd infra
docker compose up --build

# 4. Run database migrations (first time, in a new terminal)
docker compose exec api alembic upgrade head
```

- API: http://localhost:8000 (docs at `/api/docs` in non-production)
- Web app: http://localhost:3000
- Health check: http://localhost:8000/health

### Deploying somewhere other than localhost (a server IP, a domain, etc.)

Two env vars have `localhost` baked in by default and **must** be updated
together, or sign-up/login will fail with a generic "Something went wrong"
in the UI (the browser can't tell the difference between "server rejected
this" and "couldn't reach the server at all" unless told):

1. **`apps/web/.env`**: set `NEXT_PUBLIC_API_URL` to the API's actual
   reachable address, e.g. `http://your-server-ip:8000/api/v1`. Next.js
   bakes `NEXT_PUBLIC_*` vars in at **build time**, not runtime — you must
   `npm run build` (or rebuild the Docker image) again after changing this,
   restarting the dev server alone isn't enough.
2. **`apps/api/.env`**: set `CORS_ORIGINS` to include the web app's actual
   origin, e.g. `CORS_ORIGINS=["http://your-server-ip:3000"]`. The backend
   rejects requests from any origin not in this list.

If you only update one of the two, requests will still fail. Check the
browser DevTools Network tab on a failed request: "Failed to fetch" means
`NEXT_PUBLIC_API_URL` is wrong or the API isn't reachable; a console error
mentioning "CORS policy" means `CORS_ORIGINS` needs updating.

## What's implemented in this scaffold

This is a working, runnable product — every module from the original spec
is implemented backend-to-frontend: register, log in, add accounts, log
transactions, track assets/liabilities/goals/budgets/bills/subscriptions/
insurance, plan tax, store documents, and see it all on a fully redesigned
dashboard with a premium dark-first UI (Framer Motion, gradient design
system, mobile bottom nav + FAB — see `docs/04-UIUX-Design.md` for the
current visual language, which supersedes the original light-mode spec in
that doc's earlier sections). **Every "+ Add" button across all 11 tracked
modules (Accounts, Transactions, Assets, Liabilities, Goals, Budget, Bills,
Subscriptions, Insurance, Tax, Document Vault) opens a real form wired to
the backend** — this was a gap introduced mid-redesign (buttons existed
visually before their forms were built) and has since been closed.

| Layer | Implemented | Stubbed / TODO |
|---|---|---|
| Auth | Register, login, Google OAuth (verifies id_token via Google, finds-or-creates user, auto-links existing email), refresh w/ rotation + reuse detection, logout that actually revokes the session server-side, password reset (real email flow via a swappable mail service, dev-mode logs the email instead of sending it), TOTP 2FA (enable/verify with QR + manual key) | Real email provider not wired (console-log stub only — see `app/services/mail.py`); 2FA backup codes not generated |
| Users | `GET/PATCH /users/me` (profile, currency, timezone) | Avatar upload, `/users/me/export` (GDPR data export), `/users/me/audit-logs` |
| Accounts | Full CRUD | — |
| Categories | Full CRUD (system defaults + custom) | — |
| Transactions | Full CRUD, filtering, pagination, balance-sync trigger | Splits, receipts, recurring materialization |
| Assets | Full CRUD, valuation history, allocation summary | — |
| Liabilities | Full CRUD, payments, amortization schedule | — |
| Goals | Full CRUD, contributions, linear recommendation | AI-driven recommendation using actual cash-flow history |
| Budget Planner | Create budget, set per-category planned amounts, planned-vs-actual status | Recurring auto-copy from prior month |
| Bills | Full CRUD, mark-paid rolls due_date forward by frequency | Reminder notifications (Celery task stubbed in `app/tasks/notifications.py`) |
| Subscriptions | Full CRUD, monthly/yearly total summary (normalized across billing cycles) | — |
| Insurance | Full CRUD, renewal reminder | — |
| Tax Planner | Profile (income/deductions), slab-based estimate, deduction-room suggestions (India, illustrative slabs) | Multi-country tax systems, AI-driven investment suggestions |
| Document Vault | Upload (PDF/JPEG/PNG/WebP, 10MB limit), list, metadata | Local-disk storage backend only — Azure Blob SAS-token backend documented but not wired (see `app/services/blob_storage.py`) |
| Reports | Net worth (current snapshot only — see router docstring), cash flow trend, category breakdown, investment performance | True historical net-worth backfill (needs a balance-snapshot table + Celery job) |
| Analytics | Financial Health Score (deterministic: savings rate + debt-to-income + emergency fund, weighted) with daily history | — |
| Calendar | Aggregates bills, subscriptions, goal target dates for a given month | — |
| Notifications | List, mark-read, mark-all-read, unread-count bell in top bar | Nothing currently *writes* notifications yet — `app/tasks/notifications.py` (bill reminders) is still a stub, so the list will be empty until that's wired up |
| Dashboard | Net worth (balances), cash flow, savings rate, recent transactions | Full net worth incl. assets/liabilities |
| AI | Gateway abstraction; working NL-search (one intent), overspending detection (deterministic, per-category vs. 3-month baseline), Financial Health Score | Remaining NL intents, LLM-generated monthly summary narrative, investment allocation suggestions |

## Repository Layout

```
wealthos/
├── apps/
│   ├── web/     # Next.js 14 (App Router) + TypeScript + Tailwind
│   └── api/     # FastAPI + SQLAlchemy (async) + Alembic + Celery
├── infra/       # docker-compose, (Azure IaC to be added per docs/06)
├── .github/workflows/  # CI pipeline
└── docs/        # Full product & engineering documentation set
```

## Running tests

```bash
# Backend
cd apps/api
pip install -r requirements.txt -r requirements-dev.txt
pytest --cov=app

# Frontend
cd apps/web
npm install
npm run lint && npm run type-check
```

## Adding a new module (e.g., Assets)

Follow the pattern already established by `accounts`:
1. Add the SQLAlchemy model in `app/models/`.
2. Add an Alembic migration (`alembic revision -m "add assets table"`) — copy the DDL from `docs/02-Database-Design.md`, including its RLS policy and any triggers.
3. Add Pydantic schemas in `app/schemas/`.
4. Add a router in `app/api/v1/<module>/router.py`, include it in `app/api/v1/router.py`.
5. Add the matching Next.js page under `apps/web/src/app/(dashboard)/<module>/`.
6. Add unit + integration tests.

## License

Proprietary — All rights reserved.
