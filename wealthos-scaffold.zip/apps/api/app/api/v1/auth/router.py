from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    generate_secure_token,
    hash_password,
    hash_token,
    verify_password,
)
from app.models.user import Role, Session, User
from app.schemas.auth import (
    ForgotPasswordRequest,
    LoginRequest,
    RefreshRequest,
    RegisterRequest,
    ResetPasswordRequest,
    TokenResponse,
    UserPublic,
)

router = APIRouter(prefix="/auth", tags=["auth"])


async def _issue_tokens(db: AsyncSession, user: User, request: Request) -> TokenResponse:
    access = create_access_token(str(user.id))
    refresh = create_refresh_token(str(user.id))

    db.add(
        Session(
            user_id=user.id,
            refresh_token_hash=hash_token(refresh),
            user_agent=request.headers.get("user-agent"),
            ip_address=request.client.host if request.client else None,
            expires_at=datetime.now(timezone.utc)
            + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
        )
    )
    await db.flush()

    return TokenResponse(
        access_token=access,
        refresh_token=refresh,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        user=UserPublic.model_validate(user),
    )


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(payload: RegisterRequest, request: Request, db: AsyncSession = Depends(get_db)):
    existing = await db.execute(select(User).where(User.email == payload.email))
    if existing.scalar_one_or_none():
        raise HTTPException(status.HTTP_409_CONFLICT, "An account with this email already exists")

    default_role = (await db.execute(select(Role).where(Role.name == "owner"))).scalar_one_or_none()
    if not default_role:
        raise HTTPException(status.HTTP_500_INTERNAL_SERVER_ERROR, "Default role not seeded")

    user = User(
        email=payload.email,
        password_hash=hash_password(payload.password),
        full_name=payload.full_name,
        role_id=default_role.id,
        auth_provider="email",
    )
    db.add(user)
    await db.flush()

    return await _issue_tokens(db, user, request)


@router.post("/login", response_model=TokenResponse)
async def login(payload: LoginRequest, request: Request, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(User).where(User.email == payload.email, User.deleted_at.is_(None))
    )
    user = result.scalar_one_or_none()

    # Constant-shape error to avoid user-enumeration timing/response differences.
    if not user or not user.password_hash or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid email or password")

    if not user.is_active:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Account is disabled")

    user.last_login_at = datetime.now(timezone.utc)
    return await _issue_tokens(db, user, request)


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(payload: RefreshRequest, request: Request, db: AsyncSession = Depends(get_db)):
    decoded = decode_token(payload.refresh_token)
    if not decoded or decoded.get("type") != "refresh":
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid refresh token")

    token_hash = hash_token(payload.refresh_token)
    result = await db.execute(select(Session).where(Session.refresh_token_hash == token_hash))
    session_row = result.scalar_one_or_none()

    if not session_row or session_row.is_revoked or session_row.expires_at < datetime.now(timezone.utc):
        # Reuse-detection: a stale/revoked token being replayed revokes the whole family.
        if session_row and not session_row.is_revoked:
            session_row.is_revoked = True
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Refresh token expired or revoked")

    session_row.is_revoked = True  # rotate: old token can never be reused

    user = await db.get(User, session_row.user_id)
    if not user or not user.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "User not found or inactive")

    return await _issue_tokens(db, user, request)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(payload: RefreshRequest, db: AsyncSession = Depends(get_db)):
    token_hash = hash_token(payload.refresh_token)
    result = await db.execute(select(Session).where(Session.refresh_token_hash == token_hash))
    session_row = result.scalar_one_or_none()
    if session_row:
        session_row.is_revoked = True


@router.post("/password/forgot", status_code=status.HTTP_202_ACCEPTED)
async def forgot_password(payload: ForgotPasswordRequest, db: AsyncSession = Depends(get_db)):
    # Always return 202 regardless of whether the email exists (no enumeration).
    result = await db.execute(select(User).where(User.email == payload.email))
    user = result.scalar_one_or_none()
    if user:
        reset_token = generate_secure_token()
        # In production: persist hash_token(reset_token) + 15-min expiry to a
        # password_resets table, then email the raw token via SendGrid/ACS.
        # Omitted here — see docs/05-Security-Design.md §2.
        _ = reset_token
    return {"message": "If that email exists, a reset link has been sent."}


@router.post("/password/reset", status_code=status.HTTP_204_NO_CONTENT)
async def reset_password(payload: ResetPasswordRequest, db: AsyncSession = Depends(get_db)):
    # Lookup password_resets by hash_token(payload.token), verify not expired/used,
    # update user's password_hash, mark token used, revoke all sessions.
    raise HTTPException(status.HTTP_501_NOT_IMPLEMENTED, "Wire up password_resets table to complete this flow")
