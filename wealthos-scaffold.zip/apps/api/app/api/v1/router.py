from fastapi import APIRouter

from app.api.v1.accounts.router import router as accounts_router
from app.api.v1.ai.router import router as ai_router
from app.api.v1.assets.router import router as assets_router
from app.api.v1.auth.router import router as auth_router
from app.api.v1.bills.router import router as bills_router
from app.api.v1.budgets.router import router as budgets_router
from app.api.v1.categories.router import router as categories_router
from app.api.v1.dashboard.router import router as dashboard_router
from app.api.v1.goals.router import router as goals_router
from app.api.v1.liabilities.router import router as liabilities_router
from app.api.v1.transactions.router import router as transactions_router

api_router = APIRouter()
api_router.include_router(auth_router)
api_router.include_router(accounts_router)
api_router.include_router(categories_router)
api_router.include_router(transactions_router)
api_router.include_router(assets_router)
api_router.include_router(liabilities_router)
api_router.include_router(goals_router)
api_router.include_router(budgets_router)
api_router.include_router(bills_router)
api_router.include_router(dashboard_router)
api_router.include_router(ai_router)

# Additional module routers (categories, assets, liabilities, goals, budgets,
# bills, subscriptions, insurance, tax, documents, reports, analytics,
# notifications, ai) follow the same pattern established by accounts/
# transactions above and are included here as they're implemented —
# see docs/03-API-Documentation.md for the full contract of each.
