export type AccountType = "bank_savings" | "bank_current" | "cash_wallet" | "credit_card";
export type TransactionType = "income" | "expense" | "transfer";

export interface Account {
  id: string;
  account_type: AccountType;
  name: string;
  institution_name: string | null;
  current_balance: number;
  credit_limit: number | null;
  currency: string;
  is_active: boolean;
}

export interface Transaction {
  id: string;
  account_id: string;
  type: TransactionType;
  amount: number;
  category_id: string | null;
  transaction_date: string;
  merchant: string | null;
  notes: string | null;
  is_recurring: boolean;
}

export interface DashboardSummary {
  net_worth: number;
  month_income: number;
  month_expense: number;
  savings_rate_pct: number;
  recent_transactions: {
    id: string;
    type: TransactionType;
    amount: number;
    merchant: string | null;
    date: string;
  }[];
}

export interface UserPublic {
  id: string;
  email: string;
  full_name: string;
  base_currency: string;
}

export interface Asset {
  id: string;
  name: string;
  quantity: number | null;
  purchase_value: number | null;
  current_value: number;
  purchase_date: string | null;
  institution: string | null;
}

export interface AssetAllocationItem {
  asset_type: string;
  total_value: number;
  percentage: number;
}

export interface AssetSummary {
  total_value: number;
  allocation: AssetAllocationItem[];
}

export interface Liability {
  id: string;
  name: string;
  lender: string | null;
  principal_amount: number;
  outstanding_amount: number;
  interest_rate: number | null;
  emi_amount: number | null;
  end_date: string | null;
}

export type GoalType =
  | "emergency_fund"
  | "house"
  | "car"
  | "vacation"
  | "retirement"
  | "child_education"
  | "custom";

export interface Goal {
  id: string;
  goal_type: GoalType;
  name: string;
  target_amount: number;
  current_amount: number;
  target_date: string | null;
  status: "active" | "completed" | "paused" | "cancelled";
  progress_pct: number;
}

export interface BudgetItemStatus {
  category_id: string;
  category_name: string;
  planned_amount: number;
  actual_amount: number;
  percentage_used: number;
}

export interface BudgetStatus {
  budget_id: string;
  period_start: string;
  period_end: string;
  items: BudgetItemStatus[];
}

export interface Bill {
  id: string;
  name: string;
  amount: number;
  due_date: string;
  frequency: "weekly" | "monthly" | "quarterly" | "yearly";
  is_autopay: boolean;
  is_active: boolean;
}
